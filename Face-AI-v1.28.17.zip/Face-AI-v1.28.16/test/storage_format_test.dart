import 'package:flutter_test/flutter_test.dart';
import 'package:face_ai/main.dart';

void main() {
  group('formatStorageSize', () {
    test('formats bytes and kilobytes', () {
      expect(formatStorageSize(512), '512 بايت');
      expect(formatStorageSize(2048), '2.0 كيلوبايت');
    });

    test('formats megabytes and gigabytes', () {
      expect(formatStorageSize(5 * 1024 * 1024), '5.0 ميجابايت');
      expect(formatStorageSize(2 * 1024 * 1024 * 1024), '2.00 جيجابايت');
    });
  });
}
