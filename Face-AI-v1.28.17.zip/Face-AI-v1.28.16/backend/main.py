import asyncio
import json
import math
import os
import hmac
import shutil
import subprocess
import tempfile
import threading
import time
import uuid
from contextlib import asynccontextmanager
from io import BytesIO
from pathlib import Path

from fastapi import FastAPI, UploadFile, File, Form, HTTPException, Header, BackgroundTasks
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse, Response
from starlette.background import BackgroundTask
from PIL import Image, ImageEnhance, ImageFilter, ImageOps

from engine import EngineNotReadyError, face_swap_engine
from audio_engine import AudioEngineNotReadyError, audio_engine
from worker_pool import worker_pool

def nonnegative_int_env(name: str, default: int) -> int:
    raw = os.getenv(name, str(default)).strip()
    try:
        value = int(raw)
    except (TypeError, ValueError) as error:
        raise RuntimeError(f"{name} must be zero or a positive integer (0 = unlimited)") from error
    if value < 0:
        raise RuntimeError(f"{name} must be zero or a positive integer (0 = unlimited)")
    return value


def hard_capped_limit_env(name: str, hard_maximum: int) -> int:
    """Allow operators to lower limits, never raise the product's fixed ceilings.

    A configured zero means use the hard maximum; it cannot disable these caps.
    """
    configured = nonnegative_int_env(name, hard_maximum)
    return min(configured or hard_maximum, hard_maximum)


MAX_IMAGE_SIZE = nonnegative_int_env("MAX_IMAGE_SIZE", 0)
MAX_IMAGE_PIXELS = nonnegative_int_env("MAX_IMAGE_PIXELS", 0)
# These are product-level limits agreed for this app, not operator-overridable maxima.
MAX_VIDEO_SIZE = hard_capped_limit_env("MAX_VIDEO_SIZE", 300 * 1024 * 1024)
MAX_WORKER_RESULT_SIZE = hard_capped_limit_env("MAX_WORKER_RESULT_SIZE", 600 * 1024 * 1024)
MAX_VIDEO_SECONDS = hard_capped_limit_env("MAX_VIDEO_SECONDS", 120)
MAX_VIDEO_PIXELS = nonnegative_int_env("MAX_VIDEO_PIXELS", 0)
MEDIA_PROBE_TIMEOUT = nonnegative_int_env("MEDIA_PROBE_TIMEOUT", 0)
# Pillow has its own implicit decompression-bomb threshold; disable it only when
# the owner has explicitly chosen no pixel cap, leaving physical memory as the limit.
Image.MAX_IMAGE_PIXELS = MAX_IMAGE_PIXELS or None
APP_VERSION = "1.28.17"
UPLOAD_CHUNK_SIZE = 1024 * 1024
PROCESSING_LOCK = asyncio.Semaphore(1)
API_KEY = os.getenv("API_KEY", "").strip()
REQUIRE_API_KEY = os.getenv("REQUIRE_API_KEY", "false").strip().lower() in {"1", "true", "yes"}
JOB_ROOT = Path(os.getenv("JOB_ROOT", "/tmp/mohtarif-ai-jobs"))
# 0 disables automatic expiry and queue-count caps for this private instance.
JOB_TTL_SECONDS = nonnegative_int_env("JOB_TTL_SECONDS", 0)
MAX_ACTIVE_JOBS = nonnegative_int_env("MAX_ACTIVE_JOBS", 0)
JOBS: dict[str, dict] = {}
JOBS_LOCK = threading.Lock()
UPLOAD_RESERVATIONS = 0
# GPU readiness is granted only after a real authenticated inference smoke test.
GPU_SELF_TEST_PASSED = False
GPU_SELF_TEST_AT: float | None = None
GPU_SELF_TEST_PROVIDER: str | None = None


def persist_job_locked(job: dict) -> None:
    """Atomically persist public job state so completed results survive restarts."""
    job_dir = JOB_ROOT / job["job_id"]
    job_dir.mkdir(parents=True, exist_ok=True)
    metadata_path = job_dir / "job.json"
    temporary_path = job_dir / "job.json.tmp"
    persistent_fields = (
        "job_id", "status", "progress", "message", "created_at",
        "stage", "processing_backend", "worker_id", "updated_at",
    )
    payload = {key: job[key] for key in persistent_fields if key in job}
    temporary_path.write_text(json.dumps(payload, ensure_ascii=False), encoding="utf-8")
    temporary_path.replace(metadata_path)


@asynccontextmanager
async def lifespan(_app: FastAPI):
    """Prepare storage, restore finished jobs and mark interrupted work safely."""
    if REQUIRE_API_KEY and not API_KEY:
        raise RuntimeError("REQUIRE_API_KEY is enabled but API_KEY is empty")
    JOB_ROOT.mkdir(parents=True, exist_ok=True)
    cutoff = time.time() - JOB_TTL_SECONDS if JOB_TTL_SECONDS else None
    with JOBS_LOCK:
        JOBS.clear()
        for folder in JOB_ROOT.iterdir():
            if not folder.is_dir():
                continue
            try:
                if cutoff is not None and folder.stat().st_mtime < cutoff:
                    shutil.rmtree(folder, ignore_errors=True)
                    continue
                metadata_path = folder / "job.json"
                if not metadata_path.is_file():
                    continue
                job = json.loads(metadata_path.read_text(encoding="utf-8"))
                if (not isinstance(job, dict)
                        or not isinstance(job.get("job_id"), str)
                        or not __import__("re").fullmatch(r"[a-f0-9]{32}", job["job_id"])):
                    continue
                if folder.name != job["job_id"]:
                    continue
                if job.get("status") in {"queued", "processing"}:
                    job.update(
                        status="failed", progress=0,
                        message="توقفت المعالجة بسبب إعادة تشغيل الخادم. أعد إرسال الفيديو.",
                    )
                    persist_job_locked(job)
                JOBS[job["job_id"]] = job
            except (OSError, ValueError, TypeError, json.JSONDecodeError):
                continue
    yield


app = FastAPI(
    title="Al Mohtarif AI Engine",
    description="Private AI Processing Server",
    version=APP_VERSION,
    lifespan=lifespan,
)
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=False,
    allow_methods=["GET", "POST"],
    allow_headers=["Content-Type", "X-API-Key"],
)


@app.get("/")
async def home():
    return {"app": "المحترف في AI", "status": "running", "version": APP_VERSION}


@app.get("/health")
async def health():
    runtime = face_swap_engine.provider_diagnostics()
    return {
        "status": "online",
        "engine": "FaceFusion",
        "engine_script_available": face_swap_engine.is_available(),
        "ffmpeg_available": face_swap_engine.ffmpeg_available(),
        "engine_files_present": face_swap_engine.is_available() and face_swap_engine.ffmpeg_available(),
        "models_verified": False,
        "processing_ready": False,
        "gpu_worker_ready": bool(
            os.getenv("GPU_WORKER_READY", "false").strip().lower() in {"1", "true", "yes"}
            and REQUIRE_API_KEY and bool(API_KEY)
            and runtime.get("gpu_hardware_detected")
            and runtime.get("cuda_provider_available")
            and runtime.get("provider_preflight_ready")
            and runtime.get("required_model_files_present")
            and any(provider in face_swap_engine.execution_providers for provider in ("cuda", "tensorrt"))
            and face_swap_engine.is_available() and face_swap_engine.ffmpeg_available()
            and GPU_SELF_TEST_PASSED
        ),
        "gpu_self_test_passed": GPU_SELF_TEST_PASSED,
        "gpu_self_test_at": GPU_SELF_TEST_AT,
        "gpu_self_test_provider": GPU_SELF_TEST_PROVIDER,
        "api_key_required": REQUIRE_API_KEY,
        "api_key_configured": bool(API_KEY),
        "runtime": runtime,
        "audio_local_runners": audio_engine.status(),
        "runtime_preflight_ready": runtime.get("provider_preflight_ready", False),
        "note": "وجود ملفات التشغيل أو مزود CUDA لا يثبت تنزيل النماذج أو نجاح المعالجة الفعلية.",
    }


@app.get("/api/worker/health")
async def protected_worker_health(x_api_key: str | None = Header(default=None)):
    """Authenticated readiness endpoint used only by remote coordinators."""
    verify_api_key(x_api_key)
    status = await health()
    # This flag is returned only after the caller has passed API-key verification.
    status["api_key_protected"] = True
    return status


@app.post("/api/worker/self-test")
async def gpu_worker_self_test(
    source: UploadFile = File(...),
    target: UploadFile = File(...),
    x_api_key: str | None = Header(default=None),
):
    """Run a real image inference before this worker can advertise GPU readiness."""
    global GPU_SELF_TEST_PASSED, GPU_SELF_TEST_AT, GPU_SELF_TEST_PROVIDER
    if not REQUIRE_API_KEY or not API_KEY:
        raise HTTPException(503, "اختبار GPU يتطلب REQUIRE_API_KEY=true وضبط API_KEY أولاً")
    verify_api_key(x_api_key)
    GPU_SELF_TEST_PASSED = False
    GPU_SELF_TEST_AT = None
    GPU_SELF_TEST_PROVIDER = None
    try:
        diagnostics = face_swap_engine.provider_diagnostics()
        selected = [item.lower() for item in face_swap_engine.execution_providers]
        if not diagnostics.get("gpu_hardware_detected"):
            raise HTTPException(503, "لم يتم اكتشاف بطاقة NVIDIA فعلية على العامل")
        if not diagnostics.get("cuda_provider_available"):
            raise HTTPException(503, "مزود CUDA غير متاح في ONNX Runtime")
        if not diagnostics.get("provider_preflight_ready"):
            raise HTTPException(503, "مزود التنفيذ المحدد غير جاهز")
        if not diagnostics.get("required_model_files_present"):
            raise HTTPException(503, "ملفات نماذج FaceFusion المطلوبة غير مكتملة")
        if not any(item in {"cuda", "tensorrt"} for item in selected):
            raise HTTPException(503, "إعداد FaceFusion لا يطلب CUDA أو TensorRT")
        ensure_engine_ready()
        source_data = await validate_image(source)
        target_data = await validate_image(target)
    except HTTPException as error:
        error.headers = {**(error.headers or {}), "X-Worker-Stage": "preflight"}
        raise

    with tempfile.TemporaryDirectory(prefix="mohtarif-gpu-selftest-") as temp_dir:
        output_path = Path(temp_dir) / "self-test.png"
        try:
            async with PROCESSING_LOCK:
                await asyncio.to_thread(
                    face_swap_engine.swap_faces, source_data, target_data, str(output_path)
                )
            result_info = await asyncio.to_thread(validate_processed_image, output_path)
        except Exception as error:
            raise HTTPException(503, f"فشل اختبار الاستدلال الفعلي على GPU: {str(error)[:700]}") from error

    # A successful FaceFusion run with CUDA selected, CUDA exposed, and a visible
    # NVIDIA device is the worker's runtime attestation. It is intentionally
    # memory-only and must be repeated after every process restart.
    GPU_SELF_TEST_PASSED = True
    GPU_SELF_TEST_AT = time.time()
    GPU_SELF_TEST_PROVIDER = ",".join(selected)
    return {
        "passed": True,
        "test": "real_face_swap_inference",
        "provider": GPU_SELF_TEST_PROVIDER,
        "gpu_devices": diagnostics.get("gpu_devices", []),
        "output": result_info,
        "note": "نجح اختبار inference فعلي؛ ستظل الجاهزية صالحة طوال عمر عملية الخادم الحالية فقط.",
    }


@app.post("/api/worker/process")
async def worker_process_video(
    source: UploadFile = File(...),
    target: UploadFile = File(...),
    x_api_key: str | None = Header(default=None),
):
    """Authenticated worker protocol: accept one video, run local FaceFusion, return MP4."""
    verify_api_key(x_api_key)
    # Mark only deterministic, pre-inference rejections as safe for coordinator
    # failover. A timeout or failure after inference starts is ambiguous and must
    # never trigger an automatic duplicate execution on another GPU.
    try:
        ready = await health()
        if not ready.get("gpu_worker_ready"):
            raise HTTPException(503, "هذا العامل غير معلن كعامل GPU جاهز؛ أكمل اختبار GPU الفعلي أولاً")
        suffix = Path(target.filename or "video.mp4").suffix.lower()
        if suffix not in {".mp4", ".mov", ".mkv", ".webm", ".avi"}:
            raise HTTPException(400, "صيغة الفيديو غير مدعومة")
        if target.content_type and not target.content_type.startswith("video/"):
            raise HTTPException(400, "الملف المرسل ليس فيديو")
        source_data = await validate_image(source)
    except HTTPException as error:
        error.headers = {**(error.headers or {}), "X-Worker-Stage": "preflight"}
        raise
    root = Path(tempfile.mkdtemp(prefix="mohtarif-worker-"))
    source_path = root / "source.png"
    video_path = root / f"input{suffix}"
    output_path = root / "faceswap.mp4"
    try:
        with Image.open(BytesIO(source_data)) as image:
            ImageOps.exif_transpose(image).convert("RGB").save(source_path, format="PNG")
        await stream_upload_to_path(target, video_path, MAX_VIDEO_SIZE)
        duration = await asyncio.to_thread(video_duration_seconds, video_path)
        if MAX_VIDEO_SECONDS and duration > MAX_VIDEO_SECONDS:
            raise HTTPException(413, "مدة الفيديو تتجاوز 120 ثانية", headers={"X-Worker-Stage": "preflight"})
        try:
            ensure_engine_ready(require_ffmpeg=True)
        except HTTPException as error:
            error.headers = {**(error.headers or {}), "X-Worker-Stage": "preflight"}
            raise
        async with PROCESSING_LOCK:
            await asyncio.to_thread(face_swap_engine.swap_video_files, str(source_path), str(video_path), str(output_path))
        await asyncio.to_thread(validate_processed_video, output_path)
        return FileResponse(output_path, media_type="video/mp4", filename="faceswap.mp4", background=BackgroundTask(shutil.rmtree, str(root), ignore_errors=True))
    except Exception:
        shutil.rmtree(root, ignore_errors=True)
        raise


@app.post("/api/worker/process-image")
async def worker_process_image(
    source: UploadFile = File(...),
    target: UploadFile = File(...),
    x_api_key: str | None = Header(default=None),
):
    """Authenticated image worker endpoint; GPU readiness must be explicitly enabled."""
    verify_api_key(x_api_key)
    try:
        ready = await health()
        if not ready.get("gpu_worker_ready"):
            raise HTTPException(503, "هذا العامل غير معلن كعامل GPU جاهز؛ أكمل اختبار GPU الفعلي أولاً")
        source_data = await validate_image(source)
        target_data = await validate_image(target)
        ensure_engine_ready()
    except HTTPException as error:
        error.headers = {**(error.headers or {}), "X-Worker-Stage": "preflight"}
        raise
    root = Path(tempfile.mkdtemp(prefix="mohtarif-worker-image-"))
    output_path = root / "faceswap.png"
    try:
        async with PROCESSING_LOCK:
            await asyncio.to_thread(face_swap_engine.swap_faces, source_data, target_data, str(output_path))
        await asyncio.to_thread(validate_processed_image, output_path)
        if MAX_IMAGE_SIZE and output_path.stat().st_size > MAX_IMAGE_SIZE:
            raise HTTPException(413, "حجم الصورة الناتجة تجاوز الحد المضبوط")
        return FileResponse(output_path, media_type="image/png", filename="faceswap.png",
                            background=BackgroundTask(shutil.rmtree, str(root), ignore_errors=True))
    except Exception:
        shutil.rmtree(root, ignore_errors=True)
        raise


@app.get("/api/workers")
async def list_workers(x_api_key: str | None = Header(default=None)):
    """Show configured remote GPU workers without exposing their credentials."""
    verify_api_key(x_api_key)
    return {
        "configured_workers": len(worker_pool.workers),
        "workers": worker_pool.snapshot(),
        "dispatch_implemented": True,
        "scheduler_reservations_supported": True,
        "state_persistence_path_configured": bool(worker_pool.state_path),
        "state_persistence_error": worker_pool.state_persistence_error,
        "note": "حصص العمال وحالات العزل تُحفظ محلياً إن كان مسار الحالة قابلاً للكتابة؛ لا توجد موارد GPU مضمونة أو مهيأة افتراضياً.",
    }


@app.post("/api/workers/refresh")
async def refresh_workers(x_api_key: str | None = Header(default=None)):
    verify_api_key(x_api_key)
    workers = await worker_pool.refresh()
    return {"checked": len(workers), "workers": workers,
            "dispatch_implemented": True}


@app.post("/api/workers/select")
async def select_worker(x_api_key: str | None = Header(default=None)):
    """Dry-run candidate selection; deliberately does not reserve or dispatch."""
    verify_api_key(x_api_key)
    candidate = await worker_pool.select_candidate()
    return {"candidate": candidate, "dispatch_implemented": True, "dry_run": True,
            "message": "لا يوجد عامل مؤهل حالياً." if candidate is None else "تم تحديد عامل مؤهل مبدئياً؛ لم تُرسل إليه مهمة."}


@app.get("/api/workers/summary")
async def workers_summary(x_api_key: str | None = Header(default=None)):
    """Compact scheduler view for the mobile app and operational checks."""
    verify_api_key(x_api_key)
    workers = worker_pool.snapshot()
    return {
        "configured": len(workers),
        "healthy": sum(1 for item in workers if item["healthy"]),
        "eligible": sum(1 for item in workers if item["eligible"]),
        "active_reservations": sum(item["active_jobs"] for item in workers),
        "dispatch_implemented": True,
        "state_persistence_error": worker_pool.state_persistence_error,
        "workers": workers,
    }


@app.get("/api/diagnostics")
async def diagnostics():
    """Detailed runtime preflight; never reports model inference as verified."""
    runtime = face_swap_engine.provider_diagnostics()
    return {
        "facefusion_cli_available": face_swap_engine.is_available(),
        "ffmpeg_available": face_swap_engine.ffmpeg_available(),
        "runtime_preflight_ready": runtime.get("provider_preflight_ready", False),
        "runtime": runtime,
        "audio_local_runners": audio_engine.status(),
        "models_verified": False,
        "processing_verified": False,
        "message": "الفحص يتحقق من متطلبات التشغيل ووجود الملفات المحددة فقط؛ لا ينفذ استدلالاً ولا يثبت جودة تبديل الوجه.",
    }


@app.get("/api/capabilities")
async def capabilities():
    """Expose implemented routes separately from features that are not ready."""
    runtime = face_swap_engine.provider_diagnostics()
    return {
        "app": "المحترف في AI",
        "version": APP_VERSION,
        "limits": {
            "image_bytes": MAX_IMAGE_SIZE or None,
            "video_bytes": MAX_VIDEO_SIZE or None,
            "video_seconds": MAX_VIDEO_SECONDS or None,
            "image_max_pixels": MAX_IMAGE_PIXELS or None,
            "video_max_pixels": MAX_VIDEO_PIXELS or None,
            "active_jobs": MAX_ACTIVE_JOBS or None,
            "job_retention_seconds": JOB_TTL_SECONDS or None,
            "media_probe_timeout_seconds": MEDIA_PROBE_TIMEOUT or None,
        },
        "server": {
            "facefusion_cli_available": face_swap_engine.is_available(),
            "ffmpeg_available": face_swap_engine.ffmpeg_available(),
            "models_verified": False,
            "api_key_required": REQUIRE_API_KEY,
            "runtime": runtime,
            "runtime_preflight_ready": runtime.get("provider_preflight_ready", False),
            "selected_execution_providers": face_swap_engine.execution_providers,
            "configured_remote_gpu_workers": len(worker_pool.workers),
            "remote_dispatch_protocol": True,
        },
        "features": {
            "image_face_swap": {"api": True, "ai_verified": False, "runtime_preflight_required": True},
            "video_face_swap": {"api": True, "maximum_seconds": MAX_VIDEO_SECONDS or None, "ai_verified": False, "runtime_preflight_required": True},
            "remote_gpu_dispatch": {"api": True, "worker_endpoint": "/api/worker/process", "image_worker_endpoint": "/api/worker/process-image", "self_test_endpoint": "/api/worker/self-test", "gpu_workers_configured": len(worker_pool.workers), "gpu_inference_verified": GPU_SELF_TEST_PASSED},
            "basic_image_enhancement": {"api": True, "uses_ai_model": False},
            "voice_cloning": {"api": True, "runner_available": audio_engine.status()["voice_clone"]["available"], "ai_verified": False, "local_only": True},
            "voice_conversion": {"api": True, "runner_available": audio_engine.status()["voice_convert"]["available"], "ai_verified": False, "local_only": True},
            "music_generation": {"api": True, "runner_available": audio_engine.status()["music"]["available"], "ai_verified": False, "local_only": True},
        },
        "notice": "توفر نقطة API لا يعني أن محرك AI أو أوزانه قد تم اختبارها فعلياً.",
    }


def verify_api_key(x_api_key: str | None):
    # Fail closed even when an endpoint is invoked outside the normal lifespan.
    # This prevents a misconfigured protected deployment from silently becoming public.
    if REQUIRE_API_KEY and not API_KEY:
        raise HTTPException(503, "الخادم مفعّل عليه التحقق من المفتاح لكن API_KEY غير مضبوط")
    if API_KEY and (x_api_key is None or not hmac.compare_digest(x_api_key, API_KEY)):
        raise HTTPException(401, "مفتاح الوصول غير صحيح")


def ensure_engine_ready(*, require_ffmpeg: bool = False) -> None:
    """Reject work before large uploads when core runtime requirements are absent."""
    if not face_swap_engine.is_available():
        raise HTTPException(503, "محرك FaceFusion غير مثبت على الخادم")
    if require_ffmpeg and not face_swap_engine.ffmpeg_available():
        raise HTTPException(503, "FFmpeg/FFprobe غير مثبت على الخادم")
    try:
        face_swap_engine.preflight()
    except EngineNotReadyError as error:
        raise HTTPException(503, str(error)) from error


def cleanup_old_jobs() -> None:
    """Remove expired job folders and metadata from this single-process queue."""
    if not JOB_TTL_SECONDS:
        return
    cutoff = time.time() - JOB_TTL_SECONDS
    with JOBS_LOCK:
        expired = [
            job_id for job_id, job in JOBS.items()
            if job.get("created_at", time.time()) < cutoff
            and job.get("status") not in {"queued", "processing"}
        ]
        for job_id in expired:
            shutil.rmtree(JOB_ROOT / job_id, ignore_errors=True)
            JOBS.pop(job_id, None)


def public_job(job: dict) -> dict:
    return {
        "job_id": job["job_id"],
        "status": job["status"],
        "progress": job["progress"],
        "message": job["message"],
        "created_at": job["created_at"],
        "stage": job.get("stage", job["status"]),
        "processing_backend": job.get("processing_backend"),
        "worker_id": job.get("worker_id"),
        "updated_at": job.get("updated_at"),
        "result_url": f"/api/jobs/{job['job_id']}/result" if job["status"] == "completed" else None,
    }


def update_job_state(job_id: str, **changes) -> None:
    """Update and persist observable job progress without leaking worker credentials."""
    with JOBS_LOCK:
        job = JOBS.get(job_id)
        if job is None:
            return
        job.update(changes)
        job["updated_at"] = time.time()
        persist_job_locked(job)


def worker_rejection_is_retryable(status_code: int, headers=None) -> bool:
    """Fail over only when the worker explicitly says inference never started."""
    headers = headers or {}
    stage = next((value for key, value in headers.items()
                  if key.lower() == "x-worker-stage"), "")
    return stage.lower() == "preflight" and (400 <= status_code < 500 or status_code == 503)


async def stream_worker_result(response, output_path: Path, max_size: int) -> int:
    """Stream a remote MP4 result to disk with content-type and byte-limit checks."""
    content_type = response.headers.get("content-type", "").split(";", 1)[0].strip().lower()
    if content_type != "video/mp4":
        raise RuntimeError(f"عامل GPU أعاد نوع ملف غير متوقع: {content_type or 'غير محدد'}")
    output_path.parent.mkdir(parents=True, exist_ok=True)
    received = 0
    try:
        with output_path.open("wb") as output_file:
            async for chunk in response.aiter_bytes(1024 * 1024):
                if not chunk:
                    continue
                received += len(chunk)
                if max_size and received > max_size:
                    raise RuntimeError("حجم نتيجة عامل GPU تجاوز الحد المضبوط")
                output_file.write(chunk)
    except Exception:
        output_path.unlink(missing_ok=True)
        raise
    if received == 0:
        output_path.unlink(missing_ok=True)
        raise RuntimeError("عامل GPU أعاد ملف نتيجة فارغاً")
    return received


async def stream_worker_image_result(response, output_path: Path, max_size: int) -> int:
    """Stream and validate a remote PNG result without trusting its Content-Length."""
    content_type = response.headers.get("content-type", "").split(";", 1)[0].strip().lower()
    if content_type != "image/png":
        raise RuntimeError(f"عامل GPU أعاد نوع صورة غير متوقع: {content_type or 'غير محدد'}")
    output_path.parent.mkdir(parents=True, exist_ok=True)
    received = 0
    try:
        with output_path.open("wb") as output_file:
            async for chunk in response.aiter_bytes(256 * 1024):
                if not chunk:
                    continue
                received += len(chunk)
                if max_size and received > max_size:
                    raise RuntimeError("حجم نتيجة صورة عامل GPU تجاوز الحد المضبوط")
                output_file.write(chunk)
    except Exception:
        output_path.unlink(missing_ok=True)
        raise
    if received == 0:
        output_path.unlink(missing_ok=True)
        raise RuntimeError("عامل GPU أعاد صورة فارغة")
    return received


async def dispatch_image_to_worker(source_data: bytes, target_data: bytes) -> bytes | None:
    """Use a verified remote GPU worker; None means no worker was eligible."""
    attempted: set[str] = set()
    last_error = None
    for _attempt in range(min(3, len(worker_pool.workers))):
        worker = await worker_pool.reserve_candidate(exclude_ids=attempted)
        if worker is None:
            break
        attempted.add(worker.worker_id)
        marked_failure = False
        try:
            import httpx
            async with httpx.AsyncClient(timeout=httpx.Timeout(300.0, connect=15.0), follow_redirects=False) as client:
                async with client.stream(
                    "POST", worker.base_url + "/api/worker/process-image",
                    headers={"X-API-Key": worker.api_key},
                    files={
                        "source": ("source.png", source_data, "image/png"),
                        "target": ("target.png", target_data, "image/png"),
                    },
                ) as response:
                    if response.status_code != 200:
                        detail = (await response.aread())[:1500].decode("utf-8", "replace")
                        last_error = f"العامل {worker.worker_id}: HTTP {response.status_code} {detail}"
                        retryable = worker_rejection_is_retryable(response.status_code, response.headers)
                        await worker_pool.mark_failure(worker.worker_id, last_error,
                                                       cooldown_seconds=15.0 if retryable else None)
                        marked_failure = True
                        if not retryable:
                            raise RuntimeError(last_error + " — أُوقفت إعادة المحاولة لأن العامل لم يؤكد أن المعالجة لم تبدأ")
                        continue
                    with tempfile.TemporaryDirectory(prefix="mohtarif-image-result-") as temp_dir:
                        result_path = Path(temp_dir) / "result.png"
                        await stream_worker_image_result(response, result_path, MAX_IMAGE_SIZE)
                        await asyncio.to_thread(validate_processed_image, result_path)
                        image_data = result_path.read_bytes()
            await worker_pool.mark_success(worker.worker_id)
            await worker_pool.consume_quota(worker.worker_id)
            return image_data
        except Exception as error:
            if not marked_failure:
                await worker_pool.mark_failure(worker.worker_id, str(error))
            raise
        finally:
            await worker_pool.release_reservation(worker.worker_id, consume_quota=False)
    if attempted:
        raise RuntimeError(last_error or "لم ينجح أي عامل GPU متاح؛ لم يتم تشغيل المعالجة المحلية تلقائياً لتجنب تكرار مهمة غير مؤكدة")
    return None


async def process_video_job(job_id: str, source_path: Path, video_path: Path,
                            output_path: Path) -> None:
    with JOBS_LOCK:
        job = JOBS.get(job_id)
        if job is None:
            return
        job.update(status="processing", progress=8, stage="worker_selection",
                    processing_backend=None, worker_id=None,
                    message="جاري فحص عمال GPU واختيار العامل المناسب", updated_at=time.time())
        persist_job_locked(job)
    reserved_worker = None
    successful_worker_id = None
    try:
        # Remote workers are used only when their authenticated health endpoint
        # explicitly confirms GPU readiness. Otherwise the coordinator uses its local engine.
        attempted_workers: set[str] = set()
        remote_completed = False
        last_worker_error = None
        for _attempt in range(min(3, len(worker_pool.workers))):
            reserved_worker = await worker_pool.reserve_candidate(exclude_ids=attempted_workers)
            if reserved_worker is None:
                break
            attempted_workers.add(reserved_worker.worker_id)
            update_job_state(job_id, progress=18, stage="remote_dispatch",
                             processing_backend="remote_gpu", worker_id=reserved_worker.worker_id,
                             message=f"جاري إرسال الفيديو إلى عامل GPU: {reserved_worker.worker_id}")
            worker_failure_marked = False
            try:
                import httpx
                with source_path.open("rb") as source_file, video_path.open("rb") as video_file:
                    async with httpx.AsyncClient(timeout=httpx.Timeout(900.0, connect=15.0)) as client:
                        async with client.stream(
                            "POST", reserved_worker.base_url + "/api/worker/process",
                            headers={"X-API-Key": reserved_worker.api_key},
                            files={
                                "source": ("source.png", source_file, "image/png"),
                                "target": (video_path.name, video_file, "video/mp4"),
                            },
                        ) as response:
                            if response.status_code != 200:
                                detail = (await response.aread())[:3000].decode("utf-8", "replace")
                                last_worker_error = f"العامل {reserved_worker.worker_id}: HTTP {response.status_code} {detail}"
                                safe_to_failover = worker_rejection_is_retryable(response.status_code, response.headers)
                                await worker_pool.mark_failure(
                                    reserved_worker.worker_id, last_worker_error,
                                    cooldown_seconds=15.0 if safe_to_failover else None,
                                )
                                worker_failure_marked = True
                                if not safe_to_failover:
                                    raise RuntimeError(last_worker_error + " — أُوقفت إعادة المحاولة لأن العامل لم يؤكد أن المعالجة لم تبدأ")
                            else:
                                update_job_state(job_id, progress=82, stage="validating_result",
                                                 message="استُلم الفيديو؛ جاري فحص سلامة النتيجة")
                                await stream_worker_result(response, output_path, MAX_WORKER_RESULT_SIZE)
                                await asyncio.to_thread(validate_processed_video, output_path)
                                await worker_pool.mark_success(reserved_worker.worker_id)
                                remote_completed = True
                                successful_worker_id = reserved_worker.worker_id
                if remote_completed:
                    break
            except Exception as worker_error:
                if reserved_worker is not None and not worker_failure_marked:
                    await worker_pool.mark_failure(reserved_worker.worker_id, str(worker_error))
                raise
            finally:
                await worker_pool.release_reservation(reserved_worker.worker_id, consume_quota=False)
                reserved_worker = None
        if not remote_completed and attempted_workers:
            output_path.unlink(missing_ok=True)
            raise RuntimeError(last_worker_error or "تعذر تنفيذ المهمة على العمال المتاحين؛ لم يتم تحويلها تلقائياً إلى CPU لتجنب تشغيل مزدوج غير مؤكد.")
        if not remote_completed:
            update_job_state(job_id, progress=18, stage="local_processing",
                             processing_backend="local_engine", worker_id=None,
                             message="لا يوجد عامل GPU مؤهل؛ جاري تجهيز محرك المعالجة المحلي")
            ensure_engine_ready(require_ffmpeg=True)
            update_job_state(job_id, progress=35, stage="local_inference",
                             message="محرك المعالجة المحلي بدأ تنفيذ تبديل الوجه")
            async with PROCESSING_LOCK:
                await asyncio.to_thread(face_swap_engine.swap_video_files, str(source_path), str(video_path), str(output_path))
        update_job_state(job_id, progress=94, stage="final_validation",
                         message="جاري التحقق النهائي من مدة الفيديو وحجمه وسلامة مساره")
        await asyncio.to_thread(validate_processed_video, output_path)
        if successful_worker_id is not None:
            await worker_pool.consume_quota(successful_worker_id)
        update_job_state(job_id, status="completed", progress=100, stage="completed",
                         processing_backend="remote_gpu" if successful_worker_id else "local_engine",
                         worker_id=successful_worker_id, message="اكتملت معالجة الفيديو وأصبحت النتيجة جاهزة للتنزيل")
    except Exception as error:
        if reserved_worker is not None:
            await worker_pool.release_reservation(reserved_worker.worker_id, consume_quota=False)
        output_path.unlink(missing_ok=True)
        update_job_state(job_id, status="failed", progress=0, stage="failed",
                         message=str(error)[-1500:])


async def read_limited(file: UploadFile, limit: int) -> bytes:
    data = await file.read(limit + 1 if limit else -1)
    if limit and len(data) > limit:
        raise HTTPException(413, "حجم الملف أكبر من الحد المسموح")
    if not data:
        raise HTTPException(400, "الملف فارغ")
    return data


async def stream_upload_to_path(file: UploadFile, destination: Path, limit: int) -> int:
    """Write an upload incrementally so large videos are not duplicated in RAM."""
    total = 0
    destination.parent.mkdir(parents=True, exist_ok=True)
    try:
        with destination.open("wb") as output:
            while True:
                chunk = await file.read(UPLOAD_CHUNK_SIZE)
                if not chunk:
                    break
                total += len(chunk)
                if limit and total > limit:
                    raise HTTPException(413, "حجم الفيديو أكبر من الحد المسموح وفق إعدادات الخادم")
                output.write(chunk)
    except Exception:
        destination.unlink(missing_ok=True)
        raise
    if total == 0:
        destination.unlink(missing_ok=True)
        raise HTTPException(400, "ملف الفيديو فارغ")
    return total


async def validate_image(file: UploadFile) -> bytes:
    if not file.content_type or not file.content_type.startswith("image/"):
        raise HTTPException(400, "الملف لازم يكون صورة")
    data = await read_limited(file, MAX_IMAGE_SIZE)
    try:
        image = Image.open(BytesIO(data))
        if MAX_IMAGE_PIXELS and image.width * image.height > MAX_IMAGE_PIXELS:
            raise HTTPException(413, "أبعاد الصورة أكبر من الحد المضبوط في إعدادات الخادم")
        image.verify()
    except HTTPException:
        raise
    except Exception:
        raise HTTPException(400, "تعذر قراءة الصورة؛ اختر صورة سليمة")
    return data


def probe_video(video_path: Path) -> dict:
    """Read real media streams with ffprobe; filename/MIME alone are not enough."""
    command = [
        "ffprobe", "-v", "error", "-show_entries",
        "format=duration:stream=codec_type,codec_name,width,height",
        "-of", "json", str(video_path),
    ]
    try:
        result = subprocess.run(command, capture_output=True, text=True, timeout=MEDIA_PROBE_TIMEOUT or None)
    except subprocess.TimeoutExpired as error:
        raise ValueError("استغرق فحص الفيديو وقتاً أطول من المتوقع") from error
    if result.returncode != 0:
        raise ValueError("ملف الفيديو تالف أو صيغته غير مدعومة")
    try:
        metadata = json.loads(result.stdout)
        duration = float(metadata["format"]["duration"])
        if not math.isfinite(duration) or duration <= 0:
            raise ValueError("مدة الفيديو غير صالحة")
        streams = metadata.get("streams", [])
        video_streams = [stream for stream in streams if stream.get("codec_type") == "video"]
        if not video_streams:
            raise ValueError("الملف لا يحتوي على مسار فيديو صالح")
        for stream in video_streams:
            width = int(stream.get("width") or 0)
            height = int(stream.get("height") or 0)
            if width < 1 or height < 1:
                raise ValueError("تعذر تحديد أبعاد الفيديو")
            if MAX_VIDEO_PIXELS and width * height > MAX_VIDEO_PIXELS:
                raise ValueError("دقة الفيديو أعلى من حد البكسلات المضبوط في إعدادات الخادم")
        return {"duration": duration, "video_streams": video_streams, "streams": streams}
    except (KeyError, TypeError, json.JSONDecodeError) as error:
        raise ValueError("تعذر قراءة معلومات الفيديو") from error


def video_duration_seconds(video_path: Path) -> float:
    """Backward-compatible duration helper, now backed by full stream validation."""
    return float(probe_video(video_path)["duration"])


def validate_processed_video(video_path: Path) -> dict:
    """Verify output media integrity and enforce the same duration ceiling as input."""
    if not video_path.is_file() or video_path.stat().st_size < 12:
        raise ValueError("ملف الفيديو الناتج مفقود أو أصغر من أن يكون ملف MP4 صالحاً")
    if MAX_WORKER_RESULT_SIZE and video_path.stat().st_size > MAX_WORKER_RESULT_SIZE:
        raise ValueError("حجم الفيديو الناتج تجاوز الحد الأقصى البالغ 600 ميجابايت")
    try:
        metadata = probe_video(video_path)
    except ValueError as error:
        raise ValueError(f"ملف الفيديو الناتج غير صالح: {error}") from error
    if not metadata.get("video_streams"):
        raise ValueError("ملف الفيديو الناتج لا يحتوي على مسار فيديو")
    if MAX_VIDEO_SECONDS and metadata.get("duration", 0) > MAX_VIDEO_SECONDS:
        raise ValueError("مدة الفيديو الناتج تجاوزت الحد الأقصى البالغ 120 ثانية")
    return metadata


def validate_processed_image(image_path: Path) -> dict:
    """Decode the generated image and enforce output format and dimension limits."""
    if not image_path.is_file() or image_path.stat().st_size < 8:
        raise ValueError("ملف الصورة الناتج مفقود أو فارغ")
    try:
        with Image.open(image_path) as image:
            image.verify()
        with Image.open(image_path) as image:
            width, height = image.size
            image_format = image.format
            if width < 1 or height < 1 or (MAX_IMAGE_PIXELS and width * height > MAX_IMAGE_PIXELS):
                raise ValueError("أبعاد الصورة الناتجة غير صالحة أو تتجاوز الحد المضبوط")
            image.load()
    except (OSError, ValueError, Image.DecompressionBombError) as error:
        raise ValueError(f"ملف الصورة الناتج غير صالح: {error}") from error
    if image_format != "PNG":
        raise ValueError("محرك تبديل الوجه لم يُنتج صورة PNG صالحة")
    if width < 1 or height < 1 or (MAX_IMAGE_PIXELS and width * height > MAX_IMAGE_PIXELS):
        raise ValueError("أبعاد الصورة الناتجة غير صالحة أو تتجاوز الحد المضبوط")
    return {"width": width, "height": height, "format": image_format}


@app.post("/api/faceswap")
async def face_swap(
    source: UploadFile = File(...),
    target: UploadFile = File(...),
    x_api_key: str | None = Header(default=None),
):
    verify_api_key(x_api_key)
    source_data = await validate_image(source)
    target_data = await validate_image(target)
    try:
        remote_result = await dispatch_image_to_worker(source_data, target_data)
        if remote_result is not None:
            return Response(
                content=remote_result, media_type="image/png",
                headers={"Content-Disposition": 'attachment; filename="faceswap.png"',
                         "X-Processing-Backend": "remote-gpu"},
            )
        ensure_engine_ready()
        with tempfile.TemporaryDirectory() as temp_dir:
            output_path = Path(temp_dir) / "faceswap.png"
            async with PROCESSING_LOCK:
                await asyncio.to_thread(
                    face_swap_engine.swap_faces, source_data, target_data, str(output_path)
                )
            await asyncio.to_thread(validate_processed_image, output_path)
            result = output_path.read_bytes()
        return Response(
            content=result, media_type="image/png",
            headers={"Content-Disposition": 'attachment; filename="faceswap.png"',
                     "X-Processing-Backend": "local"},
        )
    except EngineNotReadyError as error:
        raise HTTPException(503, str(error))
    except subprocess.TimeoutExpired:
        raise HTTPException(504, "انتهت مهلة معالجة الصورة؛ حاول بصورة أصغر")
    except HTTPException:
        raise
    except Exception as error:
        raise HTTPException(500, f"فشل تبديل الوجه: {str(error)}")


@app.post("/api/faceswap/video")
async def face_swap_video(
    source: UploadFile = File(...),
    target: UploadFile = File(...),
    x_api_key: str | None = Header(default=None),
):
    """Synchronous compatibility route; video uploads and downloads stay disk-backed."""
    verify_api_key(x_api_key)
    source_data = await validate_image(source)
    allowed_suffixes = {".mp4", ".mov", ".mkv", ".webm", ".avi"}
    suffix = Path(target.filename or "video.mp4").suffix.lower()
    if suffix not in allowed_suffixes:
        raise HTTPException(400, "صيغة الفيديو غير مدعومة؛ استخدم MP4 أو MOV أو MKV أو WEBM أو AVI")
    if target.content_type and not target.content_type.startswith("video/"):
        raise HTTPException(400, "الملف الثاني لازم يكون فيديو")
    ensure_engine_ready(require_ffmpeg=True)
    temp_dir = Path(tempfile.mkdtemp(prefix="mohtarif-ai-video-"))
    try:
        source_path = temp_dir / "source.png"
        input_path = temp_dir / f"input{suffix}"
        output_path = temp_dir / "faceswap.mp4"
        with Image.open(BytesIO(source_data)) as source_image:
            ImageOps.exif_transpose(source_image).convert("RGB").save(source_path, format="PNG")
        await stream_upload_to_path(target, input_path, MAX_VIDEO_SIZE)
        duration = await asyncio.to_thread(video_duration_seconds, input_path)
        if MAX_VIDEO_SECONDS and duration > MAX_VIDEO_SECONDS:
            raise HTTPException(413, "مدة الفيديو تتجاوز الحد الحالي: 120 ثانية (قابل للتعديل من إعدادات الخادم)")
        async with PROCESSING_LOCK:
            await asyncio.to_thread(
                face_swap_engine.swap_video_files,
                str(source_path), str(input_path), str(output_path)
            )
        await asyncio.to_thread(validate_processed_video, output_path)
        return FileResponse(
            output_path, media_type="video/mp4", filename="faceswap.mp4",
            background=BackgroundTask(shutil.rmtree, str(temp_dir), ignore_errors=True),
        )
    except HTTPException:
        shutil.rmtree(temp_dir, ignore_errors=True)
        raise
    except EngineNotReadyError as error:
        shutil.rmtree(temp_dir, ignore_errors=True)
        raise HTTPException(503, str(error)) from error
    except subprocess.TimeoutExpired as error:
        shutil.rmtree(temp_dir, ignore_errors=True)
        raise HTTPException(504, "انتهت مهلة معالجة الفيديو؛ تحقق من موارد الخادم أو إعدادات المهلة") from error
    except ValueError as error:
        shutil.rmtree(temp_dir, ignore_errors=True)
        raise HTTPException(400, str(error)) from error
    except Exception as error:
        shutil.rmtree(temp_dir, ignore_errors=True)
        raise HTTPException(500, f"فشل تبديل الوجه في الفيديو: {str(error)}") from error


@app.post("/api/jobs/faceswap/video", status_code=202)
async def create_video_job(
    background_tasks: BackgroundTasks,
    source: UploadFile = File(...),
    target: UploadFile = File(...),
    x_api_key: str | None = Header(default=None),
):
    """Queue a video swap while streaming the large video upload to disk."""
    global UPLOAD_RESERVATIONS
    verify_api_key(x_api_key)
    cleanup_old_jobs()

    with JOBS_LOCK:
        active = sum(item["status"] in {"queued", "processing"} for item in JOBS.values())
        if MAX_ACTIVE_JOBS and active + UPLOAD_RESERVATIONS >= MAX_ACTIVE_JOBS:
            raise HTTPException(429, "تم بلوغ حد المهام المضبوط في إعدادات الخادم")
        UPLOAD_RESERVATIONS += 1
    reservation_held = True
    job_dir: Path | None = None
    job_id = uuid.uuid4().hex

    try:
        source_data = await validate_image(source)
        allowed_suffixes = {".mp4", ".mov", ".mkv", ".webm", ".avi"}
        suffix = Path(target.filename or "video.mp4").suffix.lower()
        if suffix not in allowed_suffixes:
            raise HTTPException(400, "صيغة الفيديو غير مدعومة؛ استخدم MP4 أو MOV أو MKV أو WEBM أو AVI")
        if target.content_type and not target.content_type.startswith("video/"):
            raise HTTPException(400, "الملف الثاني لازم يكون فيديو")
        if worker_pool.workers:
            if not shutil.which("ffprobe"):
                raise HTTPException(503, "FFprobe مطلوب لفحص مدة الفيديو على خادم التنسيق")
        else:
            # Preserve early local-engine preflight when no remote workers are configured.
            ensure_engine_ready(require_ffmpeg=True)

        job_dir = JOB_ROOT / job_id
        job_dir.mkdir(parents=True, exist_ok=False)
        source_path = job_dir / "source.png"
        video_path = job_dir / f"input{suffix}"
        output_path = job_dir / "faceswap.mp4"
        with Image.open(BytesIO(source_data)) as source_image:
            ImageOps.exif_transpose(source_image).convert("RGB").save(source_path, format="PNG")
        await stream_upload_to_path(target, video_path, MAX_VIDEO_SIZE)
        duration = await asyncio.to_thread(video_duration_seconds, video_path)
        if MAX_VIDEO_SECONDS and duration > MAX_VIDEO_SECONDS:
            raise HTTPException(413, "مدة الفيديو تتجاوز الحد الحالي: 120 ثانية (قابل للتعديل من إعدادات الخادم)")

        job = {
            "job_id": job_id,
            "status": "queued",
            "progress": 5,
            "message": "تم استلام الفيديو وهو في انتظار المعالجة",
            "created_at": time.time(),
            "updated_at": time.time(),
            "stage": "queued",
            "processing_backend": None,
            "worker_id": None,
        }
        # Atomically turn the upload reservation into a queued job.
        with JOBS_LOCK:
            UPLOAD_RESERVATIONS -= 1
            reservation_held = False
            JOBS[job_id] = job
            persist_job_locked(job)
        background_tasks.add_task(process_video_job, job_id, source_path, video_path, output_path)
        return public_job(job)
    except Exception:
        with JOBS_LOCK:
            if reservation_held:
                UPLOAD_RESERVATIONS -= 1
            JOBS.pop(job_id, None)
        if job_dir is not None:
            shutil.rmtree(job_dir, ignore_errors=True)
        raise


@app.get("/api/jobs/{job_id}")
async def get_video_job(job_id: str, x_api_key: str | None = Header(default=None)):
    verify_api_key(x_api_key)
    if not __import__("re").fullmatch(r"[a-f0-9]{32}", job_id):
        raise HTTPException(404, "مهمة المعالجة غير موجودة أو انتهت صلاحيتها")
    with JOBS_LOCK:
        job = JOBS.get(job_id)
        if job is None:
            raise HTTPException(404, "مهمة المعالجة غير موجودة أو انتهت صلاحيتها")
        return public_job(job)


@app.get("/api/jobs/{job_id}/result")
async def get_video_job_result(job_id: str, x_api_key: str | None = Header(default=None)):
    verify_api_key(x_api_key)
    if not __import__("re").fullmatch(r"[a-f0-9]{32}", job_id):
        raise HTTPException(404, "مهمة المعالجة غير موجودة أو انتهت صلاحيتها")
    with JOBS_LOCK:
        job = JOBS.get(job_id)
        if job is None:
            raise HTTPException(404, "مهمة المعالجة غير موجودة أو انتهت صلاحيتها")
        if job["status"] != "completed":
            raise HTTPException(409, "الفيديو لم يكتمل بعد")
    output_path = JOB_ROOT / job_id / "faceswap.mp4"
    if not output_path.is_file():
        with JOBS_LOCK:
            if job_id in JOBS:
                JOBS[job_id].update(
                    status="failed", progress=0,
                    message="ملف نتيجة الفيديو غير موجود على الخادم؛ أعد إرسال الفيديو.",
                )
                persist_job_locked(JOBS[job_id])
        raise HTTPException(410, "ملف النتيجة لم يعد متاحاً؛ أعد إرسال الفيديو")
    try:
        await asyncio.to_thread(validate_processed_video, output_path)
    except (ValueError, OSError) as error:
        with JOBS_LOCK:
            if job_id in JOBS:
                JOBS[job_id].update(
                    status="failed", progress=0,
                    message="ملف نتيجة الفيديو تالف أو غير قابل للقراءة؛ أعد إرسال الفيديو.",
                )
                persist_job_locked(JOBS[job_id])
        raise HTTPException(410, "ملف نتيجة الفيديو تالف أو غير صالح؛ أعد إرسال الفيديو") from error
    return FileResponse(output_path, media_type="video/mp4", filename="faceswap.mp4")


AUDIO_OUTPUT_ROOT = Path(os.getenv("AUDIO_OUTPUT_ROOT", str(JOB_ROOT / "audio")))
AUDIO_EXTENSIONS = {".wav", ".mp3", ".m4a", ".flac", ".ogg", ".aac", ".opus"}


async def save_audio_upload(upload: UploadFile, destination: Path) -> Path:
    suffix = Path(upload.filename or "audio.wav").suffix.lower()
    if suffix not in AUDIO_EXTENSIONS:
        raise HTTPException(400, "صيغة الصوت غير مدعومة؛ استخدم WAV أو MP3 أو M4A أو FLAC أو OGG")
    destination.parent.mkdir(parents=True, exist_ok=True)
    total = 0
    with destination.open("wb") as output:
        while True:
            chunk = await upload.read(1024 * 1024)
            if not chunk:
                break
            output.write(chunk)
            total += len(chunk)
    if total == 0:
        destination.unlink(missing_ok=True)
        raise HTTPException(400, "ملف الصوت فارغ")
    if shutil.which("ffprobe"):
        probe = subprocess.run(
            ["ffprobe", "-v", "error", "-select_streams", "a:0", "-show_entries",
             "stream=codec_type", "-of", "default=nw=1:nk=1", str(destination)],
            capture_output=True, text=True, timeout=30,
        )
        if probe.returncode != 0 or "audio" not in probe.stdout.lower():
            destination.unlink(missing_ok=True)
            raise HTTPException(400, "الملف المرفوع ليس ملفًا صوتيًا سليمًا")
    return destination


def audio_result_response(path: Path, filename: str):
    work_dir = path.parent
    return FileResponse(
        path, media_type="audio/wav", filename=filename,
        background=BackgroundTask(lambda: shutil.rmtree(work_dir, ignore_errors=True)),
    )


@app.get("/api/audio/status")
async def audio_status(x_api_key: str | None = Header(default=None)):
    verify_api_key(x_api_key)
    return {
        "local_only": True,
        "paid_external_services": False,
        "runners": audio_engine.status(),
        "note": "تُشغّل النماذج محليًا على الخادم فقط. ظهور runner متاح لا يثبت جودة النموذج قبل الاختبار الفعلي.",
    }


@app.post("/api/audio/voice-clone")
async def clone_voice(
    reference_audio: UploadFile = File(...),
    text: str = Form(...),
    language: str = Form("ar"),
    consent_confirmed: bool = Form(False),
    x_api_key: str | None = Header(default=None),
):
    verify_api_key(x_api_key)
    if not consent_confirmed:
        raise HTTPException(400, "أكد أن الصوت صوتك أو لديك إذن صريح من صاحبه")
    if not text.strip():
        raise HTTPException(400, "اكتب النص المطلوب نطقه")
    if len(text) > 10000:
        raise HTTPException(400, "النص طويل جدًا")
    if not language.strip() or len(language) > 16:
        raise HTTPException(400, "رمز اللغة غير صالح")
    AUDIO_OUTPUT_ROOT.mkdir(parents=True, exist_ok=True)
    work = Path(tempfile.mkdtemp(prefix="voice-clone-", dir=AUDIO_OUTPUT_ROOT))
    try:
        reference = await save_audio_upload(reference_audio, work / "reference" / ("reference" + Path(reference_audio.filename or "voice.wav").suffix.lower()))
        output = work / "cloned_voice.wav"
        await asyncio.to_thread(audio_engine.clone_voice, reference, text.strip(), language.strip(), output)
        return audio_result_response(output, "cloned_voice.wav")
    except AudioEngineNotReadyError as error:
        shutil.rmtree(work, ignore_errors=True)
        raise HTTPException(503, str(error)) from error
    except HTTPException:
        shutil.rmtree(work, ignore_errors=True)
        raise
    except Exception as error:
        shutil.rmtree(work, ignore_errors=True)
        raise HTTPException(500, f"فشل استنساخ الصوت: {str(error)}") from error


@app.post("/api/audio/voice-convert")
async def convert_voice(
    input_audio: UploadFile = File(...),
    target_voice_audio: UploadFile = File(...),
    consent_confirmed: bool = Form(False),
    x_api_key: str | None = Header(default=None),
):
    verify_api_key(x_api_key)
    if not consent_confirmed:
        raise HTTPException(400, "أكد امتلاكك حق استخدام الصوتين أو وجود إذن صريح")
    AUDIO_OUTPUT_ROOT.mkdir(parents=True, exist_ok=True)
    work = Path(tempfile.mkdtemp(prefix="voice-convert-", dir=AUDIO_OUTPUT_ROOT))
    try:
        source = await save_audio_upload(input_audio, work / "input" / (Path(input_audio.filename or "input.wav").name))
        reference = await save_audio_upload(target_voice_audio, work / "reference" / (Path(target_voice_audio.filename or "voice.wav").name))
        output = work / "converted_voice.wav"
        await asyncio.to_thread(audio_engine.convert_voice, source, reference, output)
        return audio_result_response(output, "converted_voice.wav")
    except AudioEngineNotReadyError as error:
        shutil.rmtree(work, ignore_errors=True)
        raise HTTPException(503, str(error)) from error
    except HTTPException:
        shutil.rmtree(work, ignore_errors=True)
        raise
    except Exception as error:
        shutil.rmtree(work, ignore_errors=True)
        raise HTTPException(500, f"فشل تغيير الصوت: {str(error)}") from error


@app.post("/api/audio/music")
async def generate_music(
    prompt: str = Form(...),
    lyrics: str = Form(""),
    duration_seconds: float = Form(60.0),
    x_api_key: str | None = Header(default=None),
):
    verify_api_key(x_api_key)
    if not prompt.strip():
        raise HTTPException(400, "اكتب وصف الأغنية أو نوع الموسيقى")
    if len(prompt) > 4000 or len(lyrics) > 12000:
        raise HTTPException(400, "الوصف أو الكلمات أطول من المسموح به")
    if not math.isfinite(duration_seconds) or duration_seconds <= 0:
        raise HTTPException(400, "مدة الأغنية يجب أن تكون رقمًا موجبًا")
    AUDIO_OUTPUT_ROOT.mkdir(parents=True, exist_ok=True)
    work = Path(tempfile.mkdtemp(prefix="music-", dir=AUDIO_OUTPUT_ROOT))
    try:
        output = work / "generated_song.wav"
        await asyncio.to_thread(audio_engine.generate_music, prompt.strip(), lyrics.strip(), duration_seconds, output)
        return audio_result_response(output, "generated_song.wav")
    except AudioEngineNotReadyError as error:
        shutil.rmtree(work, ignore_errors=True)
        raise HTTPException(503, str(error)) from error
    except Exception as error:
        shutil.rmtree(work, ignore_errors=True)
        raise HTTPException(500, f"فشل إنشاء الأغنية: {str(error)}") from error


@app.post("/api/enhance")
async def enhance_image(
    image: UploadFile = File(...),
    x_api_key: str | None = Header(default=None),
):
    """Basic Pillow enhancement; this is not AI super-resolution."""
    verify_api_key(x_api_key)
    data = await validate_image(image)
    try:
        def process():
            with Image.open(BytesIO(data)) as original:
                result = ImageOps.exif_transpose(original).convert("RGB")
                result = ImageEnhance.Color(result).enhance(1.06)
                result = ImageEnhance.Contrast(result).enhance(1.08)
                result = ImageEnhance.Sharpness(result).enhance(1.25)
                result = result.filter(ImageFilter.UnsharpMask(radius=1.2, percent=115, threshold=3))
                output = BytesIO()
                result.save(output, format="JPEG", quality=95, optimize=True)
                return output.getvalue()
        async with PROCESSING_LOCK:
            result = await asyncio.to_thread(process)
        return Response(
            content=result, media_type="image/jpeg",
            headers={"Content-Disposition": 'attachment; filename="enhanced.jpg"'},
        )
    except Exception as error:
        raise HTTPException(500, f"تعذر تحسين الصورة: {str(error)}")
