"""Local-only audio AI adapters. No cloud APIs or paid services are used."""
import os
import shutil
import subprocess
from pathlib import Path


class AudioEngineNotReadyError(RuntimeError):
    pass


class LocalAudioEngine:
    """Run owner-installed local model adapters through a strict CLI contract.

    Each configured runner is a Python script implementing the documented
    command-line arguments. The API never sends audio or text to third parties.
    """
    def __init__(self):
        self.python = os.getenv("AUDIO_RUNNER_PYTHON", "python")
        self.timeout = int(os.getenv("AUDIO_RUNNER_TIMEOUT", "0"))
        if self.timeout < 0:
            raise ValueError("AUDIO_RUNNER_TIMEOUT must be zero or positive")
        self.runners = {
            "voice_clone": os.getenv("VOICE_CLONE_RUNNER", "").strip(),
            "voice_convert": os.getenv("VOICE_CONVERSION_RUNNER", "").strip(),
            "music": os.getenv("MUSIC_GENERATION_RUNNER", "").strip(),
        }

    def status(self):
        return {
            name: {"configured": bool(path), "available": bool(path and Path(path).is_file())}
            for name, path in self.runners.items()
        }

    def _run(self, feature: str, args: list[str], output: Path) -> Path:
        runner = self.runners[feature]
        if not runner or not Path(runner).is_file():
            raise AudioEngineNotReadyError(
                f"محرك {feature} المحلي غير مثبت أو غير مضبوط على الخادم"
            )
        output.parent.mkdir(parents=True, exist_ok=True)
        command = [self.python, runner, *args, "--output-path", str(output)]
        try:
            result = subprocess.run(
                command, capture_output=True, text=True,
                timeout=self.timeout or None, check=False,
            )
        except subprocess.TimeoutExpired as error:
            raise RuntimeError("انتهت مهلة تشغيل محرك الصوت المحلي") from error
        if result.returncode != 0:
            details = result.stderr or result.stdout or "Local audio model failed"
            raise RuntimeError(details[-5000:])
        if not output.is_file() or output.stat().st_size < 128:
            raise RuntimeError("محرك الصوت لم ينتج ملفًا صوتيًا صالحًا")
        if not shutil.which("ffprobe"):
            raise RuntimeError("FFprobe غير متوفر للتحقق من ملف الصوت الناتج")
        probe = subprocess.run(
            ["ffprobe", "-v", "error", "-select_streams", "a:0",
             "-show_entries", "stream=codec_type", "-of", "default=nw=1:nk=1", str(output)],
            capture_output=True, text=True, timeout=30, check=False,
        )
        if probe.returncode != 0 or "audio" not in probe.stdout.lower():
            raise RuntimeError("الملف الناتج لا يحتوي على مسار صوت قابل للقراءة")
        return output

    def clone_voice(self, reference: Path, text: str, language: str, output: Path) -> Path:
        return self._run("voice_clone", [
            "--reference-audio", str(reference), "--text", text,
            "--language", language,
        ], output)

    def convert_voice(self, source: Path, reference: Path, output: Path) -> Path:
        return self._run("voice_convert", [
            "--input-audio", str(source), "--target-voice-audio", str(reference),
        ], output)

    def generate_music(self, prompt: str, lyrics: str, duration: float, output: Path) -> Path:
        return self._run("music", [
            "--prompt", prompt, "--lyrics", lyrics,
            "--duration-seconds", str(duration),
        ], output)


audio_engine = LocalAudioEngine()
