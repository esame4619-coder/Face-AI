"""Registry, health monitor and capacity scheduler for authorized remote GPU workers."""
from __future__ import annotations

import asyncio
import json
import os
import time
import urllib.error
import urllib.request
from dataclasses import dataclass, field
from typing import Any
from urllib.parse import urlparse


@dataclass
class Worker:
    worker_id: str
    base_url: str
    api_key: str = field(repr=False)
    priority: int = 100
    max_concurrent: int = 1
    quota_jobs: int | None = None
    enabled: bool = True
    healthy: bool = False
    active_jobs: int = 0
    last_checked: float | None = None
    last_error: str | None = None
    remote_status: dict[str, Any] = field(default_factory=dict)
    cooldown_until: float = 0.0
    consecutive_failures: int = 0
    last_failure: str | None = None

    def public(self) -> dict[str, Any]:
        return {
            "id": self.worker_id,
            "url": self.base_url,
            "priority": self.priority,
            "enabled": self.enabled,
            "healthy": self.healthy,
            "active_jobs": self.active_jobs,
            "max_concurrent": self.max_concurrent,
            "quota_jobs_remaining": self.quota_jobs,
            "last_checked": self.last_checked,
            "last_error": self.last_error,
            "cooldown_seconds_remaining": max(0, round(self.cooldown_until - time.monotonic())),
            "consecutive_failures": self.consecutive_failures,
            "last_failure": self.last_failure,
            "remote_status": self.remote_status,
            "eligible": self.eligible,
        }

    @property
    def eligible(self) -> bool:
        return bool(
            self.enabled and self.healthy
            and time.monotonic() >= self.cooldown_until
            and self.active_jobs < self.max_concurrent
            and (self.quota_jobs is None or self.quota_jobs > 0)
        )


class WorkerPool:
    def __init__(self, workers: list[Worker] | None = None, timeout: float = 5.0,
                 cooldown_seconds: float = 90.0, state_path: str | None = None):
        self.workers = workers or []
        self.timeout = timeout
        self.cooldown_seconds = max(1.0, float(cooldown_seconds))
        self.state_path = state_path if state_path is not None else os.getenv("GPU_WORKER_STATE_PATH")
        self._lock = asyncio.Lock()
        self.state_persistence_error: str | None = None
        self._restore_state()

    def _restore_state(self) -> None:
        """Restore quota and cooldown metadata without ever persisting worker secrets."""
        try:
            with open(self.state_path, "r", encoding="utf-8") as state_file:
                payload = json.load(state_file)
            if not isinstance(payload, dict) or payload.get("schema") != 1:
                return
            records = payload.get("workers")
            if not isinstance(records, dict):
                return
            now_wall = time.time()
            for worker in self.workers:
                saved = records.get(worker.worker_id)
                if not isinstance(saved, dict):
                    continue
                saved_quota = saved.get("quota_jobs_remaining")
                if saved_quota is None:
                    # A saved unlimited quota never overrides a finite quota now
                    # configured by the operator.
                    if worker.quota_jobs is None:
                        worker.quota_jobs = None
                elif isinstance(saved_quota, int) and saved_quota >= 0:
                    # Persisted usage can reduce a configured quota, never increase it.
                    worker.quota_jobs = saved_quota if worker.quota_jobs is None else min(worker.quota_jobs, saved_quota)
                failures = saved.get("consecutive_failures", 0)
                if isinstance(failures, int) and failures >= 0:
                    worker.consecutive_failures = min(failures, 1000)
                until = saved.get("cooldown_until_epoch", 0)
                if isinstance(until, (int, float)) and until > now_wall:
                    worker.cooldown_until = time.monotonic() + min(until - now_wall, 1800.0)
                failure = saved.get("last_failure")
                if isinstance(failure, str):
                    worker.last_failure = failure[:500]
        except FileNotFoundError:
            return
        except (OSError, ValueError, TypeError, json.JSONDecodeError):
            # Corrupt state must not prevent the coordinator from starting.
            return

    def _persist_state(self) -> None:
        """Atomically persist scheduler accounting; API keys and URLs are excluded."""
        path = self.state_path
        if not path:
            return
        try:
            from pathlib import Path
            state_path = Path(path)
            state_path.parent.mkdir(parents=True, exist_ok=True)
            now_mono, now_wall = time.monotonic(), time.time()
            records = {}
            for worker in self.workers:
                remaining = max(0.0, worker.cooldown_until - now_mono)
                records[worker.worker_id] = {
                    "quota_jobs_remaining": worker.quota_jobs,
                    "consecutive_failures": worker.consecutive_failures,
                    "cooldown_until_epoch": now_wall + remaining,
                    "last_failure": worker.last_failure,
                }
            temporary = state_path.with_name(state_path.name + ".tmp")
            temporary.write_text(json.dumps({"schema": 1, "workers": records}, ensure_ascii=False), encoding="utf-8")
            try:
                os.chmod(temporary, 0o600)
            except OSError:
                pass
            temporary.replace(state_path)
        except OSError:
            # Scheduler must continue operating if its optional accounting volume
            # is read-only; the diagnostics endpoint reports persistence status.
            self.state_persistence_error = "Unable to persist GPU worker state"
        else:
            self.state_persistence_error = None

    @classmethod
    def from_env(cls) -> "WorkerPool":
        raw = os.getenv("GPU_WORKERS_JSON", "").strip()
        if not raw:
            return cls()
        try:
            records = json.loads(raw)
        except json.JSONDecodeError as exc:
            raise RuntimeError("GPU_WORKERS_JSON must contain valid JSON") from exc
        if not isinstance(records, list):
            raise RuntimeError("GPU_WORKERS_JSON must be a JSON array")
        workers: list[Worker] = []
        seen: set[str] = set()
        for item in records:
            if not isinstance(item, dict):
                raise RuntimeError("Each GPU worker entry must be an object")
            worker_id = str(item.get("id", "")).strip()
            url = str(item.get("url", "")).strip().rstrip("/")
            parsed = urlparse(url)
            if not worker_id or worker_id in seen:
                raise RuntimeError("GPU worker IDs must be non-empty and unique")
            if parsed.scheme != "https" or not parsed.netloc or parsed.username or parsed.password:
                raise RuntimeError(f"Worker {worker_id}: URL must be HTTPS without embedded credentials")
            key = str(item.get("api_key", ""))
            if not key:
                raise RuntimeError(f"Worker {worker_id}: api_key is required")
            priority = int(item.get("priority", 100))
            max_concurrent = int(item.get("max_concurrent", 1))
            quota = item.get("quota_jobs")
            quota = None if quota is None else int(quota)
            if max_concurrent < 1 or (quota is not None and quota < 0):
                raise RuntimeError(f"Worker {worker_id}: invalid concurrency or quota")
            workers.append(Worker(worker_id, url, key, priority, max_concurrent, quota,
                                  bool(item.get("enabled", True))))
            seen.add(worker_id)
        cooldown = float(os.getenv("GPU_WORKER_COOLDOWN_SECONDS", "90"))
        if cooldown < 1:
            raise RuntimeError("GPU_WORKER_COOLDOWN_SECONDS must be at least 1")
        state_path = os.getenv("GPU_WORKER_STATE_PATH", "/data/gpu-worker-state.json")
        return cls(workers, cooldown_seconds=cooldown, state_path=state_path)

    @staticmethod
    def _probe(worker: Worker, timeout: float) -> tuple[bool, dict[str, Any], str | None]:
        request = urllib.request.Request(
            worker.base_url + "/api/worker/health",
            headers={"X-API-Key": worker.api_key, "Accept": "application/json"},
            method="GET",
        )
        class NoRedirect(urllib.request.HTTPRedirectHandler):
            # Never forward the worker secret to a redirect target.
            def redirect_request(self, req, fp, code, msg, headers, newurl):
                return None

        try:
            opener = urllib.request.build_opener(NoRedirect)
            with opener.open(request, timeout=timeout) as response:
                if response.status != 200:
                    return False, {}, f"HTTP {response.status}"
                payload = json.loads(response.read(128 * 1024).decode("utf-8"))
                if not isinstance(payload, dict):
                    return False, {}, "Health response is not a JSON object"
                # A generic online status is not enough: require explicit readiness
                # and a GPU signal from the worker's own diagnostics.
                runtime = payload.get("runtime") or {}
                # A worker must prove both GPU readiness and mandatory API-key
                # protection. An internet-reachable unauthenticated worker is never eligible.
                secured = payload.get("api_key_required") is True and payload.get("api_key_protected") is True
                gpu_ready = bool(
                    secured and (
                        payload.get("gpu_worker_ready") is True
                        or (payload.get("processing_ready") is True
                            and runtime.get("gpu_hardware_detected") is True
                            and runtime.get("cuda_provider_available") is True
                            and runtime.get("required_model_files_present") is True)
                    )
                )
                return gpu_ready, {
                    "status": payload.get("status"),
                    "gpu_hardware_detected": runtime.get("gpu_hardware_detected"),
                    "cuda_provider_available": runtime.get("cuda_provider_available"),
                    "processing_ready": payload.get("processing_ready"),
                    "gpu_worker_ready": payload.get("gpu_worker_ready"),
                }, None if gpu_ready else "Worker is reachable but GPU processing readiness is not verified"
        except (OSError, urllib.error.URLError, TimeoutError, ValueError) as exc:
            return False, {}, f"{type(exc).__name__}: {str(exc)[:240]}"

    async def refresh(self) -> list[dict[str, Any]]:
        async def check(worker: Worker):
            if not worker.enabled:
                worker.healthy = False
                worker.last_error = "Disabled by configuration"
                worker.last_checked = time.time()
                return
            ok, details, error = await asyncio.to_thread(self._probe, worker, self.timeout)
            worker.healthy = ok
            worker.remote_status = details
            worker.last_error = error
            worker.last_checked = time.time()
        await asyncio.gather(*(check(worker) for worker in self.workers))
        return self.snapshot()

    def snapshot(self) -> list[dict[str, Any]]:
        return [worker.public() for worker in sorted(self.workers, key=lambda w: (w.priority, w.worker_id))]

    async def select_candidate(self) -> dict[str, Any] | None:
        # Refresh before each decision so stale health is never treated as live.
        await self.refresh()
        async with self._lock:
            candidates = [worker for worker in self.workers if worker.eligible]
            if not candidates:
                return None
            chosen = min(candidates, key=lambda w: (w.priority, w.active_jobs, w.worker_id))
            return {"id": chosen.worker_id, "url": chosen.base_url,
                    "priority": chosen.priority, "quota_jobs_remaining": chosen.quota_jobs,
                    "dispatch_supported": True}

    async def reserve_candidate(self, exclude_ids: set[str] | None = None) -> Worker | None:
        """Atomically reserve capacity, optionally excluding failed workers for failover."""
        await self.refresh()
        async with self._lock:
            candidates = [worker for worker in self.workers
                          if worker.eligible and worker.worker_id not in (exclude_ids or set())]
            if not candidates:
                return None
            chosen = min(candidates, key=lambda w: (w.priority, w.active_jobs, w.worker_id))
            chosen.active_jobs += 1
            return chosen

    async def release_reservation(self, worker_id: str, *, consume_quota: bool = False) -> bool:
        """Release a scheduler reservation and optionally consume one accepted job quota."""
        async with self._lock:
            worker = next((item for item in self.workers if item.worker_id == worker_id), None)
            if worker is None:
                return False
            worker.active_jobs = max(0, worker.active_jobs - 1)
            if consume_quota and worker.quota_jobs is not None:
                worker.quota_jobs = max(0, worker.quota_jobs - 1)
            return True


    async def consume_quota(self, worker_id: str) -> bool:
        """Consume one job only after the coordinator has validated the returned result."""
        async with self._lock:
            worker = next((item for item in self.workers if item.worker_id == worker_id), None)
            if worker is None:
                return False
            if worker.quota_jobs is not None:
                worker.quota_jobs = max(0, worker.quota_jobs - 1)
            self._persist_state()
            return True

    async def mark_failure(self, worker_id: str, reason: str, *, cooldown_seconds: float | None = None) -> bool:
        """Temporarily quarantine a worker after an ambiguous/invalid dispatch result."""
        async with self._lock:
            worker = next((item for item in self.workers if item.worker_id == worker_id), None)
            if worker is None:
                return False
            worker.consecutive_failures += 1
            # Exponential backoff is bounded to avoid permanently sidelining a worker.
            base = self.cooldown_seconds if cooldown_seconds is None else max(1.0, cooldown_seconds)
            delay = min(base * (2 ** min(worker.consecutive_failures - 1, 4)), 1800.0)
            worker.cooldown_until = max(worker.cooldown_until, time.monotonic() + delay)
            worker.last_failure = str(reason)[:500]
            worker.last_error = str(reason)[:500]
            self._persist_state()
            return True

    async def mark_success(self, worker_id: str) -> bool:
        """Clear failure backoff only after a valid result has been received."""
        async with self._lock:
            worker = next((item for item in self.workers if item.worker_id == worker_id), None)
            if worker is None:
                return False
            worker.consecutive_failures = 0
            worker.cooldown_until = 0.0
            worker.last_failure = None
            self._persist_state()
            return True


worker_pool = WorkerPool.from_env()

