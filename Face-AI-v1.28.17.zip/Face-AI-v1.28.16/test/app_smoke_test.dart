import 'package:flutter_test/flutter_test.dart';
import 'package:face_ai/main.dart';

void main() {
  testWidgets('application starts and exposes its main navigation',
      (WidgetTester tester) async {
    await tester.pumpWidget(const MohtarifAI());

    expect(find.text('المحترف في AI'), findsOneWidget);
    expect(find.text('الرئيسية'), findsOneWidget);
    expect(find.text('أعمالي'), findsOneWidget);
    expect(find.text('الإعدادات'), findsOneWidget);
  });
}
