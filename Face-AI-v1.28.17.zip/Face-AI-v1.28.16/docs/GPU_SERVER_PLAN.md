# خطة خادم GPU للمحترف في AI

## الهدف
خادم شخصي مخصص لمعالجة تبديل الوجوه في الصور والفيديو، وليس خدمة اشتراكات أو منصة متعددة العملاء. لا توجد فوترة أو باقات أو حصص استخدام داخل التطبيق.

## مواصفات نبدأ بها عند اختيار الاستضافة
- GPU NVIDIA بذاكرة VRAM لا تقل عن 24GB؛ والأفضل 48GB عند الرغبة في التعامل المريح مع فيديوهات عالية الدقة ومهام أكبر.
- RAM لا تقل عن 64GB.
- معالج حديث 12–16 vCPU أو أفضل.
- قرص NVMe لا يقل عن 1TB، مع مساحة إضافية حسب حجم الفيديوهات والنتائج المحتفظ بها.
- اتصال شبكة مستقر بسرعة 1Gbps إن توفر، وقرص/نظام يسمح بكتابة ملفات مؤقتة كبيرة.
- Ubuntu LTS مع NVIDIA driver وNVIDIA Container Toolkit متوافقين مع نسخة CUDA المختارة.

## التوصية المبدئية
الخيار المفضل للبدء هو خادم NVIDIA L40S بذاكرة 48GB، مع 16 vCPU وذاكرة RAM بحجم 64GB وقرص NVMe بسعة 1TB. هذه مواصفات ترشيح أولية وليست خادماً تم حجزه أو اختباره بعد.

## بدائل حسب السعر والتوفر
- NVIDIA RTX 4090 24GB: أداء قوي وقد يكون أوفر، لكن توفره في الاستضافة السحابية يختلف.
- NVIDIA L40S 48GB: الخيار المفضل لراحة أكبر مع الفيديوهات عالية الدقة والمهام الطويلة.
- NVIDIA A100 40/80GB أو H100 80GB: فئات أعلى تكلفة؛ لا نحتاج اعتمادها قبل قياس أداء النماذج الفعلية.

## بوابة الاعتماد قبل شراء/استئجار الخادم
1. تثبيت إصدار FaceFusion محدد مع نسخ Python وONNX Runtime وCUDA/cuDNN متوافقة ومثبتة (pinned).
2. التأكد أن الحاوية ترى GPU عبر `nvidia-smi` وأن ONNX Runtime يعرض CUDAExecutionProvider.
3. تحميل النماذج والتحقق من ملفاتها وتراخيصها ومصدرها.
4. تشغيل inference فعلي لصورة، ثم فيديو قصير، ثم فيديو طويل عالي الدقة.
5. قياس VRAM/RAM والوقت ومعدل الإطارات ودرجة ثبات هوية الوجه عبر الإطارات.
6. لا يُعتمد الخادم إلا بعد نجاح الاختبارات السابقة؛ ظهور CUDA في قائمة المزودات وحده لا يكفي.

## ملاحظة مهمة
الإصدار الحالي ما زال يستخدم Docker CPU. هذه الوثيقة مواصفات اختيار وخطة تحقق وليست إعلاناً أن GPU أصبح مفعلاً. سنبني صورة GPU منفصلة بعد تثبيت التوافق الدقيق، حتى لا نضيف CUDA/ONNX Runtime غير متوافقين ونكسر محرك المعالجة.

## V1.28.3 scheduler hardening

- Worker capacity can now be reserved atomically so simultaneous scheduling requests cannot both claim the same final slot.
- Reservations can be released, with quota consumption explicit and separate from release.
- `GET /api/workers/summary` exposes aggregate configured/healthy/eligible/reserved counts without credentials.
- This is still a scheduler primitive only. Remote upload, execution, result retrieval, and end-to-end GPU inference are not implemented or verified in this release.
- A worker is eligible only when its health endpoint explicitly confirms GPU worker readiness. Merely having an online URL or detecting a GPU is not sufficient.


## V1.28.5 remote worker dispatch
The coordinator now streams media to the authenticated `/api/worker/process` endpoint, streams MP4 back to disk, revalidates it, reserves worker capacity and retries explicit HTTP rejections across up to three eligible workers. The coordinator only needs FFprobe when remote dispatch is available; a worker needs FaceFusion + CUDA. `GPU_WORKER_READY=true` is a deliberate operator attestation after a real inference test, not a substitute for that test. No provider is preconfigured and no GPU inference has been validated in this repository build.
