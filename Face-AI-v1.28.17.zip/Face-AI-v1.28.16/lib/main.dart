import 'dart:io';
import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';
import 'package:path_provider/path_provider.dart';
import 'package:video_player/video_player.dart';
import 'package:file_picker/file_picker.dart';
import 'package:audioplayers/audioplayers.dart';


String formatStorageSize(int bytes) {
  if (bytes < 1024) return '$bytes بايت';
  if (bytes < 1024 * 1024) return '${(bytes / 1024).toStringAsFixed(1)} كيلوبايت';
  if (bytes < 1024 * 1024 * 1024) return '${(bytes / (1024 * 1024)).toStringAsFixed(1)} ميجابايت';
  return '${(bytes / (1024 * 1024 * 1024)).toStringAsFixed(2)} جيجابايت';
}

String _mimeType(http.Response response) =>
    (response.headers['content-type'] ?? '').split(';').first.trim().toLowerCase();

bool _hasPngSignature(List<int> bytes) =>
    bytes.length >= 8 &&
    bytes[0] == 0x89 && bytes[1] == 0x50 && bytes[2] == 0x4E &&
    bytes[3] == 0x47 && bytes[4] == 0x0D && bytes[5] == 0x0A &&
    bytes[6] == 0x1A && bytes[7] == 0x0A;

bool _hasJpegSignature(List<int> bytes) =>
    bytes.length >= 3 && bytes[0] == 0xFF &&
    bytes[1] == 0xD8 && bytes[2] == 0xFF;

Future<bool> _hasMp4Signature(File file) async {
  RandomAccessFile? handle;
  try {
    handle = await file.open(mode: FileMode.read);
    final header = await handle.read(12);
    return header.length >= 8 &&
        String.fromCharCodes(header.sublist(4, 8)) == 'ftyp';
  } on FileSystemException {
    return false;
  } finally {
    await handle?.close();
  }
}

void main() {
  runApp(const MohtarifAI());
}

Future<Map<String, String>> apiHeaders() async {
  final prefs = await SharedPreferences.getInstance();
  final key = (prefs.getString('api_key') ?? '').trim();
  return key.isEmpty ? <String, String>{} : <String, String>{'X-API-Key': key};
}

class MohtarifAI extends StatelessWidget {
  const MohtarifAI({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'المحترف في AI',
      theme: ThemeData(
        brightness: Brightness.dark,
        scaffoldBackgroundColor: const Color(0xFF10121D),
        colorScheme: ColorScheme.fromSeed(
          seedColor: const Color(0xFF8B5CF6),
          brightness: Brightness.dark,
        ),
        useMaterial3: true,
      ),
      home: const HomeScreen(),
    );
  }
}

// الشاشة الرئيسية

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  int selectedIndex = 0;

  final List<Widget> pages = const [
    HomePage(),
    MyWorksPage(),
    SettingsPage(),
  ];

  @override
  Widget build(BuildContext context) {
    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        body: pages[selectedIndex],
        bottomNavigationBar: NavigationBar(
          selectedIndex: selectedIndex,
          backgroundColor: const Color(0xFF191B2B),
          indicatorColor: const Color(0xFF7048C8),
          onDestinationSelected: (index) {
            setState(() => selectedIndex = index);
          },
          destinations: const [
            NavigationDestination(
              icon: Icon(Icons.home_outlined),
              selectedIcon: Icon(Icons.home),
              label: 'الرئيسية',
            ),
            NavigationDestination(
              icon: Icon(Icons.folder_outlined),
              selectedIcon: Icon(Icons.folder),
              label: 'أعمالي',
            ),
            NavigationDestination(
              icon: Icon(Icons.settings_outlined),
              selectedIcon: Icon(Icons.settings),
              label: 'الإعدادات',
            ),
          ],
        ),
      ),
    );
  }
}

// الصفحة الرئيسية

class HomePage extends StatelessWidget {
  const HomePage({super.key});

  final List<Map<String, dynamic>> tools = const [
    {
      'name': 'تبديل الوجوه',
      'description': 'تبديل الوجوه في الصور',
      'icon': Icons.face_retouching_natural,
      'color': Color(0xFF8B5CF6),
      'type': 'faceswap',
    },
    {
      'name': 'استوديو الفيديو',
      'description': 'إنشاء وتعديل فيديوهات AI',
      'icon': Icons.movie_creation,
      'color': Color(0xFFEC4899),
      'type': 'video',
    },
    {
      'name': 'استنساخ الأصوات',
      'description': 'إنشاء أصوات والتحكم فيها',
      'icon': Icons.record_voice_over,
      'color': Color(0xFF06B6D4),
      'type': 'voice',
    },
    {
      'name': 'تغيير الأصوات',
      'description': 'المصرية والإنجليزية',
      'icon': Icons.graphic_eq,
      'color': Color(0xFF10B981),
      'type': 'changevoice',
    },
    {
      'name': 'صناعة الأغاني',
      'description': 'إنشاء أغاني بالذكاء الاصطناعي',
      'icon': Icons.music_note,
      'color': Color(0xFFF59E0B),
      'type': 'music',
    },
    {
      'name': 'تحسين الصور',
      'description': 'رفع الجودة وإزالة العيوب',
      'icon': Icons.auto_awesome,
      'color': Color(0xFF3B82F6),
      'type': 'enhance',
    },
  ];

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: CustomScrollView(
        slivers: [
          SliverToBoxAdapter(
            child: Padding(
              padding: const EdgeInsets.all(20),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text(
                    'المحترف في AI',
                    style: TextStyle(
                      fontSize: 28,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  const SizedBox(height: 8),
                  const Text(
                    'عالمك الإبداعي بين إيديك',
                    style: TextStyle(
                      color: Colors.white60,
                      fontSize: 16,
                    ),
                  ),
                  const SizedBox(height: 25),
                  Container(
                    width: double.infinity,
                    padding: const EdgeInsets.all(22),
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(22),
                      gradient: const LinearGradient(
                        colors: [
                          Color(0xFF7048C8),
                          Color(0xFF252A55),
                        ],
                      ),
                    ),
                    child: const Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Icon(Icons.auto_awesome, size: 35),
                        SizedBox(height: 12),
                        Text(
                          'استوديو الذكاء الاصطناعي',
                          style: TextStyle(
                            fontSize: 21,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                        SizedBox(height: 7),
                        Text(
                          'اصنع صورك وفيديوهاتك وأصواتك بطريقتك.',
                          style: TextStyle(fontSize: 14),
                        ),
                      ],
                    ),
                  ),
                  const SizedBox(height: 28),
                  const Text(
                    'أدواتك الإبداعية',
                    style: TextStyle(
                      fontSize: 21,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  const SizedBox(height: 16),
                ],
              ),
            ),
          ),
          SliverPadding(
            padding: const EdgeInsets.symmetric(horizontal: 16),
            sliver: SliverGrid(
              delegate: SliverChildBuilderDelegate(
                (context, index) {
                  final tool = tools[index];

                  return InkWell(
                    borderRadius: BorderRadius.circular(20),
                    onTap: () {
                      openTool(context, tool['type']);
                    },
                    child: Container(
                      padding: const EdgeInsets.all(16),
                      decoration: BoxDecoration(
                        color: const Color(0xFF1B1E2E),
                        borderRadius: BorderRadius.circular(20),
                        border: Border.all(color: Colors.white10),
                      ),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Icon(
                            tool['icon'],
                            color: tool['color'],
                            size: 35,
                          ),
                          const Spacer(),
                          Text(
                            tool['name'],
                            style: const TextStyle(
                              fontWeight: FontWeight.bold,
                              fontSize: 16,
                            ),
                          ),
                          const SizedBox(height: 6),
                          Text(
                            tool['description'],
                            style: const TextStyle(
                              color: Colors.white54,
                              fontSize: 11,
                            ),
                          ),
                        ],
                      ),
                    ),
                  );
                },
                childCount: tools.length,
              ),
              gridDelegate:
                  const SliverGridDelegateWithFixedCrossAxisCount(
                crossAxisCount: 2,
                mainAxisSpacing: 14,
                crossAxisSpacing: 14,
                childAspectRatio: 1.12,
              ),
            ),
          ),
          const SliverToBoxAdapter(
            child: SizedBox(height: 30),
          ),
        ],
      ),
    );
  }

  void openTool(BuildContext context, String type) {
    if (type == 'faceswap') {
      Navigator.push(
        context,
        MaterialPageRoute(
          builder: (_) => const FaceSwapStudio(),
        ),
      );
    } else if (type == 'enhance') {
      Navigator.push(
        context,
        MaterialPageRoute(
          builder: (_) => const ImageStudio(enhance: true),
        ),
      );
    } else if (type == 'video') {
      Navigator.push(
        context,
        MaterialPageRoute(builder: (_) => const VideoStudio()),
      );
    } else if (type == 'voice' || type == 'changevoice' || type == 'music') {
      Navigator.push(
        context,
        MaterialPageRoute(builder: (_) => AudioToolStudio(mode: type)),
      );
    }
  }
}

// استوديو تبديل الوجوه

class FaceSwapStudio extends StatefulWidget {
  const FaceSwapStudio({super.key});

  @override
  State<FaceSwapStudio> createState() => _FaceSwapStudioState();
}

class _FaceSwapStudioState extends State<FaceSwapStudio> {
  final ImagePicker picker = ImagePicker();
  File? sourceFace;
  File? targetImage;
  File? resultImage;
  bool processing = false;

  Future<void> selectImage(bool isFace) async {
    try {
      final XFile? file = await picker.pickImage(
        source: ImageSource.gallery,
        imageQuality: 100,
      );
      if (file == null) return;
      setState(() {
        if (isFace) {
          sourceFace = File(file.path);
        } else {
          targetImage = File(file.path);
        }
        resultImage = null;
      });
    } catch (_) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('تعذر اختيار الصورة')),
      );
    }
  }

  Future<void> runFaceSwap() async {
    if (sourceFace == null || targetImage == null || processing) return;
    final prefs = await SharedPreferences.getInstance();
    final baseUrl = (prefs.getString('api_base_url') ?? '').trim();
    if (baseUrl.isEmpty) {
      if (!mounted) return;
      await showDialog<void>(
        context: context,
        builder: (dialogContext) => AlertDialog(
          title: const Text('إعداد خادم المعالجة مطلوب'),
          content: const Text('تم اختيار الصورتين بنجاح، لكن لا يوجد خادم معالجة مرتبط بالتطبيق حتى الآن. افتح الإعدادات وأضف رابط خادمك الخاص، ثم اختبر الاتصال. بدون خادم جاهز لن يبدأ تبديل الوجه.'),
          actions: [
            TextButton(onPressed: () => Navigator.pop(dialogContext), child: const Text('حسنًا')),
          ],
        ),
      );
      return;
    }

    setState(() => processing = true);
    try {
      final uri = Uri.parse('${baseUrl.replaceAll(RegExp(r'/+$'), '')}/api/faceswap');
      final request = http.MultipartRequest('POST', uri)
        ..headers.addAll(await apiHeaders())
        ..files.add(await http.MultipartFile.fromPath('source', sourceFace!.path))
        ..files.add(await http.MultipartFile.fromPath('target', targetImage!.path));
      final streamed = await request.send().timeout(const Duration(minutes: 6));
      final response = await http.Response.fromStream(streamed);
      if (response.statusCode != 200) {
        String message = 'فشلت المعالجة (${response.statusCode})';
        try {
          message = (response.bodyBytes.isNotEmpty)
              ? (response.body.contains('detail') ? response.body : message)
              : message;
        } catch (_) {}
        throw Exception(message);
      }
      if (_mimeType(response) != 'image/png' || !_hasPngSignature(response.bodyBytes)) {
        throw Exception('الخادم لم يُرجع صورة PNG سليمة؛ لم يتم حفظ الاستجابة');
      }
      final directory = await getApplicationDocumentsDirectory();
      final output = File('${directory.path}/faceswap_${DateTime.now().millisecondsSinceEpoch}.png');
      await output.writeAsBytes(response.bodyBytes, flush: true);
      if (!mounted) return;
      setState(() => resultImage = output);
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('تمت المعالجة وحفظ النتيجة داخل التطبيق')),
      );
    } catch (error) {
      if (!mounted) return;
      await showDialog<void>(
        context: context,
        builder: (dialogContext) => AlertDialog(
          title: const Text('تعذر تنفيذ تبديل الوجه'),
          content: SingleChildScrollView(child: SelectableText(error.toString())),
          actions: [
            TextButton(onPressed: () => Navigator.pop(dialogContext), child: const Text('إغلاق')),
          ],
        ),
      );
    } finally {
      if (mounted) setState(() => processing = false);
    }
  }

  Widget imageBox({
    required String title,
    required File? image,
    required VoidCallback onTap,
  }) {
    return Expanded(
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(20),
        child: Container(
          height: 220,
          decoration: BoxDecoration(
            color: const Color(0xFF1B1E2E),
            borderRadius: BorderRadius.circular(20),
            border: Border.all(color: Colors.white24),
          ),
          child: Column(
            children: [
              Expanded(
                child: image == null
                    ? const Center(child: Icon(Icons.add_photo_alternate, size: 55, color: Color(0xFF9B7BFA)))
                    : ClipRRect(
                        borderRadius: BorderRadius.circular(20),
                        child: Image.file(image, width: double.infinity, fit: BoxFit.cover),
                      ),
              ),
              Padding(
                padding: const EdgeInsets.all(12),
                child: Text(title, style: const TextStyle(fontWeight: FontWeight.bold)),
              ),
            ],
          ),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('استوديو تبديل الوجوه')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          const Text('اختر الوجه والصورة المستهدفة', textAlign: TextAlign.center,
              style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
          const SizedBox(height: 8),
          const Text('صورة الوجه الذي تريد استخدامه، ثم الصورة التي تريد تبديل الوجه فيها.',
              textAlign: TextAlign.center, style: TextStyle(color: Colors.white60)),
          const SizedBox(height: 22),
          Row(children: [
            imageBox(title: 'الوجه الأصلي', image: sourceFace, onTap: () => selectImage(true)),
            const SizedBox(width: 12),
            imageBox(title: 'الصورة المستهدفة', image: targetImage, onTap: () => selectImage(false)),
          ]),
          const SizedBox(height: 22),
          SizedBox(
            width: double.infinity,
            child: ElevatedButton.icon(
              onPressed: sourceFace != null && targetImage != null && !processing ? runFaceSwap : null,
              icon: processing
                  ? const SizedBox(width: 18, height: 18, child: CircularProgressIndicator(strokeWidth: 2))
                  : const Icon(Icons.auto_awesome),
              label: Text(processing ? 'جارٍ تنفيذ المعالجة...' : 'ابدأ تبديل الوجه'),
              style: ElevatedButton.styleFrom(
                backgroundColor: const Color(0xFF7048C8), foregroundColor: Colors.white,
                padding: const EdgeInsets.all(18)),
            ),
          ),
          if (resultImage != null) ...[
            const SizedBox(height: 24),
            const Text('النتيجة', textAlign: TextAlign.center,
                style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
            const SizedBox(height: 12),
            ClipRRect(borderRadius: BorderRadius.circular(18),
                child: Image.file(resultImage!, fit: BoxFit.contain)),
            const SizedBox(height: 8),
            const Text('تم حفظ الصورة داخل مساحة التطبيق.',
                textAlign: TextAlign.center, style: TextStyle(color: Colors.white60)),
          ],
          const SizedBox(height: 16),
          const Text('تحتاج هذه الأداة إلى خادم معالجة فعلي مضبوط من صفحة الإعدادات.',
              textAlign: TextAlign.center, style: TextStyle(color: Colors.white54, fontSize: 12)),
        ],
      ),
    );
  }
}

// استوديو تبديل الوجوه في الفيديو

class VideoStudio extends StatefulWidget {
  const VideoStudio({super.key});

  @override
  State<VideoStudio> createState() => _VideoStudioState();
}

class _VideoStudioState extends State<VideoStudio> {
  final ImagePicker picker = ImagePicker();
  File? sourceFace;
  File? targetVideo;
  File? resultVideo;
  VideoPlayerController? resultController;
  bool processing = false;
  String jobMessage = '';
  String? savedJobId;
  String? savedJobBaseUrl;

  @override
  void initState() {
    super.initState();
    _restorePendingJob();
  }

  Future<void> _restorePendingJob() async {
    final prefs = await SharedPreferences.getInstance();
    final id = prefs.getString('pending_video_job_id');
    final base = prefs.getString('pending_video_job_base_url');
    if (!mounted || id == null || base == null || id.isEmpty || base.isEmpty) return;
    setState(() { savedJobId = id; savedJobBaseUrl = base; jobMessage = 'توجد مهمة فيديو سابقة يمكن استعادتها'; });
  }

  Future<void> _clearPendingJob() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.remove('pending_video_job_id');
    await prefs.remove('pending_video_job_base_url');
    if (mounted) setState(() { savedJobId = null; savedJobBaseUrl = null; });
  }

  Future<void> pickSource() async {
    final file = await picker.pickImage(source: ImageSource.gallery, imageQuality: 100);
    if (file != null && mounted) setState(() => sourceFace = File(file.path));
  }

  Future<void> pickTargetVideo() async {
    final file = await picker.pickVideo(source: ImageSource.gallery);
    if (file != null && mounted) {
      await resultController?.dispose();
      resultController = null;
      setState(() { targetVideo = File(file.path); resultVideo = null; });
    }
  }

  Future<void> processVideo() async {
    if (sourceFace == null || targetVideo == null || processing) return;
    final prefs = await SharedPreferences.getInstance();
    final baseUrl = (prefs.getString('api_base_url') ?? '').trim().replaceAll(RegExp(r'/+$'), '');
    if (baseUrl.isEmpty) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('أضف عنوان خادم المعالجة من الإعدادات أولاً')),
      );
      return;
    }

    setState(() {
      processing = true;
      jobMessage = 'جارٍ رفع الفيديو إلى الخادم...';
    });
    try {
      final createUri = Uri.parse('$baseUrl/api/jobs/faceswap/video');
      final request = http.MultipartRequest('POST', createUri)
        ..headers.addAll(await apiHeaders())
        ..files.add(await http.MultipartFile.fromPath('source', sourceFace!.path))
        ..files.add(await http.MultipartFile.fromPath('target', targetVideo!.path));
      final streamed = await request.send().timeout(const Duration(minutes: 8));
      final createResponse = await http.Response.fromStream(streamed);
      if (createResponse.statusCode != 202) {
        throw Exception(_apiError(createResponse.body, createResponse.statusCode));
      }
      final created = jsonDecode(createResponse.body) as Map<String, dynamic>;
      final jobId = created['job_id'] as String?;
      if (jobId == null || jobId.isEmpty) throw Exception('الخادم لم يرجع رقم مهمة صالحاً');
      final jobPrefs = await SharedPreferences.getInstance();
      await jobPrefs.setString('pending_video_job_id', jobId);
      await jobPrefs.setString('pending_video_job_base_url', baseUrl);
      if (mounted) setState(() { savedJobId = jobId; savedJobBaseUrl = baseUrl; });

      Map<String, dynamic>? status;
      for (var attempt = 0; attempt < 800; attempt++) {
        await Future<void>.delayed(const Duration(seconds: 3));
        final statusResponse = await http.get(
          Uri.parse('$baseUrl/api/jobs/$jobId'),
          headers: await apiHeaders(),
        ).timeout(const Duration(seconds: 30));
        if (statusResponse.statusCode != 200) {
          throw Exception(_apiError(statusResponse.body, statusResponse.statusCode));
        }
        final currentStatus = jsonDecode(statusResponse.body) as Map<String, dynamic>;
        status = currentStatus;
        if (!mounted) return;
        setState(() {
          jobMessage = currentStatus['message']?.toString() ?? 'جارٍ المعالجة...';
        });
        if (currentStatus['status'] == 'completed') break;
        if (currentStatus['status'] == 'failed') {
          await _clearPendingJob();
          throw Exception(currentStatus['message'] ?? 'فشلت معالجة الفيديو');
        }
      }
      if (status == null || status['status'] != 'completed') {
        throw Exception('استغرقت المعالجة وقتاً أطول من المتوقع؛ يمكنك إعادة فتح التطبيق والتحقق من حالة الخادم لاحقاً.');
      }

      setState(() => jobMessage = 'اكتملت المعالجة، جارٍ تنزيل النتيجة...');
      final directory = await getApplicationDocumentsDirectory();
      final output = File('${directory.path}/faceswap_video_${DateTime.now().millisecondsSinceEpoch}.mp4');
      final downloadClient = http.Client();
      final sink = output.openWrite();
      try {
        final downloadRequest = http.Request(
          'GET', Uri.parse('$baseUrl/api/jobs/$jobId/result'),
        )..headers.addAll(await apiHeaders());
        final streamedResult = await downloadClient.send(downloadRequest)
            .timeout(const Duration(minutes: 10));
        if (streamedResult.statusCode != 200) {
          final errorBody = await streamedResult.stream.bytesToString();
          throw Exception(_apiError(errorBody, streamedResult.statusCode));
        }
        final resultMime = (streamedResult.headers['content-type'] ?? '')
            .split(';').first.trim().toLowerCase();
        if (resultMime != 'video/mp4') {
          throw Exception('نوع ملف النتيجة غير متوقع: ${resultMime.isEmpty ? "غير معروف" : resultMime}');
        }
        var downloadedBytes = 0;
        await for (final chunk in streamedResult.stream) {
          sink.add(chunk);
          downloadedBytes += chunk.length;
          final totalBytes = streamedResult.contentLength ?? 0;
          if (mounted && totalBytes > 0) {
            final percent = (downloadedBytes * 100 / totalBytes).clamp(0, 100).round();
            setState(() => jobMessage = 'جارٍ تنزيل النتيجة: $percent%');
          }
        }
        await sink.flush();
      } catch (_) {
        await sink.close();
        if (await output.exists()) await output.delete();
        rethrow;
      } finally {
        await sink.close();
        downloadClient.close();
      }
      final validMp4 = await _hasMp4Signature(output);
      if (!validMp4) {
        if (await output.exists()) await output.delete();
        throw Exception('ملف النتيجة لا يبدو فيديو MP4 صالحاً؛ تم حذف الملف التالف');
      }
      final controller = VideoPlayerController.file(output);
      await controller.initialize();
      await resultController?.dispose();
      if (!mounted) { await controller.dispose(); return; }
      setState(() {
        resultVideo = output;
        resultController = controller;
        jobMessage = 'اكتملت معالجة الفيديو';
      });
      await _clearPendingJob();
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('اكتملت المعالجة وحُفظ الفيديو داخل التطبيق')),
      );
    } catch (error) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('تعذرت معالجة الفيديو: $error')),
      );
    } finally {
      if (mounted) setState(() => processing = false);
    }
  }

  Future<void> resumeSavedJob() async {
    final jobId = savedJobId;
    final baseUrl = savedJobBaseUrl;
    if (jobId == null || baseUrl == null || processing) return;
    setState(() { processing = true; jobMessage = 'جارٍ استعادة المهمة السابقة...'; });
    try {
      Map<String, dynamic>? status;
      for (var attempt = 0; attempt < 800; attempt++) {
        final response = await http.get(Uri.parse('$baseUrl/api/jobs/$jobId'), headers: await apiHeaders())
            .timeout(const Duration(seconds: 30));
        if (response.statusCode == 404) throw Exception('المهمة غير موجودة على الخادم؛ ربما انتهت مدة الاحتفاظ بها');
        if (response.statusCode != 200) throw Exception(_apiError(response.body, response.statusCode));
        status = jsonDecode(response.body) as Map<String, dynamic>;
        if (!mounted) return;
        setState(() => jobMessage = status?['message']?.toString() ?? 'جارٍ استكمال المهمة...');
        if (status?['status'] == 'completed') break;
        if (status?['status'] == 'failed') {
          await _clearPendingJob();
          throw Exception(status?['message'] ?? 'فشلت المهمة السابقة');
        }
        await Future<void>.delayed(const Duration(seconds: 3));
      }
      if (status?['status'] != 'completed') throw Exception('المهمة ما زالت قيد التنفيذ؛ حاول الاستعادة لاحقاً');
      setState(() => jobMessage = 'اكتملت المهمة، جارٍ تنزيل الفيديو...');
      final outputDir = await getApplicationDocumentsDirectory();
      final output = File('${outputDir.path}/faceswap_video_${DateTime.now().millisecondsSinceEpoch}.mp4');
      final client = http.Client();
      final sink = output.openWrite();
      try {
        final request = http.Request('GET', Uri.parse('$baseUrl/api/jobs/$jobId/result'))
          ..headers.addAll(await apiHeaders());
        final response = await client.send(request).timeout(const Duration(minutes: 10));
        if (response.statusCode != 200) throw Exception(_apiError(await response.stream.bytesToString(), response.statusCode));
        final mime = (response.headers['content-type'] ?? '').split(';').first.trim().toLowerCase();
        if (mime != 'video/mp4') throw Exception('نوع ملف النتيجة غير متوقع');
        await for (final chunk in response.stream) { sink.add(chunk); }
        await sink.flush();
      } catch (_) {
        await sink.close();
        if (await output.exists()) await output.delete();
        rethrow;
      } finally {
        await sink.close();
        client.close();
      }
      if (!await _hasMp4Signature(output)) {
        if (await output.exists()) await output.delete();
        throw Exception('ملف الفيديو المستعاد تالف');
      }
      final controller = VideoPlayerController.file(output);
      await controller.initialize();
      await resultController?.dispose();
      if (!mounted) { await controller.dispose(); return; }
      setState(() { resultVideo = output; resultController = controller; jobMessage = 'تم استرجاع الفيديو وحفظه'; });
      await _clearPendingJob();
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('تم استرجاع نتيجة المهمة السابقة')));
    } catch (error) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('تعذر استرجاع المهمة: $error')));
    } finally {
      if (mounted) setState(() => processing = false);
    }
  }

  String _apiError(String body, int statusCode) {
    try {
      final decoded = jsonDecode(body);
      if (decoded is Map && decoded['detail'] != null) return decoded['detail'].toString();
    } catch (_) {}
    return body.isNotEmpty ? body : 'استجابة الخادم: $statusCode';
  }

  @override
  void dispose() {
    resultController?.dispose();
    super.dispose();
  }

  Widget selectCard(String title, IconData icon, VoidCallback action, {String? filename}) {
    return Card(
      color: const Color(0xFF1B1E2E),
      child: ListTile(
        leading: Icon(icon, color: const Color(0xFF9B7BFA), size: 32),
        title: Text(title),
        subtitle: Text(filename ?? 'لم يتم الاختيار', maxLines: 1, overflow: TextOverflow.ellipsis),
        trailing: const Icon(Icons.add_circle_outline),
        onTap: action,
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('استوديو تبديل الوجوه بالفيديو')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          const Text('فيديو بدون حد زمني برمجي', textAlign: TextAlign.center,
              style: TextStyle(fontSize: 21, fontWeight: FontWeight.bold)),
          const SizedBox(height: 8),
          const Text('اختر صورة الوجه ثم الفيديو المستهدف. الخادم يتحقق من سلامة الملف والصيغة قبل المعالجة.',
              textAlign: TextAlign.center, style: TextStyle(color: Colors.white60)),
          const SizedBox(height: 18),
          selectCard('صورة الوجه الأصلي', Icons.face, pickSource, filename: sourceFace?.path.split(Platform.pathSeparator).last),
          selectCard('الفيديو المستهدف', Icons.video_library, pickTargetVideo, filename: targetVideo?.path.split(Platform.pathSeparator).last),
          const SizedBox(height: 14),
          SizedBox(
            width: double.infinity,
            child: ElevatedButton.icon(
              onPressed: sourceFace != null && targetVideo != null && !processing && savedJobId == null ? processVideo : null,
              icon: processing
                  ? const SizedBox(width: 18, height: 18, child: CircularProgressIndicator(strokeWidth: 2))
                  : const Icon(Icons.movie_filter),
              label: Text(processing ? 'جارٍ معالجة الفيديو...' : 'ابدأ تبديل الوجه بالفيديو'),
              style: ElevatedButton.styleFrom(backgroundColor: const Color(0xFF7048C8),
                  foregroundColor: Colors.white, padding: const EdgeInsets.all(18)),
            ),
          ),
          if (savedJobId != null && !processing) ...[
            const SizedBox(height: 10),
            OutlinedButton.icon(
              onPressed: resumeSavedJob,
              icon: const Icon(Icons.restore),
              label: const Text('استعادة المهمة السابقة'),
            ),
          ],
          if (processing) ...[
            const SizedBox(height: 16),
            const LinearProgressIndicator(),
            const SizedBox(height: 8),
            Text(jobMessage, textAlign: TextAlign.center,
                style: const TextStyle(color: Colors.white70)),
          ],
          if (resultVideo != null && resultController != null) ...[
            const SizedBox(height: 22),
            const Text('الفيديو الناتج', textAlign: TextAlign.center,
                style: TextStyle(fontSize: 19, fontWeight: FontWeight.bold)),
            const SizedBox(height: 10),
            AspectRatio(
              aspectRatio: resultController!.value.aspectRatio,
              child: VideoPlayer(resultController!),
            ),
            IconButton(
              onPressed: () => setState(() {
                resultController!.value.isPlaying ? resultController!.pause() : resultController!.play();
              }),
              icon: Icon(resultController!.value.isPlaying ? Icons.pause_circle : Icons.play_circle, size: 42),
            ),
          ],
          const SizedBox(height: 12),
          const Text('يتطلب خادماً مجهزاً بمحرك FaceFusion. سرعة المعالجة تعتمد على موارد الخادم، ودعم GPU غير مفعّل تلقائياً في الإعداد الحالي.',
              textAlign: TextAlign.center, style: TextStyle(color: Colors.white54, fontSize: 12)),
        ],
      ),
    );
  }
}

// استوديو الصور وتحسينها

class ImageStudio extends StatefulWidget {
  final bool enhance;

  const ImageStudio({super.key, this.enhance = false});

  @override
  State<ImageStudio> createState() => _ImageStudioState();
}

class _ImageStudioState extends State<ImageStudio> {
  File? selectedImage;
  File? resultImage;
  bool processing = false;
  final ImagePicker picker = ImagePicker();

  Future<void> pickImage(ImageSource source) async {
    try {
      final XFile? image = await picker.pickImage(source: source, imageQuality: 100);
      if (image != null && mounted) {
        setState(() {
          selectedImage = File(image.path);
          resultImage = null;
        });
      }
    } catch (_) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('تعذر فتح الصورة')),
      );
    }
  }

  Future<void> enhanceImage() async {
    if (selectedImage == null || processing) return;
    final prefs = await SharedPreferences.getInstance();
    final baseUrl = (prefs.getString('api_base_url') ?? '').trim();
    if (baseUrl.isEmpty) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('أضف عنوان خادم المعالجة من الإعدادات أولاً')),
      );
      return;
    }
    setState(() => processing = true);
    try {
      final uri = Uri.parse('${baseUrl.replaceAll(RegExp(r'/+$'), '')}/api/enhance');
      final request = http.MultipartRequest('POST', uri)
        ..headers.addAll(await apiHeaders())
        ..files.add(await http.MultipartFile.fromPath('image', selectedImage!.path));
      final streamed = await request.send().timeout(const Duration(minutes: 5));
      final response = await http.Response.fromStream(streamed);
      if (response.statusCode != 200) {
        throw Exception(response.body.isNotEmpty ? response.body : 'فشل تحسين الصورة (${response.statusCode})');
      }
      if (_mimeType(response) != 'image/jpeg' || !_hasJpegSignature(response.bodyBytes)) {
        throw Exception('الخادم لم يُرجع صورة JPEG سليمة؛ لم يتم حفظ الاستجابة');
      }
      final directory = await getApplicationDocumentsDirectory();
      final output = File('${directory.path}/enhanced_${DateTime.now().millisecondsSinceEpoch}.jpg');
      await output.writeAsBytes(response.bodyBytes, flush: true);
      if (!mounted) return;
      setState(() => resultImage = output);
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('تم تحسين الصورة وحفظ النسخة الجديدة داخل التطبيق')),
      );
    } catch (error) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('تعذر تحسين الصورة: $error')),
      );
    } finally {
      if (mounted) setState(() => processing = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final displayedImage = resultImage ?? selectedImage;
    return Scaffold(
      appBar: AppBar(title: Text(widget.enhance ? 'تحسين الصور' : 'استوديو الصور')),
      body: ListView(
        padding: const EdgeInsets.all(20),
        children: [
          Container(
            height: 330,
            width: double.infinity,
            decoration: BoxDecoration(
              color: const Color(0xFF1B1E2E),
              borderRadius: BorderRadius.circular(22),
              border: Border.all(color: Colors.white12),
            ),
            child: displayedImage == null
                ? const Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Icon(Icons.add_photo_alternate_outlined, size: 75, color: Color(0xFF9B7BFA)),
                      SizedBox(height: 18),
                      Text('اختر صورة للبدء', style: TextStyle(fontSize: 18)),
                      SizedBox(height: 8),
                      Text('يمكنك اختيار صورة من هاتفك', style: TextStyle(color: Colors.white54)),
                    ],
                  )
                : ClipRRect(
                    borderRadius: BorderRadius.circular(22),
                    child: Image.file(displayedImage, width: double.infinity, fit: BoxFit.contain),
                  ),
          ),
          if (resultImage != null) ...[
            const SizedBox(height: 10),
            const Text('النسخة المحسّنة', textAlign: TextAlign.center,
                style: TextStyle(color: Color(0xFF9B7BFA), fontWeight: FontWeight.bold)),
          ],
          const SizedBox(height: 20),
          ElevatedButton.icon(
            onPressed: processing ? null : () => pickImage(ImageSource.gallery),
            icon: const Icon(Icons.photo_library),
            label: const Text('اختيار صورة من المعرض'),
            style: ElevatedButton.styleFrom(padding: const EdgeInsets.all(17),
                backgroundColor: const Color(0xFF7048C8), foregroundColor: Colors.white),
          ),
          const SizedBox(height: 12),
          OutlinedButton.icon(
            onPressed: processing ? null : () => pickImage(ImageSource.camera),
            icon: const Icon(Icons.camera_alt),
            label: const Text('التقاط صورة بالكاميرا'),
            style: OutlinedButton.styleFrom(padding: const EdgeInsets.all(17)),
          ),
          if (widget.enhance && selectedImage != null) ...[
            const SizedBox(height: 12),
            FilledButton.icon(
              onPressed: processing ? null : enhanceImage,
              icon: processing
                  ? const SizedBox(width: 18, height: 18, child: CircularProgressIndicator(strokeWidth: 2))
                  : const Icon(Icons.auto_awesome),
              label: Text(processing ? 'جارٍ تحسين الصورة...' : 'ابدأ تحسين الصورة'),
            ),
            const SizedBox(height: 8),
            const Text('التحسين الحالي ضبط ألوان وتباين وحدّة الصورة، وليس ترميماً عميقاً بالذكاء الاصطناعي.',
                textAlign: TextAlign.center, style: TextStyle(color: Colors.white54, fontSize: 12)),
          ],
          if (selectedImage != null) ...[
            const SizedBox(height: 8),
            TextButton.icon(
              onPressed: processing ? null : () => setState(() { selectedImage = null; resultImage = null; }),
              icon: const Icon(Icons.delete_outline),
              label: const Text('إزالة الصورة'),
            ),
          ],
        ],
      ),
    );
  }
}

// استوديو الصوت والأغاني - تشغيل محلي على خادم المستخدم دون APIs مدفوعة.
class AudioToolStudio extends StatefulWidget {
  final String mode;
  const AudioToolStudio({super.key, required this.mode});

  @override
  State<AudioToolStudio> createState() => _AudioToolStudioState();
}

class _AudioToolStudioState extends State<AudioToolStudio> {
  String? firstAudioPath;
  String? secondAudioPath;
  final textController = TextEditingController();
  final promptController = TextEditingController();
  final lyricsController = TextEditingController();
  final durationController = TextEditingController(text: '60');
  bool consentConfirmed = false;
  bool processing = false;
  String statusMessage = '';

  String get title => widget.mode == 'voice'
      ? 'استنساخ الصوت'
      : widget.mode == 'changevoice'
          ? 'تغيير الصوت'
          : 'صناعة الأغاني';

  @override
  void dispose() {
    textController.dispose();
    promptController.dispose();
    lyricsController.dispose();
    durationController.dispose();
    super.dispose();
  }

  Future<String?> chooseAudio() async {
    try {
      final result = await FilePicker.platform.pickFiles(
        type: FileType.audio,
        allowMultiple: false,
        withData: false,
      );
      return result?.files.single.path;
    } catch (error) {
      if (mounted) setState(() => statusMessage = 'تعذر اختيار الملف: $error');
      return null;
    }
  }

  Future<void> pickFirst() async {
    final path = await chooseAudio();
    if (path != null && mounted) setState(() => firstAudioPath = path);
  }

  Future<void> pickSecond() async {
    final path = await chooseAudio();
    if (path != null && mounted) setState(() => secondAudioPath = path);
  }

  Future<void> runAudioTool() async {
    if (processing) return;
    if (widget.mode != 'music' && firstAudioPath == null) {
      setState(() => statusMessage = 'اختار ملف الصوت الأول');
      return;
    }
    if (widget.mode == 'changevoice' && secondAudioPath == null) {
      setState(() => statusMessage = 'اختار عينة الصوت المطلوب التحويل إليه');
      return;
    }
    if (widget.mode == 'voice' && textController.text.trim().isEmpty) {
      setState(() => statusMessage = 'اكتب النص المطلوب نطقه');
      return;
    }
    if (widget.mode == 'music' && promptController.text.trim().isEmpty) {
      setState(() => statusMessage = 'اكتب وصف الأغنية');
      return;
    }
    if (widget.mode != 'music' && !consentConfirmed) {
      setState(() => statusMessage = 'أكد أن لديك حق استخدام الصوت أو إذن صاحبه');
      return;
    }
    final prefs = await SharedPreferences.getInstance();
    final baseUrl = (prefs.getString('api_base_url') ?? '').trim().replaceAll(RegExp(r'/+$'), '');
    if (baseUrl.isEmpty) {
      setState(() => statusMessage = 'أضف عنوان خادمك المحلي من الإعدادات أولاً');
      return;
    }
    setState(() { processing = true; statusMessage = 'جارٍ الاتصال بمحرك الصوت المحلي...'; });
    try {
      final endpoint = widget.mode == 'voice'
          ? '/api/audio/voice-clone'
          : widget.mode == 'changevoice'
              ? '/api/audio/voice-convert'
              : '/api/audio/music';
      final request = http.MultipartRequest('POST', Uri.parse('$baseUrl$endpoint'))
        ..headers.addAll(await apiHeaders());
      if (widget.mode == 'voice') {
        request.fields['text'] = textController.text.trim();
        request.fields['language'] = 'ar';
        request.fields['consent_confirmed'] = 'true';
        request.files.add(await http.MultipartFile.fromPath('reference_audio', firstAudioPath!));
      } else if (widget.mode == 'changevoice') {
        request.fields['consent_confirmed'] = 'true';
        request.files.add(await http.MultipartFile.fromPath('input_audio', firstAudioPath!));
        request.files.add(await http.MultipartFile.fromPath('target_voice_audio', secondAudioPath!));
      } else {
        final duration = double.tryParse(durationController.text.trim()) ?? 60;
        request.fields['prompt'] = promptController.text.trim();
        request.fields['lyrics'] = lyricsController.text.trim();
        request.fields['duration_seconds'] = duration.toString();
      }
      final streamed = await request.send().timeout(const Duration(hours: 2));
      final response = await http.Response.fromStream(streamed);
      if (response.statusCode != 200) {
        String detail = response.body;
        try {
          final decoded = jsonDecode(response.body);
          if (decoded is Map && decoded['detail'] != null) detail = decoded['detail'].toString();
        } catch (_) {}
        throw Exception(detail.isEmpty ? 'فشلت المعالجة (${response.statusCode})' : detail);
      }
      if (!_mimeType(response).startsWith('audio/')) {
        throw Exception('الخادم لم يرجع ملفًا صوتيًا صالح النوع');
      }
      final directory = await getApplicationDocumentsDirectory();
      final output = File('${directory.path}/${widget.mode}_${DateTime.now().millisecondsSinceEpoch}.wav');
      await output.writeAsBytes(response.bodyBytes, flush: true);
      if (!mounted) return;
      setState(() => statusMessage = 'تم إنشاء الملف وحفظه داخل أعمالي الصوتية: ${output.path.split(Platform.pathSeparator).last}');
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('تم حفظ الملف الصوتي داخل التطبيق')));
    } catch (error) {
      if (mounted) setState(() => statusMessage = 'تعذر التنفيذ: $error');
    } finally {
      if (mounted) setState(() => processing = false);
    }
  }

  Widget audioPicker(String label, String? path, VoidCallback onTap) =>
      OutlinedButton.icon(
        onPressed: processing ? null : onTap,
        icon: const Icon(Icons.audio_file),
        label: Text(path == null ? label : path.split(Platform.pathSeparator).last,
            maxLines: 1, overflow: TextOverflow.ellipsis),
      );

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text(title)),
      body: ListView(padding: const EdgeInsets.all(20), children: [
        const Icon(Icons.graphic_eq, size: 64, color: Color(0xFF9B7BFA)),
        const SizedBox(height: 12),
        Text(title, textAlign: TextAlign.center,
            style: const TextStyle(fontSize: 23, fontWeight: FontWeight.bold)),
        const SizedBox(height: 8),
        const Text('المعالجة تتم على خادمك المحلي فقط؛ لا توجد خدمات مدفوعة أو إرسال إلى APIs خارجية.',
            textAlign: TextAlign.center, style: TextStyle(color: Colors.white60)),
        const SizedBox(height: 22),
        if (widget.mode == 'voice') ...[
          audioPicker('اختيار عينة صوتية مرجعية', firstAudioPath, pickFirst),
          const SizedBox(height: 12),
          TextField(controller: textController, minLines: 3, maxLines: 6,
              decoration: const InputDecoration(labelText: 'النص المطلوب نطقه', border: OutlineInputBorder())),
        ] else if (widget.mode == 'changevoice') ...[
          audioPicker('اختيار التسجيل المراد تحويله', firstAudioPath, pickFirst),
          const SizedBox(height: 12),
          audioPicker('اختيار عينة الصوت المستهدف', secondAudioPath, pickSecond),
        ] else ...[
          TextField(controller: promptController, minLines: 2, maxLines: 4,
              decoration: const InputDecoration(labelText: 'وصف الأغنية: النوع، الإيقاع، الآلات، الجو العام', border: OutlineInputBorder())),
          const SizedBox(height: 12),
          TextField(controller: lyricsController, minLines: 4, maxLines: 10,
              decoration: const InputDecoration(labelText: 'كلمات الأغنية (اختياري)', border: OutlineInputBorder())),
          const SizedBox(height: 12),
          TextField(controller: durationController, keyboardType: TextInputType.number,
              decoration: const InputDecoration(labelText: 'المدة بالثواني', border: OutlineInputBorder())),
        ],
        if (widget.mode != 'music') ...[
          const SizedBox(height: 14),
          CheckboxListTile(
            value: consentConfirmed,
            onChanged: processing ? null : (value) => setState(() => consentConfirmed = value ?? false),
            title: const Text('أؤكد أن الصوت صوتي أو لدي موافقة صريحة من صاحبه'),
            controlAffinity: ListTileControlAffinity.leading,
            contentPadding: EdgeInsets.zero,
          ),
        ],
        const SizedBox(height: 18),
        FilledButton.icon(
          onPressed: processing ? null : runAudioTool,
          icon: processing ? const SizedBox(width: 18, height: 18, child: CircularProgressIndicator(strokeWidth: 2)) : const Icon(Icons.play_arrow),
          label: Text(processing ? 'جارٍ التنفيذ...' : 'ابدأ المعالجة'),
        ),
        if (statusMessage.isNotEmpty) ...[
          const SizedBox(height: 14),
          SelectableText(statusMessage, textAlign: TextAlign.center,
              style: const TextStyle(color: Colors.white70)),
        ],
        const SizedBox(height: 20),
        const Text('تنبيه: واجهة الربط جاهزة، لكن يلزم تثبيت محرك محلي متوافق على الخادم قبل توليد الصوت فعليًا. حالة المحرك تظهر في تشخيص الخادم.',
            style: TextStyle(color: Colors.amber, fontSize: 12), textAlign: TextAlign.center),
      ]),
    );
  }
}

// الأدوات التي سيتم تطويرها

class ComingSoonPage extends StatelessWidget {
  final String title;

  const ComingSoonPage({super.key, required this.title});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text(title)),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            const Icon(
              Icons.auto_awesome,
              size: 75,
              color: Color(0xFF9B7BFA),
            ),
            const SizedBox(height: 20),
            Text(
              title,
              style: const TextStyle(
                fontSize: 23,
                fontWeight: FontWeight.bold,
              ),
            ),
            const SizedBox(height: 10),
            const Text(
              'نجهز أدوات الاستوديو الخاص بك',
              style: TextStyle(color: Colors.white60),
            ),
          ],
        ),
      ),
    );
  }
}

class SavedAudioPage extends StatefulWidget {
  final File file;
  const SavedAudioPage({super.key, required this.file});

  @override
  State<SavedAudioPage> createState() => _SavedAudioPageState();
}

class _SavedAudioPageState extends State<SavedAudioPage> {
  final AudioPlayer player = AudioPlayer();
  bool playing = false;
  Duration position = Duration.zero;
  Duration duration = Duration.zero;

  @override
  void initState() {
    super.initState();
    player.onPositionChanged.listen((value) { if (mounted) setState(() => position = value); });
    player.onDurationChanged.listen((value) { if (mounted) setState(() => duration = value); });
    player.onPlayerComplete.listen((_) { if (mounted) setState(() { playing = false; position = Duration.zero; }); });
  }

  @override
  void dispose() {
    player.dispose();
    super.dispose();
  }

  String time(Duration value) => '${value.inMinutes.remainder(60).toString().padLeft(2, '0')}:${value.inSeconds.remainder(60).toString().padLeft(2, '0')}';

  @override
  Widget build(BuildContext context) {
    final name = widget.file.uri.pathSegments.last;
    return Scaffold(
      appBar: AppBar(title: const Text('مشغل الصوت')),
      body: Center(child: Padding(
        padding: const EdgeInsets.all(24),
        child: Column(mainAxisSize: MainAxisSize.min, children: [
          const Icon(Icons.audio_file, size: 100, color: Color(0xFF9B7BFA)),
          const SizedBox(height: 18),
          Text(name, textAlign: TextAlign.center, style: const TextStyle(fontSize: 18)),
          const SizedBox(height: 20),
          Slider(
            value: duration.inMilliseconds == 0 ? 0 : position.inMilliseconds.clamp(0, duration.inMilliseconds).toDouble(),
            max: duration.inMilliseconds == 0 ? 1 : duration.inMilliseconds.toDouble(),
            onChanged: duration.inMilliseconds == 0 ? null : (value) => player.seek(Duration(milliseconds: value.round())),
          ),
          Text('${time(position)} / ${time(duration)}'),
          const SizedBox(height: 16),
          FilledButton.icon(
            onPressed: () async {
              if (playing) { await player.pause(); if (mounted) setState(() => playing = false); }
              else { await player.play(DeviceFileSource(widget.file.path)); if (mounted) setState(() => playing = true); }
            },
            icon: Icon(playing ? Icons.pause : Icons.play_arrow),
            label: Text(playing ? 'إيقاف مؤقت' : 'تشغيل'),
          ),
          const SizedBox(height: 12),
          OutlinedButton.icon(
            onPressed: () async { await player.stop(); if (context.mounted) Navigator.pop(context, true); },
            icon: const Icon(Icons.delete_outline), label: const Text('حذف الملف'),
          ),
        ]),
      )),
    );
  }
}

// صفحة أعمالي

class MyWorksPage extends StatefulWidget {
  const MyWorksPage({super.key});

  @override
  State<MyWorksPage> createState() => _MyWorksPageState();
}

class _MyWorksPageState extends State<MyWorksPage> {
  late Future<WorksSummary> worksFuture;
  final Set<String> selectedPaths = <String>{};

  @override
  void initState() {
    super.initState();
    worksFuture = loadWorks();
  }

  Future<WorksSummary> loadWorks() async {
    final directory = await getApplicationDocumentsDirectory();
    if (!await directory.exists()) return WorksSummary(<File>[], 0);
    final files = directory
        .listSync()
        .whereType<File>()
        .where((file) {
          final name = file.uri.pathSegments.last;
          return name.startsWith('faceswap_') ||
              name.startsWith('faceswap_video_') ||
              name.startsWith('enhanced_') ||
              name.startsWith('voice_') ||
              name.startsWith('changevoice_') ||
              name.startsWith('music_');
        })
        .toList()
      ..sort((a, b) => b.lastModifiedSync().compareTo(a.lastModifiedSync()));
    var totalBytes = 0;
    for (final file in files) {
      try {
        if (await file.exists()) totalBytes += await file.length();
      } on FileSystemException {
        // تجاهل الملف الذي تعذر قياس حجمه مع إبقائه ظاهراً في القائمة.
      }
    }
    return WorksSummary(files, totalBytes);
  }

  Future<void> refreshWorks() async {
    setState(() {
      selectedPaths.clear();
      worksFuture = loadWorks();
    });
  }

  void toggleSelection(File file) {
    final path = file.path;
    setState(() {
      if (!selectedPaths.add(path)) selectedPaths.remove(path);
    });
  }

  Future<void> openWork(File file) async {
    if (selectedPaths.isNotEmpty) {
      toggleSelection(file);
      return;
    }
    final name = file.uri.pathSegments.last.toLowerCase();
    if (name.endsWith('.mp4')) {
      if (!mounted) return;
      final shouldDelete = await Navigator.push<bool>(
        context,
        MaterialPageRoute(builder: (_) => SavedVideoPage(file: file)),
      );
      if (shouldDelete == true && mounted) await deleteWork(file);
    } else if (RegExp(r'\.(wav|mp3|m4a|aac|flac|ogg)$').hasMatch(name)) {
      if (!mounted) return;
      final shouldDelete = await Navigator.push<bool>(
        context,
        MaterialPageRoute(builder: (_) => SavedAudioPage(file: file)),
      );
      if (shouldDelete == true && mounted) await deleteWork(file);
    } else {
      if (!mounted) return;
      showDialog<void>(
        context: context,
        builder: (_) => Dialog(
          child: InteractiveViewer(child: Image.file(file, fit: BoxFit.contain)),
        ),
      );
    }
  }

  Future<bool> confirmDelete(File file) async {
    final name = file.uri.pathSegments.last;
    final isVideo = name.toLowerCase().endsWith('.mp4');
    return await showDialog<bool>(
          context: context,
          builder: (dialogContext) => AlertDialog(
            title: Text(isVideo ? 'حذف الفيديو؟' : 'حذف الملف؟'),
            content: Text(isVideo
                ? 'سيتم حذف الفيديو الذي تم تنزيله نهائيًا من الجهاز.'
                : 'سيتم حذف هذا الملف نهائيًا من الجهاز.'),
            actions: [
              TextButton(
                onPressed: () => Navigator.pop(dialogContext, false),
                child: const Text('إلغاء'),
              ),
              FilledButton.icon(
                onPressed: () => Navigator.pop(dialogContext, true),
                icon: const Icon(Icons.delete_outline),
                label: const Text('حذف'),
              ),
            ],
          ),
        ) ??
        false;
  }

  Future<bool> confirmBulkDelete(int count) async {
    return await showDialog<bool>(
          context: context,
          builder: (dialogContext) => AlertDialog(
            title: const Text('حذف الأعمال المحددة؟'),
            content: Text('سيتم حذف $count ملف نهائيًا من مساحة التطبيق على الجهاز.'),
            actions: [
              TextButton(
                onPressed: () => Navigator.pop(dialogContext, false),
                child: const Text('إلغاء'),
              ),
              FilledButton.icon(
                onPressed: () => Navigator.pop(dialogContext, true),
                icon: const Icon(Icons.delete_forever),
                label: const Text('حذف الكل'),
              ),
            ],
          ),
        ) ??
        false;
  }

  Future<void> deleteWork(File file) async {
    try {
      if (await file.exists()) await file.delete();
      if (!mounted) return;
      await refreshWorks();
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('تم حذف الملف من الجهاز')),
      );
    } on FileSystemException catch (error) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('تعذر حذف الملف: ${error.message}')),
      );
    }
  }

  Future<void> deleteSelected() async {
    final paths = selectedPaths.toList(growable: false);
    if (paths.isEmpty || !await confirmBulkDelete(paths.length) || !mounted) return;
    var deleted = 0;
    var failed = 0;
    for (final path in paths) {
      try {
        final file = File(path);
        if (await file.exists()) await file.delete();
        deleted++;
      } on FileSystemException {
        failed++;
      }
    }
    if (!mounted) return;
    await refreshWorks();
    if (!mounted) return;
    final message = failed == 0
        ? 'تم حذف $deleted ملف بنجاح'
        : 'تم حذف $deleted ملف، وتعذر حذف $failed ملف';
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(message)));
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(selectedPaths.isEmpty ? 'أعمالي' : 'تم تحديد ${selectedPaths.length}'),
        leading: selectedPaths.isNotEmpty
            ? IconButton(
                tooltip: 'إلغاء التحديد',
                onPressed: () => setState(() => selectedPaths.clear()),
                icon: const Icon(Icons.close),
              )
            : null,
        actions: [
          if (selectedPaths.isNotEmpty)
            IconButton(
              tooltip: 'تحديد الكل',
              onPressed: () async {
                final summary = await worksFuture;
                if (!mounted) return;
                setState(() => selectedPaths
                  ..clear()
                  ..addAll(summary.files.map((file) => file.path)));
              },
              icon: const Icon(Icons.select_all),
            ),
          if (selectedPaths.isNotEmpty)
            IconButton(
              tooltip: 'حذف المحدد',
              onPressed: deleteSelected,
              icon: const Icon(Icons.delete_sweep_outlined),
            ),
          IconButton(onPressed: refreshWorks, icon: const Icon(Icons.refresh)),
        ],
      ),
      body: FutureBuilder<WorksSummary>(
        future: worksFuture,
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return const Center(child: CircularProgressIndicator());
          }
          if (snapshot.hasError) {
            return Center(child: Text('تعذر تحميل الأعمال: ${snapshot.error}'));
          }
          final summary = snapshot.data ?? WorksSummary(<File>[], 0);
          final files = summary.files;
          if (files.isEmpty) {
            return const Center(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Icon(Icons.folder_open, size: 65, color: Colors.white54),
                  SizedBox(height: 15),
                  Text('لسه مفيش أعمال محفوظة', style: TextStyle(fontSize: 21, fontWeight: FontWeight.bold)),
                  SizedBox(height: 8),
                  Text('نتائج الصور والفيديوهات والملفات الصوتية هتظهر هنا', style: TextStyle(color: Colors.white54)),
                ],
              ),
            );
          }
          return RefreshIndicator(
            onRefresh: refreshWorks,
            child: ListView.separated(
              padding: const EdgeInsets.all(16),
              itemCount: files.length + 1,
              separatorBuilder: (_, __) => const SizedBox(height: 8),
              itemBuilder: (context, index) {
                if (index == 0) {
                  return Card(
                    color: const Color(0xFF252A40),
                    child: ListTile(
                      leading: const Icon(Icons.storage_outlined, size: 30),
                      title: Text('مساحة الأعمال: ${formatStorageSize(summary.totalBytes)}'),
                      subtitle: Text('${files.length} ملف محفوظ على الجهاز'),
                    ),
                  );
                }
                final file = files[index - 1];
                final name = file.uri.pathSegments.last;
                final isVideo = name.toLowerCase().endsWith('.mp4');
                final isAudio = RegExp(r'\.(wav|mp3|m4a|aac|flac|ogg)$').hasMatch(name.toLowerCase());
                final isSelected = selectedPaths.contains(file.path);
                return Card(
                  color: isSelected ? const Color(0xFF303A5B) : const Color(0xFF1B1E2E),
                  child: ListTile(
                    onTap: () => openWork(file),
                    onLongPress: () => toggleSelection(file),
                    leading: selectedPaths.isNotEmpty
                        ? Checkbox(value: isSelected, onChanged: (_) => toggleSelection(file))
                        : isVideo
                            ? const CircleAvatar(child: Icon(Icons.play_arrow))
                            : isAudio
                                ? const CircleAvatar(child: Icon(Icons.music_note))
                                : ClipRRect(
                                borderRadius: BorderRadius.circular(8),
                                child: Image.file(file, width: 54, height: 54, fit: BoxFit.cover),
                              ),
                    title: Text(isVideo
                        ? 'فيديو ناتج'
                        : isAudio
                            ? 'ملف صوتي ناتج'
                            : name.startsWith('enhanced_')
                                ? 'صورة محسّنة'
                                : 'صورة تبديل وجه'),
                    subtitle: Text(name, maxLines: 1, overflow: TextOverflow.ellipsis),
                    trailing: selectedPaths.isEmpty
                        ? IconButton(
                            tooltip: 'حذف',
                            onPressed: () async {
                              if (await confirmDelete(file) && mounted) await deleteWork(file);
                            },
                            icon: const Icon(Icons.delete_outline),
                          )
                        : TextButton(
                            onPressed: () => toggleSelection(file),
                            child: Text(isSelected ? 'إلغاء' : 'تحديد'),
                          ),
                  ),
                );
              },
            ),
          );
        },
      ),
    );
  }
}

class WorksSummary {
  final List<File> files;
  final int totalBytes;
  const WorksSummary(this.files, this.totalBytes);
}

class SavedVideoPage extends StatefulWidget {
  final File file;
  const SavedVideoPage({super.key, required this.file});

  @override
  State<SavedVideoPage> createState() => _SavedVideoPageState();
}

class _SavedVideoPageState extends State<SavedVideoPage> {
  late final VideoPlayerController controller;
  bool ready = false;

  @override
  void initState() {
    super.initState();
    controller = VideoPlayerController.file(widget.file)
      ..initialize().then((_) {
        if (mounted) setState(() => ready = true);
      });
  }

  @override
  void dispose() {
    controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('مشاهدة الفيديو المحفوظ'),
        actions: [
          IconButton(
            tooltip: 'حذف الفيديو',
            icon: const Icon(Icons.delete_outline),
            onPressed: () async {
              final confirmed = await showDialog<bool>(
                    context: context,
                    builder: (dialogContext) => AlertDialog(
                      title: const Text('حذف الفيديو؟'),
                      content: const Text(
                        'سيتم حذف الفيديو الذي تم تنزيله نهائيًا من الجهاز.',
                      ),
                      actions: [
                        TextButton(
                          onPressed: () => Navigator.pop(dialogContext, false),
                          child: const Text('إلغاء'),
                        ),
                        FilledButton.icon(
                          onPressed: () => Navigator.pop(dialogContext, true),
                          icon: const Icon(Icons.delete_outline),
                          label: const Text('حذف'),
                        ),
                      ],
                    ),
                  ) ??
                  false;
              if (confirmed && mounted) Navigator.pop(context, true);
            },
          ),
        ],
      ),
      body: Center(
        child: ready
            ? Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  AspectRatio(aspectRatio: controller.value.aspectRatio, child: VideoPlayer(controller)),
                  IconButton(
                    iconSize: 48,
                    onPressed: () => setState(() {
                      controller.value.isPlaying ? controller.pause() : controller.play();
                    }),
                    icon: Icon(controller.value.isPlaying ? Icons.pause_circle : Icons.play_circle),
                  ),
                ],
              )
            : const CircularProgressIndicator(),
      ),
    );
  }
}

// الإعدادات

class SettingsPage extends StatefulWidget {
  const SettingsPage({super.key});

  @override
  State<SettingsPage> createState() => _SettingsPageState();
}

class _SettingsPageState extends State<SettingsPage> {
  final TextEditingController serverController = TextEditingController();
  final TextEditingController apiKeyController = TextEditingController();
  bool loaded = false;
  bool testingConnection = false;

  @override
  void initState() {
    super.initState();
    loadServer();
  }

  Future<void> loadServer() async {
    final prefs = await SharedPreferences.getInstance();
    if (!mounted) return;
    serverController.text = prefs.getString('api_base_url') ?? '';
    apiKeyController.text = prefs.getString('api_key') ?? '';
    setState(() => loaded = true);
  }

  bool isValidServerUrl(String value) {
    final uri = Uri.tryParse(value);
    return uri != null &&
        (uri.scheme == 'http' || uri.scheme == 'https') &&
        uri.hasAuthority &&
        uri.host.isNotEmpty &&
        uri.userInfo.isEmpty &&
        uri.query.isEmpty &&
        uri.fragment.isEmpty;
  }

  void showInvalidServerUrl() {
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(content: Text('اكتب رابطاً صحيحاً يبدأ بـ http:// أو https:// ومن دون بيانات دخول أو معاملات إضافية')),
    );
  }

  Future<void> saveServer() async {
    final value = serverController.text.trim().replaceAll(RegExp(r'/+$'), '');
    if (value.isNotEmpty && !isValidServerUrl(value)) {
      showInvalidServerUrl();
      return;
    }
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString('api_base_url', value);
    await prefs.setString('api_key', apiKeyController.text.trim());
    if (!mounted) return;
    FocusScope.of(context).unfocus();
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(content: Text('تم حفظ عنوان خادم المعالجة')),
    );
  }

  Future<void> testConnection() async {
    final baseUrl = serverController.text.trim().replaceAll(RegExp(r'/+$'), '');
    if (baseUrl.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('اكتب رابط الخادم أولاً')),
      );
      return;
    }
    if (!isValidServerUrl(baseUrl)) {
      showInvalidServerUrl();
      return;
    }
    setState(() => testingConnection = true);
    try {
      final response = await http.get(
        Uri.parse('$baseUrl/health'),
        headers: apiKeyController.text.trim().isEmpty
            ? <String, String>{}
            : <String, String>{'X-API-Key': apiKeyController.text.trim()},
      ).timeout(const Duration(seconds: 20));
      if (response.statusCode == 200) {
        final capabilityResponse = await http.get(
          Uri.parse('$baseUrl/api/capabilities'),
          headers: apiKeyController.text.trim().isEmpty
              ? <String, String>{}
              : <String, String>{'X-API-Key': apiKeyController.text.trim()},
        ).timeout(const Duration(seconds: 20));
        if (capabilityResponse.statusCode != 200) {
          throw Exception('تعذر قراءة قدرات الخادم: ${capabilityResponse.statusCode}');
        }
        final capabilities = jsonDecode(capabilityResponse.body) as Map<String, dynamic>;
        final server = capabilities['server'] as Map<String, dynamic>? ?? {};
        final modelsVerified = server['models_verified'] == true;
        final cliReady = server['facefusion_cli_available'] == true;
        final ffmpegReady = server['ffmpeg_available'] == true;
        final diagnosticsResponse = await http.get(
          Uri.parse('$baseUrl/api/diagnostics'),
          headers: apiKeyController.text.trim().isEmpty
              ? <String, String>{}
              : <String, String>{'X-API-Key': apiKeyController.text.trim()},
        ).timeout(const Duration(seconds: 20));
        if (diagnosticsResponse.statusCode != 200) {
          throw Exception('تعذر فحص جاهزية المحرك: ${diagnosticsResponse.statusCode}');
        }
        final diagnostics = jsonDecode(diagnosticsResponse.body) as Map<String, dynamic>;
        final runtime = diagnostics['runtime'] as Map<String, dynamic>? ?? {};
        final runtimeReady = diagnostics['runtime_preflight_ready'] == true;
        final selectedProviders = (runtime['requested_execution_providers'] as List<dynamic>? ?? [])
            .map((value) => value.toString()).join(', ');
        final prefs = await SharedPreferences.getInstance();
        await prefs.setString('api_base_url', baseUrl);
        await prefs.setString('api_key', apiKeyController.text.trim());
        if (!mounted) return;
        final statusText = modelsVerified
            ? 'الخادم متصل؛ فحص الملفات مكتمل، لكن يلزم اختبار معالجة فعلية.'
            : 'الخادم متصل | المحرك: ${cliReady ? "موجود" : "غير موجود"} | FFmpeg: ${ffmpegReady ? "موجود" : "غير موجود"} | مزود التنفيذ ($selectedProviders): ${runtimeReady ? "متاح" : "غير جاهز"}. النماذج لم تُختبر بمعالجة فعلية.';
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text(statusText), duration: const Duration(seconds: 6)),
        );
      } else {
        throw Exception('استجابة الخادم: ${response.statusCode} ${response.body}');
      }
    } catch (error) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('فشل الاتصال: $error')),
      );
    } finally {
      if (mounted) setState(() => testingConnection = false);
    }
  }

  @override
  void dispose() {
    serverController.dispose();
    apiKeyController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('الإعدادات')),
      body: ListView(
        padding: const EdgeInsets.all(20),
        children: [
          Card(
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Row(
                children: [
                  const Icon(Icons.verified_outlined, color: Color(0xFF9B7BFF), size: 30),
                  const SizedBox(width: 12),
                  const Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text('المحترف في AI', style: TextStyle(fontSize: 17, fontWeight: FontWeight.bold)),
                        SizedBox(height: 4),
                        Text('الإصدار 1.28.17 — build 45', style: TextStyle(color: Colors.white70, fontSize: 12)),
                      ],
                    ),
                  ),
                  const Chip(label: Text('V1.28.17')),
                ],
              ),
            ),
          ),
          const SizedBox(height: 18),
          const Text('اتصال محرك الذكاء الاصطناعي',
              style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
          const SizedBox(height: 8),
          const Text(
            'اربط التطبيق بخادم معالجة تملكه أو تشغّله بنفسك. يجب أن يكون الرابط قابلًا للوصول من الهاتف؛ localhost يشير إلى الهاتف نفسه وليس إلى جهازك الآخر.',
            style: TextStyle(color: Colors.white60, fontSize: 13),
          ),
          const SizedBox(height: 12),
          TextField(
            controller: serverController,
            enabled: loaded,
            keyboardType: TextInputType.url,
            autocorrect: false,
            decoration: const InputDecoration(
              hintText: 'https://your-server.example.com',
              labelText: 'رابط خادم المعالجة',
              border: OutlineInputBorder(),
              prefixIcon: Icon(Icons.cloud_outlined),
            ),
          ),
          const SizedBox(height: 12),
          TextField(
            controller: apiKeyController,
            enabled: loaded,
            obscureText: true,
            autocorrect: false,
            decoration: const InputDecoration(
              labelText: 'مفتاح حماية الخادم',
              helperText: 'اتركه فارغًا فقط إذا كان الخادم مضبوطًا دون مفتاح API.',
              border: OutlineInputBorder(),
              prefixIcon: Icon(Icons.key_outlined),
            ),
          ),
          const SizedBox(height: 12),
          OutlinedButton.icon(
            onPressed: loaded && !testingConnection ? testConnection : null,
            icon: testingConnection
                ? const SizedBox(width: 18, height: 18, child: CircularProgressIndicator(strokeWidth: 2))
                : const Icon(Icons.wifi_tethering),
            label: Text(testingConnection ? 'جارٍ اختبار الاتصال...' : 'اختبار اتصال الخادم وحفظ الإعدادات'),
          ),
          const SizedBox(height: 8),
          FilledButton.icon(
            onPressed: loaded ? saveServer : null,
            icon: const Icon(Icons.save_outlined),
            label: const Text('حفظ إعدادات الخادم'),
          ),
          const SizedBox(height: 8),
          const Text(
            'تنبيه: حفظ الرابط لا ينشئ خادمًا ولا يثبت محرك FaceFusion. يلزم تشغيل Backend ومحرك معالجة فعلي قبل تنفيذ تبديل الوجوه.',
            style: TextStyle(color: Colors.amberAccent, fontSize: 12),
          ),
          const Divider(height: 36),
          ListTile(
            leading: const Icon(Icons.person_outline),
            title: const Text('المستخدم الشخصي'),
            subtitle: const Text('تطبيقك الخاص'),
            trailing: const Icon(Icons.chevron_left),
            onTap: () => showDialog<void>(
              context: context,
              builder: (dialogContext) => AlertDialog(
                title: const Text('المستخدم الشخصي'),
                content: const Text('هذه نسخة شخصية من تطبيق المحترف في AI، ولا تتطلب إنشاء حساب مستخدم.'),
                actions: [TextButton(onPressed: () => Navigator.pop(dialogContext), child: const Text('إغلاق'))],
              ),
            ),
          ),
          const Divider(),
          ListTile(
            leading: const Icon(Icons.language),
            title: const Text('اللغة'),
            subtitle: const Text('العربية'),
            trailing: const Icon(Icons.chevron_left),
            onTap: () => showDialog<void>(
              context: context,
              builder: (dialogContext) => AlertDialog(
                title: const Text('لغة التطبيق'),
                content: const Text('اللغة المتاحة حاليًا هي العربية.'),
                actions: [TextButton(onPressed: () => Navigator.pop(dialogContext), child: const Text('إغلاق'))],
              ),
            ),
          ),
          const Divider(),
          ListTile(
            leading: const Icon(Icons.info_outline),
            title: const Text('عن التطبيق'),
            subtitle: const Text('المحترف في AI'),
            trailing: const Icon(Icons.chevron_left),
            onTap: () => showDialog<void>(
              context: context,
              builder: (dialogContext) => AlertDialog(
                title: const Text('المحترف في AI'),
                content: const Text('الإصدار 1.28.17 — build 45\nواجهة عربية شخصية. يتطلب تنفيذ أدوات الذكاء الاصطناعي ربط خادم معالجة محلي أو خادم تملكه.'),
                actions: [TextButton(onPressed: () => Navigator.pop(dialogContext), child: const Text('إغلاق'))],
              ),
            ),
          ),
        ],
      ),
    );
  }
}
