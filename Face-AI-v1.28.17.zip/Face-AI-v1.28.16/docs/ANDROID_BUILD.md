# Android APK build

This repository contains the Flutter application source, but intentionally does
not commit a generated Android host project. The workflow
`.github/workflows/android-apk.yml` creates that host in a temporary Flutter
scaffold and copies **only** its `android/` directory into the checkout. It
never runs `flutter create` over the application root, so `lib/main.dart` and
`pubspec.yaml` are preserved.

## Build in GitHub Actions

1. Push this repository to the `main` branch on GitHub.
2. Open **Actions → Build Android APK**.
3. Wait for both `backend-tests` and `android-apk` jobs to pass.
4. Open the successful workflow run and download the artifact named
   `Mohtarif-AI-Android-<run number>`.
5. Extract `app-release.apk` and install it on the Android phone.

The workflow also runs `flutter analyze`, Flutter widget tests, backend pytest,
and validates the APK archive before publishing the artifact.

## Local build

With Flutter stable, Java 17, and Android SDK installed:

```bash
bash scripts/prepare_android.sh
flutter pub get
flutter analyze
flutter test
flutter build apk --release
```

The script refuses to overwrite an existing `android/` directory. It requires
`lib/main.dart` and `pubspec.yaml`, and copies only the generated native host.

## Important limitation

A successful APK build proves that the Android package compiles and installs;
it does **not** prove that a remote GPU worker is connected or that FaceFusion
models are installed. Real image/video inference still requires a separately
provisioned, authenticated GPU worker and an end-to-end inference test.
