# V1.28.15

- Added a reproducible GitHub Actions pipeline for backend tests and Android
  release APK builds.
- Added a safe Android host preparation script that scaffolds only the native
  `android/` directory in a temporary Flutter project; it never replaces the
  actual Dart application or `pubspec.yaml`.
- Added an explicit source-integrity check around Android scaffolding to guard
  against accidentally replacing the app with the Flutter demo template.
- Added Dart analysis, Flutter widget tests, APK archive validation, and a
  downloadable 14-day GitHub Actions artifact.
- Added repository ignore rules for generated Flutter, Gradle, Python, and
  secret environment files.
- Updated app/backend/Docker version to 1.28.15 (build 43).
- Backend behavior and the agreed video limits remain unchanged: 120 seconds
  and 300 MiB maximum input.

## Verification in this workspace

- Backend pytest: pending execution for this version.
- Flutter analyze / Flutter tests / APK build: not run here because Flutter
  SDK and Android SDK are not installed in this execution environment.
- No GPU worker was provisioned or tested by this release.
