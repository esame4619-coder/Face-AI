import os
import shutil
import subprocess
import tempfile
import importlib.metadata
import platform
import re
import math
from pathlib import Path
from io import BytesIO


class EngineNotReadyError(RuntimeError):
    """Raised when the configured inference runtime cannot run the request."""


class FaceSwapEngine:
    """Runner for the installed FaceFusion CLI plus video audio remuxing."""

    def __init__(self):
        self.facefusion_path = os.getenv(
            "FACEFUSION_PATH", "/opt/facefusion/facefusion.py"
        )
        self.python_path = os.getenv("PYTHON_PATH", "python")
        self.command_timeout = int(os.getenv("FACEFUSION_TIMEOUT", "0"))
        if self.command_timeout < 0:
            raise ValueError("FACEFUSION_TIMEOUT must be zero or a positive number of seconds")
        raw_providers = os.getenv("FACEFUSION_EXECUTION_PROVIDERS", "cpu")
        self.execution_providers = [item.strip().lower() for item in raw_providers.split(",") if item.strip()]
        if not self.execution_providers:
            self.execution_providers = ["cpu"]
        if any(not re.fullmatch(r"[a-z0-9_]+", item) for item in self.execution_providers):
            raise ValueError("FACEFUSION_EXECUTION_PROVIDERS contains an invalid provider name")
        raw_models = os.getenv("FACEFUSION_REQUIRED_MODEL_FILES", "")
        self.required_model_files = [Path(item.strip()).expanduser() for item in raw_models.split(os.pathsep) if item.strip()]

    def is_available(self):
        return Path(self.facefusion_path).is_file()

    @staticmethod
    def ffmpeg_available():
        return shutil.which("ffmpeg") is not None and shutil.which("ffprobe") is not None

    @staticmethod
    def runtime_diagnostics():
        """Report installed inference providers without claiming model readiness."""
        info = {
            "python_version": platform.python_version(),
            "facefusion_version": None,
            "onnxruntime_installed": False,
            "onnxruntime_version": None,
            "execution_providers": [],
            "cuda_provider_available": False,
            "tensorrt_provider_available": False,
            "gpu_hardware_detected": False,
            "gpu_devices": [],
            "models_verified": False,
            "requested_execution_providers": [],
            "requested_providers_available": False,
        }
        try:
            info["facefusion_version"] = importlib.metadata.version("facefusion")
        except importlib.metadata.PackageNotFoundError:
            pass
        try:
            info["onnxruntime_version"] = importlib.metadata.version("onnxruntime")
            import onnxruntime
            providers = list(onnxruntime.get_available_providers())
            info["onnxruntime_installed"] = True
            info["execution_providers"] = providers
            info["cuda_provider_available"] = "CUDAExecutionProvider" in providers
            info["tensorrt_provider_available"] = "TensorrtExecutionProvider" in providers
        except (ImportError, importlib.metadata.PackageNotFoundError, RuntimeError):
            pass
        # Hardware visibility is reported separately from ONNX provider availability.
        # This does not claim that FaceFusion inference is GPU-backed or successful.
        if shutil.which("nvidia-smi"):
            try:
                gpu_result = subprocess.run(
                    ["nvidia-smi", "--query-gpu=name,memory.total,memory.free,utilization.gpu",
                     "--format=csv,noheader,nounits"],
                    capture_output=True, text=True, timeout=5,
                )
                if gpu_result.returncode == 0:
                    for line in gpu_result.stdout.splitlines():
                        fields = [item.strip() for item in line.split(",")]
                        if len(fields) == 4:
                            info["gpu_devices"].append({
                                "name": fields[0],
                                "memory_total_mb": fields[1],
                                "memory_free_mb": fields[2],
                                "utilization_percent": fields[3],
                            })
                    info["gpu_hardware_detected"] = bool(info["gpu_devices"])
            except (OSError, subprocess.TimeoutExpired):
                pass
        return info

    def provider_diagnostics(self):
        info = self.runtime_diagnostics()
        requested = self.execution_providers
        available = set(info.get("execution_providers", []))
        provider_map = {
            "cpu": "CPUExecutionProvider",
            "cuda": "CUDAExecutionProvider",
            "tensorrt": "TensorrtExecutionProvider",
            "coreml": "CoreMLExecutionProvider",
            "directml": "DmlExecutionProvider",
            "openvino": "OpenVINOExecutionProvider",
            "rocm": "ROCMExecutionProvider",
            "migraphx": "MIGraphXExecutionProvider",
            "qnn": "QNNExecutionProvider",
            "webnn": "WebNNExecutionProvider",
            "webgpu": "WebGpuExecutionProvider",
        }
        requested_runtime_names = [provider_map.get(item, item) for item in requested]
        info["requested_execution_providers"] = requested
        info["requested_providers_available"] = bool(available) and all(
            item in available for item in requested_runtime_names
        )
        selected_available = [item for item in requested_runtime_names if item in available]
        info["available_requested_providers"] = selected_available
        info["provider_preflight_ready"] = bool(selected_available)
        info["provider_fallback_possible"] = bool(
            selected_available and len(selected_available) < len(requested_runtime_names)
        )
        missing_models = []
        for path in self.required_model_files:
            try:
                if not path.is_file() or path.stat().st_size == 0:
                    missing_models.append(str(path))
            except OSError:
                missing_models.append(str(path))
        info["required_model_files_configured"] = bool(self.required_model_files)
        info["required_model_files_present"] = bool(self.required_model_files) and not missing_models
        info["missing_required_model_files"] = missing_models
        info["models_verified"] = False  # File presence is not proof of successful model loading.
        return info

    def preflight(self):
        """Fail early if no selected ONNX provider or configured model file is usable."""
        info = self.provider_diagnostics()
        if not info.get("provider_preflight_ready"):
            requested = ", ".join(self.execution_providers)
            raise EngineNotReadyError(
                f"لا يوجد مزود ONNX Runtime متاح من المزودات المحددة ({requested}). "
                "تحقق من تثبيت ONNX Runtime ومكتبات GPU المطلوبة."
            )
        missing_models = info.get("missing_required_model_files", [])
        if missing_models:
            raise EngineNotReadyError(
                "ملفات النماذج المحددة غير موجودة أو فارغة: " + ", ".join(missing_models)
            )
        return info

    def _run(self, source_path: Path, target_path: Path,
             output_path: Path, timeout: int):
        if not source_path.is_file() or source_path.stat().st_size == 0:
            raise ValueError("Source image is missing or empty")
        if not target_path.is_file() or target_path.stat().st_size == 0:
            raise ValueError("Target media file is missing or empty")
        if not self.is_available():
            raise RuntimeError("FaceFusion is not installed on the server")
        if not self.ffmpeg_available():
            raise RuntimeError("FFmpeg/FFprobe is required on the server")
        self.preflight()

        output_path.parent.mkdir(parents=True, exist_ok=True)
        command = [
            self.python_path,
            self.facefusion_path,
            "headless-run",
            "--source-paths", str(source_path),
            "--target-path", str(target_path),
            "--output-path", str(output_path),
            "--execution-providers", *self.execution_providers,
            "--processors", "face_swapper",
        ]
        result = subprocess.run(
            command, capture_output=True, text=True, timeout=(timeout or self.command_timeout or None)
        )
        if result.returncode != 0:
            details = result.stderr or result.stdout or "FaceFusion failed"
            raise RuntimeError(details[-6000:])
        if not output_path.is_file() or output_path.stat().st_size == 0:
            raise RuntimeError("FaceFusion did not generate a valid output")

    @staticmethod
    def _load_image(data: bytes):
        from PIL import Image, ImageOps
        image = Image.open(BytesIO(data))
        image.load()
        return ImageOps.exif_transpose(image).convert("RGB")

    def swap_faces(self, source_image: bytes, target_image: bytes,
                   output_path: str):
        with tempfile.TemporaryDirectory() as temp_dir:
            temp = Path(temp_dir)
            source_path = temp / "source.png"
            target_path = temp / "target.png"
            self._load_image(source_image).save(source_path, format="PNG")
            self._load_image(target_image).save(target_path, format="PNG")
            self._run(source_path, target_path, Path(output_path), timeout=self.command_timeout)
        return output_path

    def swap_video(self, source_image: bytes, target_video: bytes,
                   video_suffix: str, output_path: str):
        suffix = video_suffix.lower()
        if suffix not in {".mp4", ".mov", ".mkv", ".webm", ".avi"}:
            suffix = ".mp4"
        with tempfile.TemporaryDirectory() as temp_dir:
            temp = Path(temp_dir)
            source_path = temp / "source.png"
            target_path = temp / f"original{suffix}"
            self._load_image(source_image).save(source_path, format="PNG")
            target_path.write_bytes(target_video)
            return self.swap_video_files(str(source_path), str(target_path), output_path)

    def swap_video_files(self, source_path: str, target_path: str, output_path: str):
        """Process existing files to avoid copying large uploads into memory."""
        source = Path(source_path)
        target = Path(target_path)
        final_path = Path(output_path)
        with tempfile.TemporaryDirectory() as temp_dir:
            swapped_path = Path(temp_dir) / "swapped.mp4"
            self._run(source, target, swapped_path, timeout=self.command_timeout)
            # Read the original duration and cap the mux to that duration. Avoid
            # -shortest: a slightly shorter audio stream must not truncate video.
            probe = [
                "ffprobe", "-v", "error", "-show_entries", "format=duration",
                "-of", "default=noprint_wrappers=1:nokey=1", str(target),
            ]
            probe_result = subprocess.run(
                probe, capture_output=True, text=True, timeout=self.command_timeout or None
            )
            if probe_result.returncode != 0:
                details = probe_result.stderr or "Unable to read original video duration"
                raise RuntimeError(details[-2000:])
            try:
                duration = float(probe_result.stdout.strip())
            except (TypeError, ValueError) as error:
                raise RuntimeError("FFprobe returned an invalid video duration") from error
            if not math.isfinite(duration) or duration <= 0:
                raise RuntimeError("Original video duration must be a finite positive number")
            final_path.parent.mkdir(parents=True, exist_ok=True)
            mux = [
                "ffmpeg", "-y", "-i", str(swapped_path), "-i", str(target),
                "-map", "0:v:0", "-map", "1:a?", "-map_metadata", "1",
                "-c:v", "copy", "-c:a", "aac", "-b:a", "192k",
                "-t", f"{duration:.3f}", "-movflags", "+faststart", str(final_path),
            ]
            result = subprocess.run(mux, capture_output=True, text=True, timeout=self.command_timeout or None)
            if result.returncode != 0 or not final_path.is_file() or final_path.stat().st_size == 0:
                details = result.stderr or result.stdout or "FFmpeg audio mux failed"
                raise RuntimeError(details[-4000:])
        return output_path


face_swap_engine = FaceSwapEngine()
