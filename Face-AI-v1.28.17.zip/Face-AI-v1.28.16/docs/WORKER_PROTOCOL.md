# GPU Worker Protocol (V1.28.15)

## Coordinator configuration
Set `GPU_WORKERS_JSON` to a JSON array. Each entry requires a unique `id`, an HTTPS `url`, and a distinct `api_key`; optional fields are `priority`, `max_concurrent`, `quota_jobs`, and `enabled`. Never commit real keys.

## Worker configuration
Run the same backend on a GPU host with `API_KEY` set to the worker secret, `REQUIRE_API_KEY=true`, and `GPU_WORKER_READY=true` **only after** a real FaceFusion CUDA inference test has succeeded. The health check also requires visible NVIDIA hardware, CUDAExecutionProvider selected in `FACEFUSION_EXECUTION_PROVIDERS`, a passing provider preflight, FaceFusion files, and FFmpeg. The flag is an operator attestation, not an automatic inference benchmark.

## Protocol
The coordinator probes the authenticated `GET /api/worker/health` endpoint (the general `GET /health` remains public for liveness only; it is not authentication proof), reserves up to three eligible workers in priority order (retrying only explicit preflight rejections carrying `X-Worker-Stage: preflight`; all other HTTP errors and ambiguous 5xx/network failures stop rather than risk duplicate processing), then streams `POST /api/worker/process` as multipart fields `source` (PNG) and `target` (video). The worker authenticates `X-API-Key`, validates the 300 MiB / 120 second limits, runs its local FaceFusion engine, validates output, and returns MP4. The coordinator requires `Content-Type: video/mp4`, streams the result to disk under `MAX_WORKER_RESULT_SIZE` (600 MiB default), and validates it again with FFprobe. Partial files are deleted on failure. Quota is decremented only after the returned MP4 passes FFprobe validation; capacity reservations are always released.

## Safety and limitations
Only configure worker hosts you own or are explicitly authorized to use. This protocol does not create free GPU capacity, extend provider quotas, or guarantee worker uptime. A remote worker must have a reachable HTTPS endpoint and the same API key configured on both ends. If no eligible remote worker is available, the coordinator falls back to its own local engine; this may be CPU-only. Worker retries are intentionally not automatic after a request is accepted, to avoid duplicate paid/quota consumption when a network failure makes completion ambiguous.


## Safe failover contract (V1.28.8)
A worker may return `X-Worker-Stage: preflight` only when it rejects a request before FaceFusion inference begins (for example, readiness, file type, size, duration, or model/runtime preflight checks). The coordinator may then release the reservation and try the next configured worker. Once inference may have started, the worker must not send this marker; the coordinator stops on that response. Network timeouts after submission are always ambiguous and are not automatically retried.


## Worker quarantine and recovery (v1.28.8)

The coordinator now applies a per-worker exponential cooldown after an ambiguous dispatch failure, invalid response, or non-retryable HTTP response. A worker in cooldown is excluded from scheduling even if its authenticated `/api/worker/health` endpoint still answers. The cooldown starts at `GPU_WORKER_COOLDOWN_SECONDS` (default 90 seconds), doubles after consecutive failures, and is capped at 30 minutes. A valid MP4 result clears the failure counter. This is a scheduling safeguard, not proof that the remote provider has recovered or that an interrupted inference stopped. Ambiguous jobs are still not automatically replayed on another worker, preventing duplicate GPU execution and duplicate quota use.


## Authenticated health handshake (V1.28.10)
The coordinator sends its configured `X-API-Key` to `/api/worker/health`. The worker verifies the key before returning the readiness payload and setting `api_key_protected=true`. The unauthenticated `/health` endpoint is reserved for basic liveness and does not claim that the caller authenticated. Health probes do not follow HTTP redirects, preventing the worker secret from being forwarded to another host.


## GPU self-test (V1.28.15)

Before a worker can report `gpu_worker_ready=true`, run the authenticated `POST /api/worker/self-test` with two face images. It performs a real FaceFusion image inference using the configured CUDA/TensorRT provider and validates the generated PNG. The attestation is memory-only and is cleared when the worker process restarts. `GPU_WORKER_READY=true` remains an operator opt-in, not a substitute for the self-test.

## Image processing worker (V1.28.15)
The same authenticated worker now exposes `POST /api/worker/process-image` with multipart `source` and `target` PNG images. The coordinator's `POST /api/faceswap` first validates both uploads, then reserves a verified GPU worker and streams the returned PNG to a temporary file. It validates the PNG by decoding it before returning the result with `X-Processing-Backend: remote-gpu`. If no worker is eligible, it uses the coordinator's local engine and labels the response `X-Processing-Backend: local`.

The image worker returns `X-Worker-Stage: preflight` only for failures known to occur before inference. Ambiguous failures are not automatically replayed. The coordinator decrements worker quota only after receiving and validating a real PNG response. Image output is validated independently from the worker's HTTP status and content type. This expands the protocol; it does not mean any GPU worker is currently deployed or that CUDA inference has been proven.


## Fixed video limits and job progress (V1.28.15)
- Coordinator and worker both enforce an absolute input ceiling of 300 MiB and 120 seconds. Environment settings may lower these values, but cannot raise or disable them.
- All completed video outputs are checked against 600 MiB and 120 seconds, including local-engine output.
- Job status now includes `stage`, `processing_backend`, `worker_id`, and `updated_at`; these fields are persisted with the job metadata.


## Persistent worker accounting (V1.28.15)
The coordinator persists quota remaining, consecutive failures, last failure reason, and cooldown expiry in `GPU_WORKER_STATE_PATH` (Docker default: `/data/gpu-worker-state.json`). The file is atomically replaced and excludes worker URLs and API keys. The data volume must be persistent to survive container replacement. Remove the state file while the service is stopped to intentionally reset quota accounting and quarantine history. A finite quota configured by the operator cannot be increased by a stale state file.
