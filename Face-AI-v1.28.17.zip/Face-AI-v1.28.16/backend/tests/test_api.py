import io
import sys
from pathlib import Path

from fastapi.testclient import TestClient
from PIL import Image
import pytest

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import main  # noqa: E402

client = TestClient(main.app)


def png_bytes():
    output = io.BytesIO()
    Image.new("RGB", (32, 32), (100, 120, 140)).save(output, format="PNG")
    return output.getvalue()


def test_home_and_health_are_available():
    home = client.get("/")
    assert home.status_code == 200
    assert home.json()["version"] == main.APP_VERSION
    assert main.app.version == main.APP_VERSION
    health = client.get("/health")
    assert health.status_code == 200
    assert health.json()["processing_ready"] is False


def test_enhance_returns_jpeg():
    response = client.post(
        "/api/enhance",
        files={"image": ("sample.png", png_bytes(), "image/png")},
    )
    assert response.status_code == 200
    assert response.headers["content-type"] == "image/jpeg"
    assert response.content.startswith(b"\xff\xd8")


def test_faceswap_reports_missing_engine():
    response = client.post(
        "/api/faceswap",
        files={
            "source": ("source.png", png_bytes(), "image/png"),
            "target": ("target.png", png_bytes(), "image/png"),
        },
    )
    assert response.status_code == 503


def test_video_rejects_unknown_extension():
    response = client.post(
        "/api/faceswap/video",
        files={
            "source": ("source.png", png_bytes(), "image/png"),
            "target": ("target.bin", b"not a video", "application/octet-stream"),
        },
    )
    assert response.status_code == 400


def test_processing_routes_enforce_configured_api_key(monkeypatch):
    monkeypatch.setattr(main, "API_KEY", "unit-test-secret")
    files = {
        "source": ("source.png", png_bytes(), "image/png"),
        "target": ("target.png", png_bytes(), "image/png"),
    }
    denied = client.post("/api/faceswap", files=files)
    assert denied.status_code == 401

    allowed_but_engine_missing = client.post(
        "/api/faceswap", files=files, headers={"X-API-Key": "unit-test-secret"}
    )
    assert allowed_but_engine_missing.status_code == 503


def test_video_job_completes_and_result_can_be_downloaded(monkeypatch, tmp_path):
    monkeypatch.setattr(main.face_swap_engine, "is_available", lambda: True)
    monkeypatch.setattr(main.face_swap_engine, "ffmpeg_available", lambda: True)
    monkeypatch.setattr(main.face_swap_engine, "preflight", lambda: {"provider_preflight_ready": True})
    monkeypatch.setattr(main, "video_duration_seconds", lambda _path: 4.0)
    monkeypatch.setattr(main, "JOB_ROOT", tmp_path / "jobs")

    def fake_swap(_source_path, _video_path, output_path):
        Path(output_path).write_bytes(b"fake-mp4-result")
        return output_path

    monkeypatch.setattr(main.face_swap_engine, "swap_video_files", fake_swap)
    monkeypatch.setattr(main, "validate_processed_video", lambda _path: {"duration": 4.0, "video_streams": [{}]})
    response = client.post(
        "/api/jobs/faceswap/video",
        files={
            "source": ("source.png", png_bytes(), "image/png"),
            "target": ("clip.mp4", b"fake-video", "video/mp4"),
        },
    )
    assert response.status_code == 202
    job = response.json()
    assert job["status"] == "queued"

    status = client.get(f"/api/jobs/{job['job_id']}")
    assert status.status_code == 200
    assert status.json()["status"] == "completed"
    assert status.json()["progress"] == 100
    assert status.json()["stage"] == "completed"
    assert status.json()["processing_backend"] == "local_engine"
    saved_state = (tmp_path / "jobs" / job["job_id"] / "job.json").read_text(encoding="utf-8")
    assert '"stage": "completed"' in saved_state

    result = client.get(f"/api/jobs/{job['job_id']}/result")
    assert result.status_code == 200
    assert result.content == b"fake-mp4-result"


def test_video_result_is_rejected_and_job_marked_failed_when_file_is_corrupt(monkeypatch, tmp_path):
    job_id = "c" * 32
    job_dir = tmp_path / job_id
    job_dir.mkdir(parents=True)
    output_path = job_dir / "faceswap.mp4"
    output_path.write_bytes(b"corrupt-output")
    monkeypatch.setattr(main, "JOB_ROOT", tmp_path)
    monkeypatch.setitem(main.JOBS, job_id, {
        "job_id": job_id, "status": "completed", "progress": 100,
        "message": "done", "created_at": __import__("time").time(),
    })
    monkeypatch.setattr(main, "validate_processed_video", lambda _path: (_ for _ in ()).throw(ValueError("bad media")))

    response = client.get(f"/api/jobs/{job_id}/result")
    assert response.status_code == 410
    assert main.JOBS[job_id]["status"] == "failed"
    assert "تالف" in main.JOBS[job_id]["message"]


def test_video_result_missing_file_marks_job_failed(monkeypatch, tmp_path):
    job_id = "d" * 32
    (tmp_path / job_id).mkdir(parents=True)
    monkeypatch.setattr(main, "JOB_ROOT", tmp_path)
    monkeypatch.setitem(main.JOBS, job_id, {
        "job_id": job_id, "status": "completed", "progress": 100,
        "message": "done", "created_at": __import__("time").time(),
    })

    response = client.get(f"/api/jobs/{job_id}/result")
    assert response.status_code == 410
    assert main.JOBS[job_id]["status"] == "failed"


def test_video_job_rejects_upload_over_streamed_limit(monkeypatch, tmp_path):
    monkeypatch.setattr(main.face_swap_engine, "is_available", lambda: True)
    monkeypatch.setattr(main.face_swap_engine, "ffmpeg_available", lambda: True)
    monkeypatch.setattr(main.face_swap_engine, "preflight", lambda: {"provider_preflight_ready": True})
    monkeypatch.setattr(main, "JOB_ROOT", tmp_path / "jobs")
    monkeypatch.setattr(main, "MAX_VIDEO_SIZE", 4)
    response = client.post(
        "/api/jobs/faceswap/video",
        files={
            "source": ("source.png", png_bytes(), "image/png"),
            "target": ("clip.mp4", b"12345", "video/mp4"),
        },
    )
    assert response.status_code == 413
    assert not list((tmp_path / "jobs").glob("*"))


def test_video_job_rejects_video_longer_than_two_minutes(monkeypatch, tmp_path):
    monkeypatch.setattr(main.face_swap_engine, "is_available", lambda: True)
    monkeypatch.setattr(main.face_swap_engine, "ffmpeg_available", lambda: True)
    monkeypatch.setattr(main.face_swap_engine, "preflight", lambda: {"provider_preflight_ready": True})
    monkeypatch.setattr(main, "video_duration_seconds", lambda _path: 121.0)
    monkeypatch.setattr(main, "MAX_VIDEO_SECONDS", 120)
    monkeypatch.setattr(main, "JOB_ROOT", tmp_path / "jobs")
    response = client.post(
        "/api/jobs/faceswap/video",
        files={
            "source": ("source.png", png_bytes(), "image/png"),
            "target": ("clip.mp4", b"fake-video", "video/mp4"),
        },
    )
    assert response.status_code == 413
    assert not list((tmp_path / "jobs").glob("*"))


def test_image_with_excessive_dimensions_is_rejected(monkeypatch):
    monkeypatch.setattr(main, "MAX_IMAGE_PIXELS", 100)
    response = client.post(
        "/api/enhance",
        files={"image": ("large.png", png_bytes(), "image/png")},
    )
    assert response.status_code == 413


def test_video_upload_reservation_is_released_after_validation_error(monkeypatch):
    monkeypatch.setattr(main, "UPLOAD_RESERVATIONS", 0)
    response = client.post(
        "/api/jobs/faceswap/video",
        files={
            "source": ("source.png", png_bytes(), "image/png"),
            "target": ("clip.bin", b"not-video", "application/octet-stream"),
        },
    )
    assert response.status_code == 400
    assert main.UPLOAD_RESERVATIONS == 0


def test_video_queue_rejects_when_capacity_is_reserved(monkeypatch):
    monkeypatch.setattr(main, "MAX_ACTIVE_JOBS", 1)
    monkeypatch.setattr(main, "UPLOAD_RESERVATIONS", 1)
    response = client.post(
        "/api/jobs/faceswap/video",
        files={
            "source": ("source.png", png_bytes(), "image/png"),
            "target": ("clip.mp4", b"fake-video", "video/mp4"),
        },
    )
    assert response.status_code == 429


def test_completed_jobs_are_restored_after_server_restart(monkeypatch, tmp_path):
    import json
    from fastapi.testclient import TestClient as LocalTestClient

    job_id = "a" * 32
    job_dir = tmp_path / job_id
    job_dir.mkdir()
    (job_dir / "faceswap.mp4").write_bytes(b"persisted-result")
    (job_dir / "job.json").write_text(json.dumps({
        "job_id": job_id, "status": "completed", "progress": 100,
        "message": "done", "created_at": __import__("time").time(),
    }), encoding="utf-8")
    monkeypatch.setattr(main, "JOB_ROOT", tmp_path)
    monkeypatch.setattr(main, "validate_processed_video", lambda _path: {"duration": 4.0, "video_streams": [{}]})

    with LocalTestClient(main.app) as restarted_client:
        status = restarted_client.get(f"/api/jobs/{job_id}")
        assert status.status_code == 200
        assert status.json()["status"] == "completed"
        result = restarted_client.get(f"/api/jobs/{job_id}/result")
        assert result.status_code == 200
        assert result.content == b"persisted-result"


def test_interrupted_jobs_are_marked_failed_after_restart(monkeypatch, tmp_path):
    import json
    from fastapi.testclient import TestClient as LocalTestClient

    job_id = "b" * 32
    job_dir = tmp_path / job_id
    job_dir.mkdir()
    (job_dir / "job.json").write_text(json.dumps({
        "job_id": job_id, "status": "processing", "progress": 10,
        "message": "working", "created_at": __import__("time").time(),
    }), encoding="utf-8")
    monkeypatch.setattr(main, "JOB_ROOT", tmp_path)

    with LocalTestClient(main.app) as restarted_client:
        status = restarted_client.get(f"/api/jobs/{job_id}")
        assert status.status_code == 200
        assert status.json()["status"] == "failed"
        assert "إعادة تشغيل الخادم" in status.json()["message"]


def test_capabilities_separate_api_routes_from_verified_ai(monkeypatch):
    monkeypatch.setattr(main.face_swap_engine, "is_available", lambda: True)
    monkeypatch.setattr(main.face_swap_engine, "ffmpeg_available", lambda: True)
    monkeypatch.setattr(main.face_swap_engine, "preflight", lambda: {"provider_preflight_ready": True})
    response = client.get("/api/capabilities")
    assert response.status_code == 200
    data = response.json()
    assert data["version"] == main.APP_VERSION
    assert data["server"]["facefusion_cli_available"] is True
    assert data["server"]["models_verified"] is False
    assert data["features"]["video_face_swap"]["maximum_seconds"] == 120
    assert data["features"]["voice_cloning"]["api"] is True
    assert data["features"]["voice_cloning"]["ai_verified"] is False
    assert data["features"]["music_generation"]["api"] is True


def test_api_key_required_configuration_rejects_missing_secret(monkeypatch, tmp_path):
    from fastapi.testclient import TestClient as LocalTestClient
    monkeypatch.setattr(main, "REQUIRE_API_KEY", True)
    monkeypatch.setattr(main, "API_KEY", "")
    monkeypatch.setattr(main, "JOB_ROOT", tmp_path / "jobs")
    import pytest
    with pytest.raises(RuntimeError, match="API_KEY is empty"):
        with LocalTestClient(main.app):
            pass


def test_engine_builds_facefusion_cli_with_plural_source_paths(monkeypatch, tmp_path):
    from engine import FaceSwapEngine

    script = tmp_path / "facefusion.py"
    script.write_text("# fake FaceFusion entrypoint", encoding="utf-8")
    engine = FaceSwapEngine()
    engine.facefusion_path = str(script)
    monkeypatch.setattr(engine, "ffmpeg_available", lambda: True)
    monkeypatch.setattr(engine, "preflight", lambda: {"provider_preflight_ready": True})
    source = tmp_path / "source.png"
    target = tmp_path / "target.png"
    source.write_bytes(b"source")
    target.write_bytes(b"target")
    output = tmp_path / "result.png"
    captured = {}

    def fake_run(command, **kwargs):
        captured["command"] = command
        output.write_bytes(b"test-image-output")
        class Result:
            returncode = 0
            stderr = ""
            stdout = ""
        return Result()

    monkeypatch.setattr("engine.subprocess.run", fake_run)
    engine._run(source, target, output, timeout=10)
    command = captured["command"]
    assert "--source-paths" in command
    assert "--source-path" not in command
    assert command[command.index("--target-path") + 1] == str(tmp_path / "target.png")
    assert output.read_bytes() == b"test-image-output"


def test_video_probe_requires_real_video_stream(monkeypatch, tmp_path):
    import json
    video = tmp_path / "clip.mp4"
    video.write_bytes(b"fake")
    class Result:
        returncode = 0
        stderr = ""
        stdout = json.dumps({"format": {"duration": "12.5"}, "streams": [
            {"codec_type": "audio", "codec_name": "aac"}
        ]})
    monkeypatch.setattr(main.subprocess, "run", lambda *args, **kwargs: Result())
    import pytest
    with pytest.raises(ValueError, match="لا يحتوي على مسار فيديو"):
        main.probe_video(video)


def test_video_probe_rejects_extreme_resolution(monkeypatch, tmp_path):
    import json
    video = tmp_path / "clip.mp4"
    video.write_bytes(b"fake")
    class Result:
        returncode = 0
        stderr = ""
        stdout = json.dumps({"format": {"duration": "12.5"}, "streams": [
            {"codec_type": "video", "codec_name": "h264", "width": 12000, "height": 8000}
        ]})
    monkeypatch.setattr(main.subprocess, "run", lambda *args, **kwargs: Result())
    monkeypatch.setattr(main, "MAX_VIDEO_PIXELS", 33_177_600)
    import pytest
    with pytest.raises(ValueError, match="أعلى من"):
        main.probe_video(video)


def test_video_probe_returns_duration_and_stream_metadata(monkeypatch, tmp_path):
    import json
    video = tmp_path / "clip.mp4"
    video.write_bytes(b"fake")
    class Result:
        returncode = 0
        stderr = ""
        stdout = json.dumps({"format": {"duration": "12.5"}, "streams": [
            {"codec_type": "video", "codec_name": "h264", "width": 1920, "height": 1080},
            {"codec_type": "audio", "codec_name": "aac"}
        ]})
    monkeypatch.setattr(main.subprocess, "run", lambda *args, **kwargs: Result())
    metadata = main.probe_video(video)
    assert metadata["duration"] == 12.5
    assert metadata["video_streams"][0]["width"] == 1920


def test_face_swap_image_loader_applies_exif_orientation():
    from engine import FaceSwapEngine
    image = Image.new("RGB", (10, 20), (10, 20, 30))
    exif = image.getexif()
    exif[274] = 6  # rotate 90 degrees clockwise when displayed
    output = io.BytesIO()
    image.save(output, format="JPEG", exif=exif)
    loaded = FaceSwapEngine._load_image(output.getvalue())
    assert loaded.size == (20, 10)


def test_facefusion_timeout_zero_means_no_command_timeout(monkeypatch):
    from engine import FaceSwapEngine
    monkeypatch.setenv("FACEFUSION_TIMEOUT", "0")
    engine = FaceSwapEngine()
    assert engine.command_timeout == 0


def test_runtime_diagnostics_never_claims_models_are_verified():
    from engine import FaceSwapEngine
    diagnostics = FaceSwapEngine.runtime_diagnostics()
    assert "python_version" in diagnostics
    assert isinstance(diagnostics["execution_providers"], list)
    assert diagnostics["models_verified"] is False




def test_runtime_diagnostics_reports_nvidia_gpu_visibility_separately(monkeypatch):
    from engine import FaceSwapEngine
    class Result:
        returncode = 0
        stdout = "NVIDIA Test GPU, 24576, 12000, 35\n"
        stderr = ""
    monkeypatch.setattr("engine.shutil.which", lambda name: "/usr/bin/nvidia-smi" if name == "nvidia-smi" else None)
    monkeypatch.setattr("engine.subprocess.run", lambda *args, **kwargs: Result())
    info = FaceSwapEngine.runtime_diagnostics()
    assert info["gpu_hardware_detected"] is True
    assert info["gpu_devices"][0]["name"] == "NVIDIA Test GPU"
    assert info["gpu_devices"][0]["memory_total_mb"] == "24576"
    assert info["models_verified"] is False


def test_health_exposes_runtime_provider_diagnostics():
    response = client.get("/health")
    assert response.status_code == 200
    runtime = response.json()["runtime"]
    assert "cuda_provider_available" in runtime
    assert "onnxruntime_installed" in runtime
    assert runtime["models_verified"] is False



def test_engine_includes_configured_execution_provider_in_command(monkeypatch, tmp_path):
    from engine import FaceSwapEngine

    monkeypatch.setenv("FACEFUSION_EXECUTION_PROVIDERS", "cuda,cpu")
    script = tmp_path / "facefusion.py"
    script.write_text("# fake FaceFusion entrypoint", encoding="utf-8")
    engine = FaceSwapEngine()
    engine.facefusion_path = str(script)
    monkeypatch.setattr(engine, "ffmpeg_available", lambda: True)
    monkeypatch.setattr(engine, "preflight", lambda: {"provider_preflight_ready": True})
    source = tmp_path / "source.png"
    target = tmp_path / "target.png"
    source.write_bytes(b"source")
    target.write_bytes(b"target")
    output = tmp_path / "result.png"
    captured = {}

    def fake_run(command, **kwargs):
        captured["command"] = command
        output.write_bytes(b"test-image-output")
        class Result:
            returncode = 0
            stderr = ""
            stdout = ""
        return Result()

    monkeypatch.setattr("engine.subprocess.run", fake_run)
    engine._run(source, target, output, timeout=10)
    command = captured["command"]
    index = command.index("--execution-providers")
    assert command[index + 1:index + 3] == ["cuda", "cpu"]


def test_engine_provider_diagnostics_reports_requested_provider(monkeypatch):
    from engine import FaceSwapEngine

    engine = FaceSwapEngine()
    engine.execution_providers = ["cuda"]
    monkeypatch.setattr(FaceSwapEngine, "runtime_diagnostics", staticmethod(lambda: {
        "execution_providers": ["CPUExecutionProvider", "CUDAExecutionProvider"],
        "onnxruntime_installed": True,
        "models_verified": False,
    }))
    diagnostics = engine.provider_diagnostics()
    assert diagnostics["requested_execution_providers"] == ["cuda"]
    assert diagnostics["requested_providers_available"] is True


def test_engine_provider_diagnostics_flags_missing_cuda(monkeypatch):
    from engine import FaceSwapEngine

    engine = FaceSwapEngine()
    engine.execution_providers = ["cuda"]
    monkeypatch.setattr(FaceSwapEngine, "runtime_diagnostics", staticmethod(lambda: {
        "execution_providers": ["CPUExecutionProvider"],
        "onnxruntime_installed": True,
        "models_verified": False,
    }))
    assert engine.provider_diagnostics()["requested_providers_available"] is False


def test_video_mux_uses_source_duration_without_shortest(monkeypatch, tmp_path):
    from engine import FaceSwapEngine

    engine = FaceSwapEngine()
    target = tmp_path / "source.mp4"
    target.write_bytes(b"video")
    source = tmp_path / "face.png"
    source.write_bytes(b"image")
    final = tmp_path / "final.mp4"
    commands = []

    def fake_run(command, **kwargs):
        commands.append(command)
        class Result:
            returncode = 0
            stderr = ""
            stdout = "9.75" if command[0] == "ffprobe" else ""
        if command[0] == "ffmpeg":
            final.write_bytes(b"muxed-video")
        return Result()

    monkeypatch.setattr(engine, "_run", lambda *_args, **_kwargs: (tmp_path / "swapped.mp4").write_bytes(b"swapped"))
    monkeypatch.setattr("engine.subprocess.run", fake_run)
    engine.swap_video_files(str(source), str(target), str(final))
    mux = commands[1]
    assert "-shortest" not in mux
    assert mux[mux.index("-t") + 1] == "9.750"
    assert "-map_metadata" in mux
    assert final.read_bytes() == b"muxed-video"


def test_engine_preflight_rejects_unavailable_selected_provider(monkeypatch):
    import pytest
    from engine import EngineNotReadyError, FaceSwapEngine

    engine = FaceSwapEngine()
    engine.execution_providers = ["cuda"]
    monkeypatch.setattr(FaceSwapEngine, "runtime_diagnostics", staticmethod(lambda: {
        "execution_providers": ["CPUExecutionProvider"],
        "onnxruntime_installed": True,
        "models_verified": False,
    }))
    with pytest.raises(EngineNotReadyError, match="لا يوجد مزود ONNX Runtime متاح"):
        engine.preflight()


def test_engine_preflight_reports_missing_configured_model_file(monkeypatch, tmp_path):
    import pytest
    from engine import EngineNotReadyError, FaceSwapEngine

    engine = FaceSwapEngine()
    engine.execution_providers = ["cpu"]
    engine.required_model_files = [tmp_path / "missing-model.onnx"]
    monkeypatch.setattr(FaceSwapEngine, "runtime_diagnostics", staticmethod(lambda: {
        "execution_providers": ["CPUExecutionProvider"],
        "onnxruntime_installed": True,
        "models_verified": False,
    }))
    with pytest.raises(EngineNotReadyError, match="ملفات النماذج المحددة غير موجودة"):
        engine.preflight()


def test_diagnostics_endpoint_does_not_claim_inference_verified():
    response = client.get("/api/diagnostics")
    assert response.status_code == 200
    payload = response.json()
    assert payload["models_verified"] is False
    assert payload["processing_verified"] is False
    assert "runtime_preflight_ready" in payload


def test_video_job_rejects_unavailable_runtime_before_storing_video(monkeypatch, tmp_path):
    from engine import EngineNotReadyError

    monkeypatch.setattr(main.face_swap_engine, "is_available", lambda: True)
    monkeypatch.setattr(main.face_swap_engine, "ffmpeg_available", lambda: True)
    monkeypatch.setattr(main.face_swap_engine, "preflight", lambda: (_ for _ in ()).throw(
        EngineNotReadyError("CUDA غير متاح")
    ))
    monkeypatch.setattr(main, "JOB_ROOT", tmp_path / "jobs")
    response = client.post(
        "/api/jobs/faceswap/video",
        files={
            "source": ("source.png", png_bytes(), "image/png"),
            "target": ("clip.mp4", b"fake-video", "video/mp4"),
        },
    )
    assert response.status_code == 503
    assert "CUDA غير متاح" in response.json()["detail"]
    assert not list((tmp_path / "jobs").glob("*"))


def test_probe_video_rejects_nan_duration(monkeypatch, tmp_path):
    import json
    from types import SimpleNamespace

    video = tmp_path / "sample.mp4"
    video.write_bytes(b"fake")
    monkeypatch.setattr(
        main.subprocess, "run",
        lambda *args, **kwargs: SimpleNamespace(
            returncode=0, stdout=json.dumps({
                "format": {"duration": "NaN"},
                "streams": [{"codec_type": "video", "width": 640, "height": 480}],
            }), stderr="",
        ),
    )
    with pytest.raises(ValueError, match="مدة الفيديو غير صالحة"):
        main.probe_video(video)


def test_probe_video_rejects_infinite_duration(monkeypatch, tmp_path):
    import json
    from types import SimpleNamespace

    video = tmp_path / "sample.mp4"
    video.write_bytes(b"fake")
    monkeypatch.setattr(
        main.subprocess, "run",
        lambda *args, **kwargs: SimpleNamespace(
            returncode=0, stdout=json.dumps({
                "format": {"duration": "Infinity"},
                "streams": [{"codec_type": "video", "width": 640, "height": 480}],
            }), stderr="",
        ),
    )
    with pytest.raises(ValueError, match="مدة الفيديو غير صالحة"):
        main.probe_video(video)


def test_backend_version_is_aligned_with_release():
    assert main.app.version == main.APP_VERSION
    assert client.get("/api/capabilities").json()["version"] == main.APP_VERSION


def test_engine_rejects_missing_source_or_target_before_running(monkeypatch, tmp_path):
    from engine import FaceSwapEngine
    import pytest

    engine = FaceSwapEngine()
    source = tmp_path / "source.png"
    target = tmp_path / "target.mp4"
    output = tmp_path / "out.mp4"
    with pytest.raises(ValueError, match="Source image is missing or empty"):
        engine._run(source, target, output, timeout=10)
    source.write_bytes(b"image")
    with pytest.raises(ValueError, match="Target media file is missing or empty"):
        engine._run(source, target, output, timeout=10)


def test_engine_rejects_non_finite_video_duration(monkeypatch, tmp_path):
    from engine import FaceSwapEngine
    import pytest
    from types import SimpleNamespace

    engine = FaceSwapEngine()
    source = tmp_path / "source.png"
    target = tmp_path / "target.mp4"
    source.write_bytes(b"image")
    target.write_bytes(b"video")
    monkeypatch.setattr(engine, "_run", lambda *_args, **_kwargs: (tmp_path / "swapped.mp4").write_bytes(b"swapped"))
    monkeypatch.setattr("engine.subprocess.run", lambda *args, **kwargs: SimpleNamespace(
        returncode=0, stdout="Infinity", stderr=""
    ))
    with pytest.raises(RuntimeError, match="finite positive"):
        engine.swap_video_files(str(source), str(target), str(tmp_path / "nested" / "final.mp4"))


def test_protected_api_fails_closed_if_secret_is_missing(monkeypatch):
    monkeypatch.setattr(main, "REQUIRE_API_KEY", True)
    monkeypatch.setattr(main, "API_KEY", "")
    response = client.post(
        "/api/enhance",
        files={"image": ("sample.png", png_bytes(), "image/png")},
    )
    assert response.status_code == 503
    assert "API_KEY" in response.json()["detail"]


def test_enhance_rejects_missing_or_wrong_api_key(monkeypatch):
    monkeypatch.setattr(main, "REQUIRE_API_KEY", False)
    monkeypatch.setattr(main, "API_KEY", "unit-test-secret")
    files = {"image": ("sample.png", png_bytes(), "image/png")}
    assert client.post("/api/enhance", files=files).status_code == 401
    assert client.post(
        "/api/enhance", files=files, headers={"X-API-Key": "wrong-secret"}
    ).status_code == 401
    assert client.post(
        "/api/enhance", files=files, headers={"X-API-Key": "unit-test-secret"}
    ).status_code == 200


def test_nonnegative_int_env_accepts_zero_and_positive_values(monkeypatch):
    monkeypatch.setenv("TEST_NONNEGATIVE_SETTING", "0")
    assert main.nonnegative_int_env("TEST_NONNEGATIVE_SETTING", 5) == 0
    monkeypatch.setenv("TEST_NONNEGATIVE_SETTING", "12")
    assert main.nonnegative_int_env("TEST_NONNEGATIVE_SETTING", 5) == 12


def test_nonnegative_int_env_rejects_negative_and_non_integer(monkeypatch):
    for raw in ("-1", "many"):
        monkeypatch.setenv("TEST_NONNEGATIVE_SETTING", raw)
        with pytest.raises(RuntimeError, match="zero or a positive integer"):
            main.nonnegative_int_env("TEST_NONNEGATIVE_SETTING", 5)


def test_processed_video_validation_rejects_non_video_output(monkeypatch, tmp_path):
    output = tmp_path / "result.mp4"
    output.write_bytes(b"not-a-real-mp4-file")
    monkeypatch.setattr(main, "probe_video", lambda _path: (_ for _ in ()).throw(ValueError("ملف غير صالح")))
    with pytest.raises(ValueError, match="الناتج غير صالح"):
        main.validate_processed_video(output)


def test_job_endpoints_reject_non_uuid_identifiers():
    assert client.get("/api/jobs/../../etc/passwd").status_code in {404, 422}
    assert client.get("/api/jobs/not-a-job-id").status_code == 404
    assert client.get("/api/jobs/not-a-job-id/result").status_code == 404


def test_engine_preflight_reports_missing_requested_provider(monkeypatch):
    from engine import FaceSwapEngine, EngineNotReadyError

    engine = FaceSwapEngine()
    engine.execution_providers = ["cuda"]
    monkeypatch.setattr(engine, "runtime_diagnostics", lambda: {
        "python_version": "3.11.0", "onnxruntime_installed": True,
        "onnxruntime_version": "1.20.0",
        "execution_providers": ["CPUExecutionProvider"],
        "cuda_provider_available": False, "tensorrt_provider_available": False,
    })
    engine.required_model_files = []
    with pytest.raises(EngineNotReadyError, match="cuda"):
        engine.preflight()


def test_engine_preflight_rejects_missing_configured_model(monkeypatch, tmp_path):
    from engine import FaceSwapEngine, EngineNotReadyError

    engine = FaceSwapEngine()
    engine.execution_providers = ["cpu"]
    monkeypatch.setattr(engine, "runtime_diagnostics", lambda: {
        "python_version": "3.11.0", "onnxruntime_installed": True,
        "onnxruntime_version": "1.20.0",
        "execution_providers": ["CPUExecutionProvider"],
        "cuda_provider_available": False, "tensorrt_provider_available": False,
    })
    engine.required_model_files = [tmp_path / "missing-model.onnx"]
    with pytest.raises(EngineNotReadyError, match="missing-model.onnx"):
        engine.preflight()


def test_engine_preflight_accepts_cpu_and_present_model(monkeypatch, tmp_path):
    from engine import FaceSwapEngine

    model = tmp_path / "model.onnx"
    model.write_bytes(b"not-a-real-model-but-present")
    engine = FaceSwapEngine()
    engine.execution_providers = ["cpu"]
    monkeypatch.setattr(engine, "runtime_diagnostics", lambda: {
        "python_version": "3.11.0", "onnxruntime_installed": True,
        "onnxruntime_version": "1.20.0",
        "execution_providers": ["CPUExecutionProvider"],
        "cuda_provider_available": False, "tensorrt_provider_available": False,
    })
    engine.required_model_files = [model]
    result = engine.preflight()
    assert result["provider_preflight_ready"] is True
    assert result["required_model_files_present"] is True
    assert result["models_verified"] is False


def test_processed_image_validation_accepts_valid_png(tmp_path):
    output = tmp_path / "result.png"
    Image.new("RGB", (24, 16), (10, 20, 30)).save(output, format="PNG")
    assert main.validate_processed_image(output) == {
        "width": 24, "height": 16, "format": "PNG"
    }


def test_processed_image_validation_rejects_corrupt_output(tmp_path):
    output = tmp_path / "result.png"
    output.write_bytes(b"not-a-png-file")
    with pytest.raises(ValueError, match="الصورة الناتجة غير صالحة|الصورة الناتج غير صالح"):
        main.validate_processed_image(output)


def test_processed_image_validation_rejects_oversized_dimensions(monkeypatch, tmp_path):
    output = tmp_path / "result.png"
    Image.new("RGB", (20, 20)).save(output, format="PNG")
    monkeypatch.setattr(main, "MAX_IMAGE_PIXELS", 100)
    with pytest.raises(ValueError, match="أبعاد الصورة الناتجة"):
        main.validate_processed_image(output)


def test_faceswap_rejects_corrupt_engine_image_output(monkeypatch):
    monkeypatch.setattr(main.face_swap_engine, "is_available", lambda: True)
    monkeypatch.setattr(main.face_swap_engine, "preflight", lambda: {"provider_preflight_ready": True})

    def fake_swap(_source, _target, output_path):
        Path(output_path).write_bytes(b"not-a-png-file")
        return output_path

    monkeypatch.setattr(main.face_swap_engine, "swap_faces", fake_swap)
    response = client.post("/api/faceswap", files={
        "source": ("source.png", png_bytes(), "image/png"),
        "target": ("target.png", png_bytes(), "image/png"),
    })
    assert response.status_code == 500
    assert "الصورة الناتج غير صالح" in response.json()["detail"]


def test_private_instance_defaults_to_two_minute_300_mib_video_caps():
    response = client.get("/api/capabilities")
    assert response.status_code == 200
    limits = response.json()["limits"]
    assert limits["image_bytes"] is None
    assert limits["video_bytes"] == 300 * 1024 * 1024
    assert limits["video_seconds"] == 120
    assert limits["image_max_pixels"] is None
    assert limits["video_max_pixels"] is None
    assert limits["active_jobs"] is None
    assert limits["job_retention_seconds"] is None


def test_video_duration_limit_is_optional_and_configurable(monkeypatch):
    monkeypatch.setattr(main, "MAX_VIDEO_SECONDS", 0)
    assert main.MAX_VIDEO_SECONDS == 0  # zero means unlimited duration
    monkeypatch.setattr(main, "MAX_VIDEO_SECONDS", 900)
    assert main.MAX_VIDEO_SECONDS == 900


def test_job_cleanup_is_disabled_when_retention_is_unlimited(monkeypatch):
    monkeypatch.setattr(main, "JOB_TTL_SECONDS", 0)
    monkeypatch.setattr(main, "JOBS", {"a" * 32: {
        "job_id": "a" * 32, "status": "completed", "created_at": 1,
    }})
    main.cleanup_old_jobs()
    assert "a" * 32 in main.JOBS


def test_stream_upload_has_no_software_size_cap_when_zero(tmp_path):
    import asyncio
    from starlette.datastructures import UploadFile
    upload = UploadFile(filename="clip.mp4", file=io.BytesIO(b"0123456789"))
    destination = tmp_path / "clip.mp4"
    written = asyncio.run(main.stream_upload_to_path(upload, destination, 0))
    assert written == 10
    assert destination.read_bytes() == b"0123456789"


def test_audio_status_reports_local_runners_only():
    response = client.get("/api/audio/status")
    assert response.status_code == 200
    data = response.json()
    assert data["local_only"] is True
    assert data["paid_external_services"] is False
    assert data["runners"]["voice_clone"]["available"] is False


def test_voice_clone_requires_explicit_consent():
    response = client.post(
        "/api/audio/voice-clone",
        data={"text": "اختبار", "language": "ar"},
        files={"reference_audio": ("voice.wav", b"fake-audio", "audio/wav")},
    )
    assert response.status_code == 400
    assert "إذن" in response.json()["detail"]


def test_voice_clone_reports_local_runner_missing(monkeypatch, tmp_path):
    monkeypatch.setattr(main, "AUDIO_OUTPUT_ROOT", tmp_path / "audio")
    monkeypatch.setattr(main.audio_engine, "runners", {"voice_clone": "", "voice_convert": "", "music": ""})
    monkeypatch.setattr("main.shutil.which", lambda _name: None)
    response = client.post(
        "/api/audio/voice-clone",
        data={"text": "مرحبا", "language": "ar", "consent_confirmed": "true"},
        files={"reference_audio": ("voice.wav", b"fake-audio", "audio/wav")},
    )
    assert response.status_code == 503
    assert "غير مثبت" in response.json()["detail"]


def test_music_generation_reports_local_runner_missing(monkeypatch, tmp_path):
    monkeypatch.setattr(main, "AUDIO_OUTPUT_ROOT", tmp_path / "audio")
    monkeypatch.setattr(main.audio_engine, "runners", {"voice_clone": "", "voice_convert": "", "music": ""})
    response = client.post("/api/audio/music", data={"prompt": "أغنية عربية", "lyrics": "كلمات", "duration_seconds": "30"})
    assert response.status_code == 503
    assert "غير مثبت" in response.json()["detail"]


def test_music_rejects_non_positive_duration():
    response = client.post("/api/audio/music", data={"prompt": "موسيقى", "duration_seconds": "0"})
    assert response.status_code == 400


def test_audio_engine_command_contract(monkeypatch, tmp_path):
    from audio_engine import LocalAudioEngine
    runner = tmp_path / "runner.py"
    runner.write_text("# local model adapter", encoding="utf-8")
    engine = LocalAudioEngine()
    engine.runners["voice_clone"] = str(runner)
    commands = []
    class Result:
        returncode = 0
        stdout = "audio\n"
        stderr = ""
    def fake_run(command, **kwargs):
        commands.append(command)
        if command[0] == "ffprobe":
            return Result()
        Path(command[command.index("--output-path") + 1]).write_bytes(b"x" * 256)
        return Result()
    monkeypatch.setattr("audio_engine.subprocess.run", fake_run)
    monkeypatch.setattr("audio_engine.shutil.which", lambda _name: "/usr/bin/ffprobe")
    output = tmp_path / "voice.wav"
    engine.clone_voice(tmp_path / "reference.wav", "مرحبا", "ar", output)
    assert output.is_file()
    assert "--reference-audio" in commands[0]
    assert "--text" in commands[0]
    assert "--language" in commands[0]


def test_voice_conversion_requires_explicit_consent():
    response = client.post(
        "/api/audio/voice-convert",
        files={
            "input_audio": ("input.wav", b"fake", "audio/wav"),
            "target_voice_audio": ("target.wav", b"fake", "audio/wav"),
        },
    )
    assert response.status_code == 400
    assert "إذن" in response.json()["detail"]


def test_audio_upload_rejects_unsupported_extension(monkeypatch, tmp_path):
    monkeypatch.setattr(main, "AUDIO_OUTPUT_ROOT", tmp_path / "audio")
    response = client.post(
        "/api/audio/voice-clone",
        data={"text": "مرحبا", "language": "ar", "consent_confirmed": "true"},
        files={"reference_audio": ("voice.exe", b"not audio", "application/octet-stream")},
    )
    assert response.status_code == 400
    assert "صيغة الصوت" in response.json()["detail"]


def test_worker_endpoint_requires_valid_coordinator_secret(monkeypatch):
    monkeypatch.setattr(main, "API_KEY", "worker-secret")
    response = client.post("/api/worker/process", files={
        "source": ("source.png", png_bytes(), "image/png"),
        "target": ("clip.mp4", b"fake", "video/mp4"),
    })
    assert response.status_code == 401


def test_worker_health_is_not_ready_without_operator_attestation(monkeypatch):
    monkeypatch.delenv("GPU_WORKER_READY", raising=False)
    response = client.get("/health")
    assert response.status_code == 200
    assert response.json()["gpu_worker_ready"] is False


class FakeStreamingResponse:
    def __init__(self, chunks, content_type="video/mp4"):
        self.headers = {"content-type": content_type}
        self.chunks = chunks
    async def aiter_bytes(self, _chunk_size):
        for chunk in self.chunks:
            yield chunk


def test_remote_worker_result_is_streamed_and_bounded(tmp_path):
    import asyncio
    destination = tmp_path / "result.mp4"
    size = asyncio.run(main.stream_worker_result(
        FakeStreamingResponse([b"1234", b"5678"]), destination, 8
    ))
    assert size == 8
    assert destination.read_bytes() == b"12345678"


def test_remote_worker_result_over_limit_is_removed(tmp_path):
    import asyncio
    destination = tmp_path / "result.mp4"
    with pytest.raises(RuntimeError, match="تجاوز الحد"):
        asyncio.run(main.stream_worker_result(
            FakeStreamingResponse([b"1234", b"5678", b"9"]), destination, 8
        ))
    assert not destination.exists()


def test_remote_worker_result_rejects_wrong_content_type(tmp_path):
    import asyncio
    destination = tmp_path / "result.mp4"
    with pytest.raises(RuntimeError, match="نوع ملف غير متوقع"):
        asyncio.run(main.stream_worker_result(
            FakeStreamingResponse([b"1234"], "text/html"), destination, 100
        ))
    assert not destination.exists()


def test_remote_worker_result_rejects_empty_body(tmp_path):
    import asyncio
    destination = tmp_path / "result.mp4"
    with pytest.raises(RuntimeError, match="فارغ"):
        asyncio.run(main.stream_worker_result(FakeStreamingResponse([]), destination, 100))
    assert not destination.exists()


def test_worker_failover_requires_explicit_preflight_rejection():
    preflight = {"X-Worker-Stage": "preflight"}
    assert main.worker_rejection_is_retryable(400, preflight)
    assert main.worker_rejection_is_retryable(429, preflight)
    assert main.worker_rejection_is_retryable(503, preflight)
    assert not main.worker_rejection_is_retryable(400, {})
    assert not main.worker_rejection_is_retryable(503, {})
    assert not main.worker_rejection_is_retryable(500, preflight)
    assert not main.worker_rejection_is_retryable(502, preflight)


def test_gpu_worker_readiness_requires_auth_and_configured_models(monkeypatch):
    monkeypatch.setattr(main, "API_KEY", "worker-secret")
    monkeypatch.setattr(main, "REQUIRE_API_KEY", True)
    monkeypatch.setenv("GPU_WORKER_READY", "true")
    monkeypatch.setattr(main.face_swap_engine, "is_available", lambda: True)
    monkeypatch.setattr(main.face_swap_engine, "ffmpeg_available", lambda: True)
    monkeypatch.setattr(main.face_swap_engine, "execution_providers", ["cuda"])
    monkeypatch.setattr(main.face_swap_engine, "provider_diagnostics", lambda: {
        "gpu_hardware_detected": True, "cuda_provider_available": True,
        "provider_preflight_ready": True, "required_model_files_present": False,
    })
    response = client.get("/health")
    assert response.status_code == 200
    assert response.json()["gpu_worker_ready"] is False


def test_gpu_worker_readiness_requires_api_key_protection(monkeypatch):
    monkeypatch.setattr(main, "API_KEY", "")
    monkeypatch.setattr(main, "REQUIRE_API_KEY", False)
    monkeypatch.setenv("GPU_WORKER_READY", "true")
    monkeypatch.setattr(main.face_swap_engine, "is_available", lambda: True)
    monkeypatch.setattr(main.face_swap_engine, "ffmpeg_available", lambda: True)
    monkeypatch.setattr(main.face_swap_engine, "execution_providers", ["cuda"])
    monkeypatch.setattr(main.face_swap_engine, "provider_diagnostics", lambda: {
        "gpu_hardware_detected": True, "cuda_provider_available": True,
        "provider_preflight_ready": True, "required_model_files_present": True,
    })
    response = client.get("/health")
    assert response.json()["gpu_worker_ready"] is False


def test_worker_health_endpoint_requires_api_key_and_confirms_authenticated_access(monkeypatch):
    monkeypatch.setattr(main, "API_KEY", "worker-secret")
    monkeypatch.setattr(main, "REQUIRE_API_KEY", True)
    denied = client.get("/api/worker/health")
    assert denied.status_code == 401
    accepted = client.get("/api/worker/health", headers={"X-API-Key": "worker-secret"})
    assert accepted.status_code == 200
    assert accepted.json()["api_key_protected"] is True


def test_public_health_does_not_claim_request_was_authenticated(monkeypatch):
    monkeypatch.setattr(main, "API_KEY", "worker-secret")
    monkeypatch.setattr(main, "REQUIRE_API_KEY", True)
    response = client.get("/health")
    assert response.status_code == 200
    assert "api_key_protected" not in response.json()


def test_gpu_image_worker_rejects_unverified_gpu(monkeypatch):
    async def not_ready():
        return {"gpu_worker_ready": False}
    monkeypatch.setattr(main, "health", not_ready)
    response = client.post(
        "/api/worker/process-image",
        files={
            "source": ("source.png", png_bytes(), "image/png"),
            "target": ("target.png", png_bytes(), "image/png"),
        },
    )
    assert response.status_code == 503
    assert response.headers.get("x-worker-stage") == "preflight"


def test_gpu_image_worker_runs_and_returns_png_when_ready(monkeypatch):
    async def ready():
        return {"gpu_worker_ready": True}
    monkeypatch.setattr(main, "health", ready)
    monkeypatch.setattr(main, "ensure_engine_ready", lambda: None)

    def fake_swap(_source, _target, output_path):
        Image.new("RGB", (24, 24), (10, 20, 30)).save(output_path, format="PNG")
        return output_path

    monkeypatch.setattr(main.face_swap_engine, "swap_faces", fake_swap)
    response = client.post(
        "/api/worker/process-image",
        files={
            "source": ("source.png", png_bytes(), "image/png"),
            "target": ("target.png", png_bytes(), "image/png"),
        },
    )
    assert response.status_code == 200
    assert response.headers["content-type"] == "image/png"
    assert response.content.startswith(b"\x89PNG\r\n\x1a\n")


def test_image_worker_dispatch_returns_none_when_pool_empty(monkeypatch):
    import asyncio
    class EmptyPool:
        workers = []
    monkeypatch.setattr(main, "worker_pool", EmptyPool())
    assert asyncio.run(main.dispatch_image_to_worker(png_bytes(), png_bytes())) is None


def test_image_worker_dispatch_validates_and_returns_remote_png(monkeypatch):
    import asyncio
    from types import SimpleNamespace
    import httpx

    worker = SimpleNamespace(worker_id="gpu-test", base_url="https://gpu.example", api_key="secret")

    class FakePool:
        workers = [worker]
        reserved = False
        async def reserve_candidate(self, exclude_ids=None):
            if self.reserved:
                return None
            self.reserved = True
            return worker
        async def mark_success(self, worker_id):
            assert worker_id == worker.worker_id
        async def consume_quota(self, worker_id):
            assert worker_id == worker.worker_id
        async def release_reservation(self, worker_id, consume_quota=False):
            assert worker_id == worker.worker_id
        async def mark_failure(self, worker_id, reason, cooldown_seconds=None):
            raise AssertionError(f"unexpected worker failure: {reason}")

    class FakeResponse:
        status_code = 200
        headers = {"content-type": "image/png"}
        async def __aenter__(self): return self
        async def __aexit__(self, *args): return False
        async def aiter_bytes(self, chunk_size):
            data = png_bytes()
            for offset in range(0, len(data), chunk_size):
                yield data[offset:offset + chunk_size]
        async def aread(self): return b""

    class FakeClient:
        def __init__(self, *args, **kwargs): pass
        async def __aenter__(self): return self
        async def __aexit__(self, *args): return False
        def stream(self, method, url, **kwargs):
            assert method == "POST"
            assert url == "https://gpu.example/api/worker/process-image"
            assert kwargs["headers"]["X-API-Key"] == "secret"
            return FakeResponse()

    pool = FakePool()
    monkeypatch.setattr(main, "worker_pool", pool)
    monkeypatch.setattr(httpx, "AsyncClient", FakeClient)
    result = asyncio.run(main.dispatch_image_to_worker(png_bytes(), png_bytes()))
    assert result.startswith(b"\x89PNG\r\n\x1a\n")


def test_capabilities_advertise_image_worker_without_claiming_gpu_inference():
    response = client.get("/api/capabilities")
    assert response.status_code == 200
    data = response.json()
    assert data["version"] == "1.28.17"
    dispatch = data["features"]["remote_gpu_dispatch"]
    assert dispatch["image_worker_endpoint"] == "/api/worker/process-image"
    assert dispatch["gpu_inference_verified"] is False


def test_video_limits_remain_two_minutes_and_300_mib():
    response = client.get("/api/capabilities")
    limits = response.json()["limits"]
    assert limits["video_bytes"] == 300 * 1024 * 1024
    assert limits["video_seconds"] == 120


def test_gpu_worker_readiness_requires_successful_real_self_test(monkeypatch):
    monkeypatch.setattr(main, "API_KEY", "worker-secret")
    monkeypatch.setattr(main, "REQUIRE_API_KEY", True)
    monkeypatch.setenv("GPU_WORKER_READY", "true")
    monkeypatch.setattr(main, "GPU_SELF_TEST_PASSED", False)
    monkeypatch.setattr(main.face_swap_engine, "is_available", lambda: True)
    monkeypatch.setattr(main.face_swap_engine, "ffmpeg_available", lambda: True)
    monkeypatch.setattr(main.face_swap_engine, "execution_providers", ["cuda"])
    monkeypatch.setattr(main.face_swap_engine, "provider_diagnostics", lambda: {
        "gpu_hardware_detected": True, "cuda_provider_available": True,
        "provider_preflight_ready": True, "required_model_files_present": True,
    })
    response = client.get("/health")
    assert response.status_code == 200
    assert response.json()["gpu_worker_ready"] is False
    assert response.json()["gpu_self_test_passed"] is False


def test_gpu_self_test_requires_authentication(monkeypatch):
    monkeypatch.setattr(main, "API_KEY", "worker-secret")
    monkeypatch.setattr(main, "REQUIRE_API_KEY", True)
    response = client.post("/api/worker/self-test", files={
        "source": ("source.png", png_bytes(), "image/png"),
        "target": ("target.png", png_bytes(), "image/png"),
    })
    assert response.status_code == 401


def test_gpu_self_test_rejects_missing_cuda_hardware(monkeypatch):
    monkeypatch.setattr(main, "API_KEY", "worker-secret")
    monkeypatch.setattr(main, "REQUIRE_API_KEY", True)
    monkeypatch.setattr(main, "GPU_SELF_TEST_PASSED", False)
    monkeypatch.setattr(main.face_swap_engine, "provider_diagnostics", lambda: {
        "gpu_hardware_detected": False, "cuda_provider_available": True,
        "provider_preflight_ready": True, "required_model_files_present": True,
    })
    response = client.post("/api/worker/self-test", headers={"X-API-Key": "worker-secret"}, files={
        "source": ("source.png", png_bytes(), "image/png"),
        "target": ("target.png", png_bytes(), "image/png"),
    })
    assert response.status_code == 503
    assert main.GPU_SELF_TEST_PASSED is False


def test_gpu_self_test_sets_readiness_only_after_valid_inference(monkeypatch):
    monkeypatch.setattr(main, "API_KEY", "worker-secret")
    monkeypatch.setattr(main, "REQUIRE_API_KEY", True)
    monkeypatch.setattr(main, "GPU_SELF_TEST_PASSED", False)
    monkeypatch.setattr(main.face_swap_engine, "execution_providers", ["cuda"])
    monkeypatch.setattr(main.face_swap_engine, "provider_diagnostics", lambda: {
        "gpu_hardware_detected": True, "cuda_provider_available": True,
        "provider_preflight_ready": True, "required_model_files_present": True,
        "gpu_devices": [{"name": "Test NVIDIA", "memory_total_mb": "8192"}],
    })
    monkeypatch.setattr(main, "ensure_engine_ready", lambda: None)
    def fake_swap(_source, _target, output_path):
        Image.new("RGB", (32, 32), (30, 40, 50)).save(output_path, format="PNG")
    monkeypatch.setattr(main.face_swap_engine, "swap_faces", fake_swap)
    response = client.post("/api/worker/self-test", headers={"X-API-Key": "worker-secret"}, files={
        "source": ("source.png", png_bytes(), "image/png"),
        "target": ("target.png", png_bytes(), "image/png"),
    })
    assert response.status_code == 200, response.text
    assert response.json()["passed"] is True
    assert main.GPU_SELF_TEST_PASSED is True
    assert main.GPU_SELF_TEST_PROVIDER == "cuda"


def test_gpu_self_test_refuses_unprotected_worker(monkeypatch):
    monkeypatch.setattr(main, "API_KEY", "")
    monkeypatch.setattr(main, "REQUIRE_API_KEY", False)
    response = client.post("/api/worker/self-test", files={
        "source": ("source.png", png_bytes(), "image/png"),
        "target": ("target.png", png_bytes(), "image/png"),
    })
    assert response.status_code == 503


def test_fixed_video_caps_cannot_be_raised_by_environment(monkeypatch):
    monkeypatch.setenv("MAX_VIDEO_SIZE", str(900 * 1024 * 1024))
    monkeypatch.setenv("MAX_VIDEO_SECONDS", "900")
    monkeypatch.setenv("MAX_WORKER_RESULT_SIZE", str(2 * 1024 * 1024 * 1024))
    assert main.hard_capped_limit_env("MAX_VIDEO_SIZE", 300 * 1024 * 1024) == 300 * 1024 * 1024
    assert main.hard_capped_limit_env("MAX_VIDEO_SECONDS", 120) == 120
    assert main.hard_capped_limit_env("MAX_WORKER_RESULT_SIZE", 600 * 1024 * 1024) == 600 * 1024 * 1024


def test_video_caps_can_be_lowered_but_zero_does_not_disable_them(monkeypatch):
    monkeypatch.setenv("MAX_VIDEO_SIZE", str(25 * 1024 * 1024))
    monkeypatch.setenv("MAX_VIDEO_SECONDS", "45")
    assert main.hard_capped_limit_env("MAX_VIDEO_SIZE", 300 * 1024 * 1024) == 25 * 1024 * 1024
    assert main.hard_capped_limit_env("MAX_VIDEO_SECONDS", 120) == 45
    monkeypatch.setenv("MAX_VIDEO_SECONDS", "0")
    assert main.hard_capped_limit_env("MAX_VIDEO_SECONDS", 120) == 120


def test_processed_video_rejects_duration_over_hard_limit(monkeypatch, tmp_path):
    output = tmp_path / "result.mp4"
    output.write_bytes(b"0" * 32)
    monkeypatch.setattr(main, "MAX_WORKER_RESULT_SIZE", 600 * 1024 * 1024)
    monkeypatch.setattr(main, "MAX_VIDEO_SECONDS", 120)
    monkeypatch.setattr(main, "probe_video", lambda _path: {
        "duration": 120.01, "video_streams": [{"codec_name": "h264"}], "streams": []
    })
    with pytest.raises(ValueError, match="120"):
        main.validate_processed_video(output)


def test_processed_video_rejects_output_larger_than_result_cap(monkeypatch, tmp_path):
    output = tmp_path / "result.mp4"
    output.write_bytes(b"0" * 64)
    monkeypatch.setattr(main, "MAX_WORKER_RESULT_SIZE", 32)
    with pytest.raises(ValueError, match="حجم الفيديو الناتج"):
        main.validate_processed_video(output)


def test_public_job_includes_processing_stage_without_secrets():
    job = {
        "job_id": "a" * 32, "status": "processing", "progress": 82,
        "message": "validating", "created_at": 1.0, "stage": "validating_result",
        "processing_backend": "remote_gpu", "worker_id": "gpu-east", "updated_at": 2.0,
    }
    public = main.public_job(job)
    assert public["stage"] == "validating_result"
    assert public["processing_backend"] == "remote_gpu"
    assert public["worker_id"] == "gpu-east"
    assert "api_key" not in public
