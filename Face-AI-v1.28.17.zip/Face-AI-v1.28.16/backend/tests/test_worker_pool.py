import json
import os
import pytest

from worker_pool import Worker, WorkerPool


def test_worker_public_view_never_exposes_api_key():
    worker = Worker("gpu-a", "https://gpu.example", "SECRET", priority=2)
    assert "SECRET" not in json.dumps(worker.public())
    assert "api_key" not in worker.public()


def test_eligibility_respects_enabled_health_capacity_and_quota():
    worker = Worker("gpu-a", "https://gpu.example", "secret", max_concurrent=2, quota_jobs=1)
    assert not worker.eligible
    worker.healthy = True
    assert worker.eligible
    worker.active_jobs = 2
    assert not worker.eligible
    worker.active_jobs = 0
    worker.quota_jobs = 0
    assert not worker.eligible
    worker.quota_jobs = 1
    worker.enabled = False
    assert not worker.eligible


def test_env_config_requires_https_and_secret(monkeypatch):
    monkeypatch.setenv("GPU_WORKERS_JSON", json.dumps([
        {"id": "bad", "url": "http://gpu.example", "api_key": "x"}
    ]))
    with pytest.raises(RuntimeError, match="HTTPS"):
        WorkerPool.from_env()


def test_env_config_rejects_duplicate_ids(monkeypatch):
    monkeypatch.setenv("GPU_WORKERS_JSON", json.dumps([
        {"id": "same", "url": "https://one.example", "api_key": "x"},
        {"id": "same", "url": "https://two.example", "api_key": "y"},
    ]))
    with pytest.raises(RuntimeError, match="unique"):
        WorkerPool.from_env()


def test_env_config_rejects_negative_quota(monkeypatch):
    monkeypatch.setenv("GPU_WORKERS_JSON", json.dumps([
        {"id": "gpu", "url": "https://gpu.example", "api_key": "x", "quota_jobs": -1}
    ]))
    with pytest.raises(RuntimeError, match="invalid"):
        WorkerPool.from_env()


def test_empty_pool_has_no_candidate():
    import asyncio
    assert asyncio.run(WorkerPool().select_candidate()) is None


def test_probe_requires_verified_gpu_readiness(monkeypatch):
    from io import BytesIO
    from unittest.mock import patch

    class FakeResponse(BytesIO):
        status = 200
        def __enter__(self): return self
        def __exit__(self, *args): self.close()

    worker = Worker("gpu", "https://gpu.example", "secret")
    payload = {"status": "online", "api_key_required": True, "api_key_protected": True,
               "runtime": {"gpu_hardware_detected": True,
               "cuda_provider_available": True}, "processing_ready": False}
    class FakeOpener:
        def open(self, request, timeout):
            assert request.full_url.endswith("/api/worker/health")
            assert request.get_header("X-api-key") == "secret"
            return FakeResponse(json.dumps(payload).encode())
    with patch("urllib.request.build_opener", return_value=FakeOpener()):
        ready, _, error = WorkerPool._probe(worker, 1)
    assert not ready
    assert "not verified" in error


def test_probe_accepts_explicit_gpu_worker_ready():
    from io import BytesIO
    from unittest.mock import patch

    class FakeResponse(BytesIO):
        status = 200
        def __enter__(self): return self
        def __exit__(self, *args): self.close()

    worker = Worker("gpu", "https://gpu.example", "secret")
    payload = {"status": "online", "gpu_worker_ready": True, "api_key_required": True, "api_key_protected": True}
    class FakeOpener:
        def open(self, request, timeout):
            assert request.full_url.endswith("/api/worker/health")
            return FakeResponse(json.dumps(payload).encode())
    with patch("urllib.request.build_opener", return_value=FakeOpener()):
        ready, details, error = WorkerPool._probe(worker, 1)
    assert ready and error is None
    assert details["gpu_worker_ready"] is True


def test_reservation_is_atomic_and_respects_worker_capacity():
    import asyncio
    worker = Worker("gpu", "https://gpu.example", "secret", max_concurrent=1)
    worker.healthy = True
    pool = WorkerPool([worker])
    async def no_refresh(): return pool.snapshot()
    pool.refresh = no_refresh
    async def run():
        first = await pool.reserve_candidate()
        second = await pool.reserve_candidate()
        assert first is worker
        assert second is None
        assert worker.active_jobs == 1
    asyncio.run(run())


def test_release_reservation_consumes_quota_only_when_requested():
    import asyncio
    worker = Worker("gpu", "https://gpu.example", "secret", quota_jobs=3)
    worker.active_jobs = 1
    pool = WorkerPool([worker])
    async def run():
        assert await pool.release_reservation("gpu")
        assert worker.active_jobs == 0
        assert worker.quota_jobs == 3
        worker.active_jobs = 1
        assert await pool.release_reservation("gpu", consume_quota=True)
        assert worker.active_jobs == 0
        assert worker.quota_jobs == 2
        assert not await pool.release_reservation("missing")
    asyncio.run(run())


def test_reservation_does_not_expose_worker_secret():
    import asyncio
    worker = Worker("gpu", "https://gpu.example", "TOP-SECRET")
    worker.healthy = True
    pool = WorkerPool([worker])
    async def no_refresh(): return pool.snapshot()
    pool.refresh = no_refresh
    async def run():
        chosen = await pool.reserve_candidate()
        assert chosen is worker
        assert "TOP-SECRET" not in json.dumps(pool.snapshot())
    asyncio.run(run())


def test_reserve_candidate_can_skip_failed_worker():
    import asyncio
    first = Worker("a", "https://a.example", "secret", priority=1)
    second = Worker("b", "https://b.example", "secret", priority=2)
    first.healthy = second.healthy = True
    pool = WorkerPool([first, second])
    async def no_refresh(): return pool.snapshot()
    pool.refresh = no_refresh
    async def run():
        chosen = await pool.reserve_candidate(exclude_ids={"a"})
        assert chosen is second
        assert second.active_jobs == 1
    asyncio.run(run())


def test_consume_quota_only_changes_quota_not_active_reservations():
    import asyncio
    worker = Worker("gpu", "https://gpu.example", "secret", quota_jobs=2)
    worker.active_jobs = 1
    pool = WorkerPool([worker])
    async def run():
        assert await pool.consume_quota("gpu")
        assert worker.quota_jobs == 1
        assert worker.active_jobs == 1
        assert not await pool.consume_quota("missing")
    asyncio.run(run())


def test_failed_worker_enters_cooldown_and_is_not_eligible():
    import asyncio
    worker = Worker("gpu", "https://gpu.example", "secret")
    worker.healthy = True
    pool = WorkerPool([worker], cooldown_seconds=30)
    async def run():
        assert await pool.mark_failure("gpu", "dispatch timed out")
        assert worker.consecutive_failures == 1
        assert worker.cooldown_until > 0
        assert not worker.eligible
        assert "dispatch timed out" in worker.public()["last_failure"]
        assert await pool.mark_success("gpu")
        assert worker.consecutive_failures == 0
        assert worker.cooldown_until == 0
        assert worker.eligible
    asyncio.run(run())

def test_worker_cooldown_backoff_is_bounded():
    import asyncio
    worker = Worker("gpu", "https://gpu.example", "secret")
    pool = WorkerPool([worker], cooldown_seconds=10)
    async def run():
        for _ in range(10):
            await pool.mark_failure("gpu", "failure")
        remaining = worker.cooldown_until - __import__("time").monotonic()
        assert 0 < remaining <= 1800
    asyncio.run(run())

def test_failure_state_is_public_but_secret_is_not():
    worker = Worker("gpu", "https://gpu.example", "NEVER-EXPOSE", last_failure="bad response")
    public = worker.public()
    assert public["last_failure"] == "bad response"
    assert "NEVER-EXPOSE" not in json.dumps(public)


def test_probe_rejects_gpu_worker_without_api_key_protection():
    from io import BytesIO
    from unittest.mock import patch

    class FakeResponse(BytesIO):
        status = 200
        def __enter__(self): return self
        def __exit__(self, *args): self.close()

    worker = Worker("gpu", "https://gpu.example", "secret")
    payload = {"status": "online", "gpu_worker_ready": True,
               "api_key_required": False, "api_key_protected": False}
    class FakeOpener:
        def open(self, request, timeout):
            return FakeResponse(json.dumps(payload).encode())
    with patch("urllib.request.build_opener", return_value=FakeOpener()):
        ready, _, error = WorkerPool._probe(worker, 1)
    assert not ready
    assert "not verified" in error


def test_quota_and_cooldown_persist_across_pool_restart(tmp_path):
    import asyncio
    state = tmp_path / "worker-state.json"
    worker = Worker("gpu-a", "https://gpu.example", "SECRET", quota_jobs=5)
    pool = WorkerPool([worker], cooldown_seconds=20, state_path=str(state))
    async def update():
        assert await pool.consume_quota("gpu-a")
        assert await pool.mark_failure("gpu-a", "temporary dispatch error")
    asyncio.run(update())
    saved = state.read_text(encoding="utf-8")
    assert "SECRET" not in saved
    restored_worker = Worker("gpu-a", "https://gpu.example", "NEW-SECRET", quota_jobs=5)
    restored = WorkerPool([restored_worker], cooldown_seconds=20, state_path=str(state))
    assert restored_worker.quota_jobs == 4
    assert restored_worker.consecutive_failures == 1
    assert restored_worker.cooldown_until > __import__("time").monotonic()
    assert restored_worker.last_failure == "temporary dispatch error"


def test_persisted_quota_never_increases_configured_quota(tmp_path):
    import asyncio
    state = tmp_path / "worker-state.json"
    state.write_text(json.dumps({"schema": 1, "workers": {
        "gpu-a": {"quota_jobs_remaining": 9, "consecutive_failures": 0,
                  "cooldown_until_epoch": 0, "last_failure": None}
    }}), encoding="utf-8")
    worker = Worker("gpu-a", "https://gpu.example", "secret", quota_jobs=3)
    WorkerPool([worker], state_path=str(state))
    assert worker.quota_jobs == 3


def test_corrupt_worker_state_does_not_prevent_startup(tmp_path):
    state = tmp_path / "worker-state.json"
    state.write_text("not-json", encoding="utf-8")
    worker = Worker("gpu-a", "https://gpu.example", "secret", quota_jobs=2)
    pool = WorkerPool([worker], state_path=str(state))
    assert worker.quota_jobs == 2
    assert pool.snapshot()[0]["id"] == "gpu-a"
